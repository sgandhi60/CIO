The following information needs to be changed before running the script:

	In xmlElements.properties file:
	
		# increment the sequence by 1 
		# only PROD or TEST server, depends upon the platform the job is running
		mhTasks.control.sequence.data.prodserver=9
		mhTasks.control.sequence.data.testserver=29
		
	In persona.properties file:
	
		# processMonth is required to filter the specific record 
		# for specific CNUM from firstline_pc view (YYYYMM)
		processMonth=201508
		
	In persona.properties file:
	
	The following flags needs to be modified depends upon the platform the job is running:
	
		#Flag for accessing EPWS from Direct Connect
		#	true, if we have Direct Connect
		#	false, otherwise
		
		#accessEPWSFromDirectConnect=false
		accessEPWSFromDirectConnect=true
		
		#Flag for DEV/TEST or PROD on POD-C
		#	false, if we are running on DEV or TEST platform
		#	true, if we are running on PROD platform
		
		#isProd=false
		isProd=true
		
		
		#Flag for DEV/TEST DB on POD-C
		#	true, if we are running with DEV DB
		#	false, if we are running with TEST DB
		
		#isDevDB=false
		isDevDB=true
		
		#Flag for test run (log messages)
		
		isTestRun=true

		#Flag to decide whether to copy the records to Compliance table from Compliance_pre table
		# This flag MIST be true for mgrhub run processing
		
		copyToComplianceTable=false
		#copyToComplianceTable=true
		
		#Flag to decide MgrHub ONLY run 
		#	true, if we need to generate mgrHub data ONLY
		#	false, if we are running the normal combined data (Persona + MgrHub)
		
		isMgrHubOnlyRun=false
		#isMgrHubOnlyRun=true
		
		#Flag to decide whether MgrHub run required or not
		#	true, if we need to generate mgrHub data on Test or Prod server, false if we need to generate only Persona data
		#	false, for Dev server (always)
		# if this flag is true, "copyToComplianceTable" flag MUST be true
		
		#isMgrHubRunRequired=false
		isMgrHubRunRequired=true
		
		#Flag to decide MgrHub run on Test Server
		#	true, if we need to generate mgrHub data on Test server, otherwise false
		
		#isMgrHubOnTestRun=false
		isMgrHubOnTestRun=true
