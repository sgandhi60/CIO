package com.pbepc.ilog;

public class ComplianceForIlog {
	
	private String countryCode = "";
	/* Stage 6 */
	private String spMobCmp = "";
	private String spMobWwer = "";
	private String cpMobCmp = "";
	private String cpMobWwer = "";
	private String dcDatCmp = "";
	private String dcDatWwer = "";
	private String hovHveWwer = "";
	
	/* Stage 8 */
	private String multiServiceCheck = "";
	private String basicCell = "";
	private String smartphone = "";
	private String homevoice = "";
	private Double cellphoneAverage = 0.0;
	private Double basicCellCpc = 0.0;
	private Double smartphoneAverage = 0.0;
	private Double smartphoneCpc = 0.0;
	private Double homeOfficeAverage = 0.0;
	private Double homeOfficeCpc = 0.0;
	private Double datacardAverage = 0.0;
	private Double datacardCpc = 0.0;
	private Integer multiRule = 0;
	private Integer multiRule2 = 0;
	private Double tabletCpc = 0.0;
	private Double tabletAverage = 0.0;
	private String multiServiceCheck2 = "";
	private String basicCellSecondExpense = "";
	private String smartphoneSecondExpense = "";
	private String homeVoiceSecondExpense = "";
	private String cpMultiruleCalculated = "False";
	private String spMultiruleCalculated = "False";
	private String hovMultiruleCalculated = "False";
	private String multiruleCalculated = "False";
	private String multiRuleConcat = "";
	
	/* Stage 9a Smartphone */
	private String smartphoneCompliance = "";
	private String kfrCpcSpecialBillingHasExpSp = "";
	private String wwerexpIsBetweenZeroAndClipLevelSp = "";
	private String wwerExpIsAboveClipLevelSp = "";
	private String cmpCountry = "";
	private String smartphoneService = "";
	private String kfrCcSpecialBillingHasExpSp = "";
	private String exceptionMobCmpSp = "";
	private Double countryClipLevelSp = 0.0;
	private String isEmpWithinCmpCountrySp = "";
	private String isEmpEligibleForServiceSp = "";
	private Double smartphoneCc = 0.0;
	private String kfrCpcSpCalculated = "False";
	private String spComplianceCalculated = "False";
	private Double sumSPAveragePlusCpc = 0.0;
	private String exceptionMobWwerSp = "";
		
	/* Stage 9b Cellphone */
	private String cellphoneCompliance = "";
	private String kfrCpcSpecialBillingHasExpCp = "";
	private String wwerexpIsBetweenZeroAndClipLevelCp = "";
	private String wwerExpIsAboveClipLevelCp = "";
	private String cellphoneService = "";
	private String kfrCcSpecialBillingHasExpCp = "";
	private String exceptionMobCmpCp = "";
	private Double countryClipLevelCp = 0.0;
	private String isEmpWithinCmpCountryCp = "";
	private String isEmpEligibleForServiceCp = "";
	private Double basicCellCc = 0.0;
	private String kfrCpcCpCalculated = "False";
	private String cpComplianceCalculated = "False";
	private Double sumCPAveragePlusCpc = 0.0;
	private String exceptionMobWwerCp = "";

	/* Stage 9c Datacard */
	private String datacardCompliance = "";
	private String kfrCpcSpecialBillingHasExpDc = "";
	private String wwerexpIsBetweenZeroAndClipLevelDc = "";
	private String wwerExpIsAboveClipLevelDc = "";
	private String datacardService = "";
	private String kfrCcSpecialBillingHasExpDc = "";
	private String exceptionDatCmpDc = "";
	private Double countryClipLevelDc = 0.0;
	private String isEmpWithinCmpCountryDc = "";
	private String isEmpEligibleForServiceDc = "";
	private Double datacardCc = 0.0;
	private String kfrCpcDcCalculated = "False";
	private String dcComplianceCalculated = "False";
	private Double sumDCAveragePlusCpc = 0.0;
	private String exceptionDatWwerDc = "";
	
	/* Stage 9d Home Office Voice */
	private String homeofficevoiceCompliance = "";
	private String kfrCpcSpecialBillingHasExpHov = "";
	private String wwerexpIsBetweenZeroAndClipLevelHov = "";
	private String wwerExpIsAboveClipLevelHov = "";
	private String homeofficevoiceService = "";
	private String kfrCcSpecialBillingHasExpHov = "";
	private String exceptionMobCmpHov = "";
	private Double countryClipLevelHov = 0.0;
	private String isEmpWithinCmpCountryHov = "";
	private String isEmpEligibleForServiceHov = "";
	private Double homeofficevoiceCc = 0.0;
	private String hovCmp = "";
	private String kfrCpcHovCalculated = "False";
	private String hovComplianceCalculated = "False";
	private Double sumHovAveragePlusCpc = 0.0;
	private String exceptionMobHveWwerHov = "";
	
	/* Stage 10 Overall Compliance*/
	private String overallCompliance = "";
	private String overallCalculated = "false";
	private Integer countNonCompliance = 0;
	private Integer countCompliance = 0;
	private Integer countOccasionalUse = 0;
	private String realOverallCompliance = "";
	private String realOverallCalculated = "false";
	
	/* Stage 11 Explanation non-compliant*/
	private String explanation1Multi = "";
	private String explanation2Smartphone = "";
	private String explanation2BSmartphone = "";
	private String explanation3Cell = "";
	private String explanation3BCell = "";
	private String explanation4Datacard = "";
	private String explanation4BDatacard = "";
	private String collectionOfNonCompliantExplanation = "";
	private String summaryOfNonCompliantExplanation = "";
	private String explanationMultiCalculated = "False";
	private String explanation2SPCalculated = "False";
	private String explanation3CPCalculated = "False";
	private String explanation4DCCalculated = "False";
	private String explanationConcat = "";
	private String explanationSummaryCalculated = "False";
	//R2
	private String explanation5Hov = "";
	private String explanation5BHov = "";
	private String explanation5HovCalculated = "False";
	private String explanationMulti2Calculated = "False";
	private String explanation1Multi2 = "";
	
	
	/* Stage 12 Manager Hub feed*/
	private String managerHubFeed = "";

	public String getMultiServiceCheck() {
		return multiServiceCheck;
	}

	public void setMultiServiceCheck(String multiServiceCheck) {
		this.multiServiceCheck = multiServiceCheck;
	}

	public String getBasicCell() {
		return basicCell;
	}

	public void setBasicCell(String basicCell) {
		this.basicCell = basicCell;
	}

	public String getSmartphone() {
		return smartphone;
	}

	public void setSmartphone(String smartphone) {
		this.smartphone = smartphone;
	}

	public String getHomevoice() {
		return homevoice;
	}

	public void setHomevoice(String homevoice) {
		this.homevoice = homevoice;
	}

	public Double getCellphoneAverage() {
		return cellphoneAverage;
	}

	public void setCellphoneAverage(Double cellphoneAverage) {
		this.cellphoneAverage = cellphoneAverage;
	}

	public Double getBasicCellCpc() {
		return basicCellCpc;
	}

	public void setBasicCellCpc(Double basicCellCpc) {
		this.basicCellCpc = basicCellCpc;
	}

	public Double getSmartphoneAverage() {
		return smartphoneAverage;
	}

	public void setSmartphoneAverage(Double smartphoneAverage) {
		this.smartphoneAverage = smartphoneAverage;
	}

	public Double getSmartphoneCpc() {
		return smartphoneCpc;
	}

	public void setSmartphoneCpc(Double smartphoneCpc) {
		this.smartphoneCpc = smartphoneCpc;
	}

	public Double getHomeOfficeAverage() {
		return homeOfficeAverage;
	}

	public void setHomeOfficeAverage(Double homeOfficeAverage) {
		this.homeOfficeAverage = homeOfficeAverage;
	}

	public Double getHomeOfficeCpc() {
		return homeOfficeCpc;
	}

	public void setHomeOfficeCpc(Double homeOfficeCpc) {
		this.homeOfficeCpc = homeOfficeCpc;
	}
	public Double getDatacardAverage() {
		return datacardAverage;
	}

	public void setDatacardAverage(Double datacardAverage) {
		this.datacardAverage = datacardAverage;
	}

	public Double getDatacardCpc() {
		return datacardCpc;
	}

	public void setDatacardCpc(Double datacardCpc) {
		this.datacardCpc = datacardCpc;
	}

	public Integer getMultiRule() {
		return multiRule;
	}

	public void setMultiRule(Integer multiRule) {
		this.multiRule = multiRule;
	}

	public String getSmartphoneCompliance() {
		return smartphoneCompliance;
	}

	public void setSmartphoneCompliance(String smartphoneCompliance) {
		this.smartphoneCompliance = smartphoneCompliance;
	}

	public String getKfrCpcSpecialBillingHasExpSp() {
		return kfrCpcSpecialBillingHasExpSp;
	}

	public void setKfrCpcSpecialBillingHasExpSp(String kfrCpcSpecialBillingHasExpSp) {
		this.kfrCpcSpecialBillingHasExpSp = kfrCpcSpecialBillingHasExpSp;
	}

	public String getWwerexpIsBetweenZeroAndClipLevelSp() {
		return wwerexpIsBetweenZeroAndClipLevelSp;
	}

	public void setWwerexpIsBetweenZeroAndClipLevelSp(
			String wwerexpIsBetweenZeroAndClipLevelSp) {
		this.wwerexpIsBetweenZeroAndClipLevelSp = wwerexpIsBetweenZeroAndClipLevelSp;
	}

	public String getWwerExpIsAboveClipLevelSp() {
		return wwerExpIsAboveClipLevelSp;
	}

	public void setWwerExpIsAboveClipLevelSp(String wwerExpIsAboveClipLevelSp) {
		this.wwerExpIsAboveClipLevelSp = wwerExpIsAboveClipLevelSp;
	}

	public String getCmpCountry() {
		return cmpCountry;
	}

	public void setCmpCountry(String cmpCountry) {
		this.cmpCountry = cmpCountry;
	}

	public String getSmartphoneService() {
		return smartphoneService;
	}

	public void setSmartphoneService(String smartphoneService) {
		this.smartphoneService = smartphoneService;
	}

	public String getKfrCcSpecialBillingHasExpSp() {
		return kfrCcSpecialBillingHasExpSp;
	}

	public void setKfrCcSpecialBillingHasExpSp(String kfrCcSpecialBillingHasExpSp) {
		this.kfrCcSpecialBillingHasExpSp = kfrCcSpecialBillingHasExpSp;
	}

	public String getExceptionMobCmpSp() {
		return exceptionMobCmpSp;
	}

	public void setExceptionMobCmpSp(String exceptionMobCmpSp) {
		this.exceptionMobCmpSp = exceptionMobCmpSp;
	}

	public Double getCountryClipLevelSp() {
		return countryClipLevelSp;
	}

	public void setCountryClipLevelSp(Double countryClipLevelSp) {
		this.countryClipLevelSp = countryClipLevelSp;
	}

	public String getIsEmpWithinCmpCountrySp() {
		return isEmpWithinCmpCountrySp;
	}

	public void setIsEmpWithinCmpCountrySp(String isEmpWithinCmpCountrySp) {
		this.isEmpWithinCmpCountrySp = isEmpWithinCmpCountrySp;
	}

	public String getIsEmpEligibleForServiceSp() {
		return isEmpEligibleForServiceSp;
	}

	public void setIsEmpEligibleForServiceSp(String isEmpEligibleForServiceSp) {
		this.isEmpEligibleForServiceSp = isEmpEligibleForServiceSp;
	}

	public Double getSmartphoneCc() {
		return smartphoneCc;
	}

	public void setSmartphoneCc(Double smartphoneCc) {
		this.smartphoneCc = smartphoneCc;
	}

	public String getKfrCpcSpCalculated() {
		return kfrCpcSpCalculated;
	}

	public void setKfrCpcSpCalculated(String kfrCpcSpCalculated) {
		this.kfrCpcSpCalculated = kfrCpcSpCalculated;
	}

	public String getSpComplianceCalculated() {
		return spComplianceCalculated;
	}

	public void setSpComplianceCalculated(String spComplianceCalculated) {
		this.spComplianceCalculated = spComplianceCalculated;
	}

	public Double getSumSPAveragePlusCpc() {
		return sumSPAveragePlusCpc;
	}

	public void setSumSPAveragePlusCpc(Double sumSPAveragePlusCpc) {
		this.sumSPAveragePlusCpc = sumSPAveragePlusCpc;
	}

	public String getCellphoneCompliance() {
		return cellphoneCompliance;
	}

	public void setCellphoneCompliance(String cellphoneCompliance) {
		this.cellphoneCompliance = cellphoneCompliance;
	}

	public String getKfrCpcSpecialBillingHasExpCp() {
		return kfrCpcSpecialBillingHasExpCp;
	}

	public void setKfrCpcSpecialBillingHasExpCp(String kfrCpcSpecialBillingHasExpCp) {
		this.kfrCpcSpecialBillingHasExpCp = kfrCpcSpecialBillingHasExpCp;
	}

	public String getWwerexpIsBetweenZeroAndClipLevelCp() {
		return wwerexpIsBetweenZeroAndClipLevelCp;
	}

	public void setWwerexpIsBetweenZeroAndClipLevelCp(
			String wwerexpIsBetweenZeroAndClipLevelCp) {
		this.wwerexpIsBetweenZeroAndClipLevelCp = wwerexpIsBetweenZeroAndClipLevelCp;
	}

	public String getWwerExpIsAboveClipLevelCp() {
		return wwerExpIsAboveClipLevelCp;
	}

	public void setWwerExpIsAboveClipLevelCp(String wwerExpIsAboveClipLevelCp) {
		this.wwerExpIsAboveClipLevelCp = wwerExpIsAboveClipLevelCp;
	}

	public String getCellphoneService() {
		return cellphoneService;
	}

	public void setCellphoneService(String cellphoneService) {
		this.cellphoneService = cellphoneService;
	}

	public String getKfrCcSpecialBillingHasExpCp() {
		return kfrCcSpecialBillingHasExpCp;
	}

	public void setKfrCcSpecialBillingHasExpCp(String kfrCcSpecialBillingHasExpCp) {
		this.kfrCcSpecialBillingHasExpCp = kfrCcSpecialBillingHasExpCp;
	}

	public String getExceptionMobCmpCp() {
		return exceptionMobCmpCp;
	}

	public void setExceptionMobCmpCp(String exceptionMobCmpCp) {
		this.exceptionMobCmpCp = exceptionMobCmpCp;
	}

	public Double getCountryClipLevelCp() {
		return countryClipLevelCp;
	}

	public void setCountryClipLevelCp(Double countryClipLevelCp) {
		this.countryClipLevelCp = countryClipLevelCp;
	}

	public String getIsEmpWithinCmpCountryCp() {
		return isEmpWithinCmpCountryCp;
	}

	public void setIsEmpWithinCmpCountryCp(String isEmpWithinCmpCountryCp) {
		this.isEmpWithinCmpCountryCp = isEmpWithinCmpCountryCp;
	}

	public String getIsEmpEligibleForServiceCp() {
		return isEmpEligibleForServiceCp;
	}

	public void setIsEmpEligibleForServiceCp(String isEmpEligibleForServiceCp) {
		this.isEmpEligibleForServiceCp = isEmpEligibleForServiceCp;
	}

	public Double getBasicCellCc() {
		return basicCellCc;
	}

	public void setBasicCellCc(Double basicCellCc) {
		this.basicCellCc = basicCellCc;
	}

	public String getKfrCpcCpCalculated() {
		return kfrCpcCpCalculated;
	}

	public void setKfrCpcCpCalculated(String kfrCpcCpCalculated) {
		this.kfrCpcCpCalculated = kfrCpcCpCalculated;
	}

	public String getCpComplianceCalculated() {
		return cpComplianceCalculated;
	}

	public void setCpComplianceCalculated(String cpComplianceCalculated) {
		this.cpComplianceCalculated = cpComplianceCalculated;
	}

	public Double getSumCPAveragePlusCpc() {
		return sumCPAveragePlusCpc;
	}

	public void setSumCPAveragePlusCpc(Double sumCPAveragePlusCpc) {
		this.sumCPAveragePlusCpc = sumCPAveragePlusCpc;
	}

	public String getDatacardCompliance() {
		return datacardCompliance;
	}

	public void setDatacardCompliance(String datacardCompliance) {
		this.datacardCompliance = datacardCompliance;
	}

	public String getKfrCpcSpecialBillingHasExpDc() {
		return kfrCpcSpecialBillingHasExpDc;
	}

	public void setKfrCpcSpecialBillingHasExpDc(String kfrCpcSpecialBillingHasExpDc) {
		this.kfrCpcSpecialBillingHasExpDc = kfrCpcSpecialBillingHasExpDc;
	}

	public String getWwerexpIsBetweenZeroAndClipLevelDc() {
		return wwerexpIsBetweenZeroAndClipLevelDc;
	}

	public void setWwerexpIsBetweenZeroAndClipLevelDc(
			String wwerexpIsBetweenZeroAndClipLevelDc) {
		this.wwerexpIsBetweenZeroAndClipLevelDc = wwerexpIsBetweenZeroAndClipLevelDc;
	}

	public String getWwerExpIsAboveClipLevelDc() {
		return wwerExpIsAboveClipLevelDc;
	}

	public void setWwerExpIsAboveClipLevelDc(String wwerExpIsAboveClipLevelDc) {
		this.wwerExpIsAboveClipLevelDc = wwerExpIsAboveClipLevelDc;
	}

	public String getDatacardService() {
		return datacardService;
	}

	public void setDatacardService(String datacardService) {
		this.datacardService = datacardService;
	}

	public String getKfrCcSpecialBillingHasExpDc() {
		return kfrCcSpecialBillingHasExpDc;
	}

	public void setKfrCcSpecialBillingHasExpDc(String kfrCcSpecialBillingHasExpDc) {
		this.kfrCcSpecialBillingHasExpDc = kfrCcSpecialBillingHasExpDc;
	}

	public Double getCountryClipLevelDc() {
		return countryClipLevelDc;
	}

	public void setCountryClipLevelDc(Double countryClipLevelDc) {
		this.countryClipLevelDc = countryClipLevelDc;
	}

	public String getIsEmpWithinCmpCountryDc() {
		return isEmpWithinCmpCountryDc;
	}

	public void setIsEmpWithinCmpCountryDc(String isEmpWithinCmpCountryDc) {
		this.isEmpWithinCmpCountryDc = isEmpWithinCmpCountryDc;
	}

	public String getIsEmpEligibleForServiceDc() {
		return isEmpEligibleForServiceDc;
	}

	public void setIsEmpEligibleForServiceDc(String isEmpEligibleForServiceDc) {
		this.isEmpEligibleForServiceDc = isEmpEligibleForServiceDc;
	}

	public Double getDatacardCc() {
		return datacardCc;
	}

	public void setDatacardCc(Double datacardCc) {
		this.datacardCc = datacardCc;
	}

	public String getKfrCpcDcCalculated() {
		return kfrCpcDcCalculated;
	}

	public void setKfrCpcDcCalculated(String kfrCpcDcCalculated) {
		this.kfrCpcDcCalculated = kfrCpcDcCalculated;
	}

	public String getDcComplianceCalculated() {
		return dcComplianceCalculated;
	}

	public void setDcComplianceCalculated(String dcComplianceCalculated) {
		this.dcComplianceCalculated = dcComplianceCalculated;
	}

	public Double getSumDCAveragePlusCpc() {
		return sumDCAveragePlusCpc;
	}

	public void setSumDCAveragePlusCpc(Double sumDCAveragePlusCpc) {
		this.sumDCAveragePlusCpc = sumDCAveragePlusCpc;
	}

	public String getOverallCompliance() {
		return overallCompliance;
	}

	public void setOverallCompliance(String overallCompliance) {
		this.overallCompliance = overallCompliance;
	}

	public String getOverallCalculated() {
		return overallCalculated;
	}

	public void setOverallCalculated(String overallCalculated) {
		this.overallCalculated = overallCalculated;
	}

	public Integer getCountNonCompliance() {
		return countNonCompliance;
	}

	public void setCountNonCompliance(Integer countNonCompliance) {
		this.countNonCompliance = countNonCompliance;
	}

	public Integer getCountCompliance() {
		return countCompliance;
	}

	public void setCountCompliance(Integer countCompliance) {
		this.countCompliance = countCompliance;
	}

	public Integer getCountOccasionalUse() {
		return countOccasionalUse;
	}

	public void setCountOccasionalUse(Integer countOccasionalUse) {
		this.countOccasionalUse = countOccasionalUse;
	}

	public String getExplanation1Multi() {
		return explanation1Multi;
	}

	public void setExplanation1Multi(String explanation1Multi) {
		this.explanation1Multi = explanation1Multi;
	}

	public String getExplanation2Smartphone() {
		return explanation2Smartphone;
	}

	public void setExplanation2Smartphone(String explanation2Smartphone) {
		this.explanation2Smartphone = explanation2Smartphone;
	}

	public String getExplanation2BSmartphone() {
		return explanation2BSmartphone;
	}

	public void setExplanation2BSmartphone(String explanation2bSmartphone) {
		explanation2BSmartphone = explanation2bSmartphone;
	}

	public String getExplanation3Cell() {
		return explanation3Cell;
	}

	public void setExplanation3Cell(String explanation3Cell) {
		this.explanation3Cell = explanation3Cell;
	}

	public String getExplanation3BCell() {
		return explanation3BCell;
	}

	public void setExplanation3BCell(String explanation3bCell) {
		explanation3BCell = explanation3bCell;
	}

	public String getExplanation4Datacard() {
		return explanation4Datacard;
	}

	public void setExplanation4Datacard(String explanation4Datacard) {
		this.explanation4Datacard = explanation4Datacard;
	}

	public String getExplanation4BDatacard() {
		return explanation4BDatacard;
	}

	public void setExplanation4BDatacard(String explanation4bDatacard) {
		explanation4BDatacard = explanation4bDatacard;
	}

	public String getCollectionOfNonCompliantExplanation() {
		return collectionOfNonCompliantExplanation;
	}

	public void setCollectionOfNonCompliantExplanation(
			String collectionOfNonCompliantExplanation) {
		this.collectionOfNonCompliantExplanation = collectionOfNonCompliantExplanation;
	}

	public String getSummaryOfNonCompliantExplanation() {
		return summaryOfNonCompliantExplanation;
	}

	public void setSummaryOfNonCompliantExplanation(
			String summaryOfNonCompliantExplanation) {
		this.summaryOfNonCompliantExplanation = summaryOfNonCompliantExplanation;
	}

	public String getExplanationMultiCalculated() {
		return explanationMultiCalculated;
	}

	public void setExplanationMultiCalculated(String explanationMultiCalculated) {
		this.explanationMultiCalculated = explanationMultiCalculated;
	}

	public String getExplanation2SPCalculated() {
		return explanation2SPCalculated;
	}

	public void setExplanation2SPCalculated(String explanation2spCalculated) {
		explanation2SPCalculated = explanation2spCalculated;
	}

	public String getExplanation3CPCalculated() {
		return explanation3CPCalculated;
	}

	public void setExplanation3CPCalculated(String explanation3cpCalculated) {
		explanation3CPCalculated = explanation3cpCalculated;
	}

	public String getExplanation4DCCalculated() {
		return explanation4DCCalculated;
	}

	public void setExplanation4DCCalculated(String explanation4dcCalculated) {
		explanation4DCCalculated = explanation4dcCalculated;
	}

	public String getExplanationConcat() {
		return explanationConcat;
	}

	public void setExplanationConcat(String explanationConcat) {
		this.explanationConcat = explanationConcat;
	}

	public String getManagerHubFeed() {
		return managerHubFeed;
	}

	public void setManagerHubFeed(String managerHubFeed) {
		this.managerHubFeed = managerHubFeed;
	}

	public String getExplanationSummaryCalculated() {
		return explanationSummaryCalculated;
	}

	public void setExplanationSummaryCalculated(String explanationSummaryCalculated) {
		this.explanationSummaryCalculated = explanationSummaryCalculated;
	}

	public Double getTabletCpc() {
		return tabletCpc;
	}

	public void setTabletCpc(Double tabletCpc) {
		this.tabletCpc = tabletCpc;
	}

	public Double getTabletAverage() {
		return tabletAverage;
	}

	public void setTabletAverage(Double tabletAverage) {
		this.tabletAverage = tabletAverage;
	}

	public String getMultiServiceCheck2() {
		return multiServiceCheck2;
	}

	public void setMultiServiceCheck2(String multiServiceCheck2) {
		this.multiServiceCheck2 = multiServiceCheck2;
	}

	public String getBasicCellSecondExpense() {
		return basicCellSecondExpense;
	}

	public void setBasicCellSecondExpense(String basicCellSecondExpense) {
		this.basicCellSecondExpense = basicCellSecondExpense;
	}

	public String getSmartphoneSecondExpense() {
		return smartphoneSecondExpense;
	}

	public void setSmartphoneSecondExpense(String smartphoneSecondExpense) {
		this.smartphoneSecondExpense = smartphoneSecondExpense;
	}

	public String getHomeofficevoiceCompliance() {
		return homeofficevoiceCompliance;
	}

	public void setHomeofficevoiceCompliance(String homeofficevoiceCompliance) {
		this.homeofficevoiceCompliance = homeofficevoiceCompliance;
	}

	public String getKfrCpcSpecialBillingHasExpHov() {
		return kfrCpcSpecialBillingHasExpHov;
	}

	public void setKfrCpcSpecialBillingHasExpHov(
			String kfrCpcSpecialBillingHasExpHov) {
		this.kfrCpcSpecialBillingHasExpHov = kfrCpcSpecialBillingHasExpHov;
	}

	public String getWwerexpIsBetweenZeroAndClipLevelHov() {
		return wwerexpIsBetweenZeroAndClipLevelHov;
	}

	public void setWwerexpIsBetweenZeroAndClipLevelHov(
			String wwerexpIsBetweenZeroAndClipLevelHov) {
		this.wwerexpIsBetweenZeroAndClipLevelHov = wwerexpIsBetweenZeroAndClipLevelHov;
	}

	public String getWwerExpIsAboveClipLevelHov() {
		return wwerExpIsAboveClipLevelHov;
	}

	public void setWwerExpIsAboveClipLevelHov(String wwerExpIsAboveClipLevelHov) {
		this.wwerExpIsAboveClipLevelHov = wwerExpIsAboveClipLevelHov;
	}

	public String getKfrCcSpecialBillingHasExpHov() {
		return kfrCcSpecialBillingHasExpHov;
	}

	public void setKfrCcSpecialBillingHasExpHov(String kfrCcSpecialBillingHasExpHov) {
		this.kfrCcSpecialBillingHasExpHov = kfrCcSpecialBillingHasExpHov;
	}

	public String getExceptionMobCmpHov() {
		return exceptionMobCmpHov;
	}

	public void setExceptionMobCmpHov(String exceptionMobCmpHov) {
		this.exceptionMobCmpHov = exceptionMobCmpHov;
	}

	public Double getCountryClipLevelHov() {
		return countryClipLevelHov;
	}

	public void setCountryClipLevelHov(Double countryClipLevelHov) {
		this.countryClipLevelHov = countryClipLevelHov;
	}

	public String getIsEmpWithinCmpCountryHov() {
		return isEmpWithinCmpCountryHov;
	}

	public void setIsEmpWithinCmpCountryHov(String isEmpWithinCmpCountryHov) {
		this.isEmpWithinCmpCountryHov = isEmpWithinCmpCountryHov;
	}

	public String getIsEmpEligibleForServiceHov() {
		return isEmpEligibleForServiceHov;
	}

	public void setIsEmpEligibleForServiceHov(String isEmpEligibleForServiceHov) {
		this.isEmpEligibleForServiceHov = isEmpEligibleForServiceHov;
	}

	public String getHovCmp() {
		return hovCmp;
	}

	public void setHovCmp(String hovCmp) {
		this.hovCmp = hovCmp;
	}

	public String getKfrCpcHovCalculated() {
		return kfrCpcHovCalculated;
	}

	public void setKfrCpcHovCalculated(String kfrCpcHovCalculated) {
		this.kfrCpcHovCalculated = kfrCpcHovCalculated;
	}

	public String getHovComplianceCalculated() {
		return hovComplianceCalculated;
	}

	public void setHovComplianceCalculated(String hovComplianceCalculated) {
		this.hovComplianceCalculated = hovComplianceCalculated;
	}

	public Double getSumHovAveragePlusCpc() {
		return sumHovAveragePlusCpc;
	}

	public void setSumHovAveragePlusCpc(Double sumHovAveragePlusCpc) {
		this.sumHovAveragePlusCpc = sumHovAveragePlusCpc;
	}

	public String getExplanation5Hov() {
		return explanation5Hov;
	}

	public void setExplanation5Hov(String explanation5Hov) {
		this.explanation5Hov = explanation5Hov;
	}

	public String getExplanation5BHov() {
		return explanation5BHov;
	}

	public void setExplanation5BHov(String explanation5bHov) {
		explanation5BHov = explanation5bHov;
	}

	public String getExplanation5HovCalculated() {
		return explanation5HovCalculated;
	}

	public void setExplanation5HovCalculated(String explanation5HovCalculated) {
		this.explanation5HovCalculated = explanation5HovCalculated;
	}

	public Integer getMultiRule2() {
		return multiRule2;
	}

	public void setMultiRule2(Integer multiRule2) {
		this.multiRule2 = multiRule2;
	}

	public String getHomeofficevoiceService() {
		return homeofficevoiceService;
	}

	public void setHomeofficevoiceService(String homeofficevoiceService) {
		this.homeofficevoiceService = homeofficevoiceService;
	}

	public Double getHomeofficevoiceCc() {
		return homeofficevoiceCc;
	}

	public void setHomeofficevoiceCc(Double homeofficevoiceCc) {
		this.homeofficevoiceCc = homeofficevoiceCc;
	}

	public String getExplanationMulti2Calculated() {
		return explanationMulti2Calculated;
	}

	public void setExplanationMulti2Calculated(String explanationMulti2Calculated) {
		this.explanationMulti2Calculated = explanationMulti2Calculated;
	}

	public String getExplanation1Multi2() {
		return explanation1Multi2;
	}

	public void setExplanation1Multi2(String explanation1Multi2) {
		this.explanation1Multi2 = explanation1Multi2;
	}

	public String getExceptionMobWwerSp() {
		return exceptionMobWwerSp;
	}

	public void setExceptionMobWwerSp(String exceptionMobWwerSp) {
		this.exceptionMobWwerSp = exceptionMobWwerSp;
	}

	public String getExceptionMobWwerCp() {
		return exceptionMobWwerCp;
	}

	public void setExceptionMobWwerCp(String exceptionMobWwerCp) {
		this.exceptionMobWwerCp = exceptionMobWwerCp;
	}

	public String getExceptionMobHveWwerHov() {
		return exceptionMobHveWwerHov;
	}

	public void setExceptionMobHveWwerHov(String exceptionMobHveWwerHov) {
		this.exceptionMobHveWwerHov = exceptionMobHveWwerHov;
	}

	public String getRealOverallCompliance() {
		return realOverallCompliance;
	}

	public void setRealOverallCompliance(String realOverallCompliance) {
		this.realOverallCompliance = realOverallCompliance;
	}

	public String getRealOverallCalculated() {
		return realOverallCalculated;
	}

	public void setRealOverallCalculated(String realOverallCalculated) {
		this.realOverallCalculated = realOverallCalculated;
	}

	public String getSpMobCmp() {
		return spMobCmp;
	}

	public void setSpMobCmp(String spMobCmp) {
		this.spMobCmp = spMobCmp;
	}

	public String getSpMobWwer() {
		return spMobWwer;
	}

	public void setSpMobWwer(String spMobWwer) {
		this.spMobWwer = spMobWwer;
	}

	public String getCpMobCmp() {
		return cpMobCmp;
	}

	public void setCpMobCmp(String cpMobCmp) {
		this.cpMobCmp = cpMobCmp;
	}

	public String getCpMobWwer() {
		return cpMobWwer;
	}

	public void setCpMobWwer(String cpMobWwer) {
		this.cpMobWwer = cpMobWwer;
	}

	public String getDcDatCmp() {
		return dcDatCmp;
	}

	public void setDcDatCmp(String dcDatCmp) {
		this.dcDatCmp = dcDatCmp;
	}

	public String getDcDatWwer() {
		return dcDatWwer;
	}

	public void setDcDatWwer(String dcDatWwer) {
		this.dcDatWwer = dcDatWwer;
	}

	public String getHovHveWwer() {
		return hovHveWwer;
	}

	public void setHovHveWwer(String hovHveWwer) {
		this.hovHveWwer = hovHveWwer;
	}

	public String getExceptionDatCmpDc() {
		return exceptionDatCmpDc;
	}

	public void setExceptionDatCmpDc(String exceptionDatCmpDc) {
		this.exceptionDatCmpDc = exceptionDatCmpDc;
	}

	public String getExceptionDatWwerDc() {
		return exceptionDatWwerDc;
	}

	public void setExceptionDatWwerDc(String exceptionDatWwerDc) {
		this.exceptionDatWwerDc = exceptionDatWwerDc;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getHomeVoiceSecondExpense() {
		return homeVoiceSecondExpense;
	}

	public void setHomeVoiceSecondExpense(String homeVoiceSecondExpense) {
		this.homeVoiceSecondExpense = homeVoiceSecondExpense;
	}

	public String getCpMultiruleCalculated() {
		return cpMultiruleCalculated;
	}

	public void setCpMultiruleCalculated(String cpMultiruleCalculated) {
		this.cpMultiruleCalculated = cpMultiruleCalculated;
	}

	public String getSpMultiruleCalculated() {
		return spMultiruleCalculated;
	}

	public void setSpMultiruleCalculated(String spMultiruleCalculated) {
		this.spMultiruleCalculated = spMultiruleCalculated;
	}

	public String getHovMultiruleCalculated() {
		return hovMultiruleCalculated;
	}

	public void setHovMultiruleCalculated(String hovMultiruleCalculated) {
		this.hovMultiruleCalculated = hovMultiruleCalculated;
	}

	public String getMultiruleCalculated() {
		return multiruleCalculated;
	}

	public void setMultiruleCalculated(String multiruleCalculated) {
		this.multiruleCalculated = multiruleCalculated;
	}

	public String getMultiRuleConcat() {
		return multiRuleConcat;
	}

	public void setMultiRuleConcat(String multiRuleConcat) {
		this.multiRuleConcat = multiRuleConcat;
	}

	

}