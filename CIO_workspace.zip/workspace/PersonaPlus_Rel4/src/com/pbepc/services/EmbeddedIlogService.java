package com.pbepc.services;

import ilog.rules.archive.IlrJarArchiveLoader;
import ilog.rules.engine.IlrContext;
import ilog.rules.engine.IlrParameterMap;
import ilog.rules.engine.IlrRuleset;
import ilog.rules.engine.IlrRulesetArchiveParser;
import ilog.rules.util.engine.IlrRulesetOptimConfig;
import java.io.InputStream;
import java.util.jar.JarInputStream;
import com.pbepc.ilog.ComplianceForIlog;

public class EmbeddedIlogService {

	private IlrContext 			engine = null; 
	private String				rulesetPath = "com/pbepc/ilog/ruleSetArchPBEPC.jar";			
	
	public EmbeddedIlogService() {
		initalizeIlogEngine();
	}
	
	private void initalizeIlogEngine() {
		try {
			// --------------------------------------------------------------------
			// Retrieve the ruleset archive JAR file using the Java I/O API.
			// --------------------------------------------------------------------
			InputStream fileStream =  Thread.currentThread().getContextClassLoader().getResourceAsStream(rulesetPath);					
			JarInputStream jarStream = new JarInputStream(fileStream);

			// ----------------------------------------------
			// Create the ruleset archive parsing objects.
			// ----------------------------------------------
			IlrJarArchiveLoader loader =  new IlrJarArchiveLoader(jarStream);
			IlrRulesetArchiveParser parser =  new IlrRulesetArchiveParser();

			// ----------------------------------------------
			// Create a ruleset to store the parsed rules.
			// ----------------------------------------------
			IlrRuleset ruleset = new IlrRuleset();

			// -----------------------------------------------------------------
			// Connect the Ruleset to the Ruleset Archive parser so that
			// the parsed rules are accumulated in the Ruleset as the parsing
			// is performed.
			// -----------------------------------------------------------------
			parser.setRuleset(ruleset);
			

			// ---------------------------------------------
			// Launch the parsing of the Ruleset Archive:
			// ---------------------------------------------
			if (! parser.parseArchive(loader)) {
				// -----------------------------------
				// In case of errors, list the errors.
				// -----------------------------------
				String[] errors = parser.getErrors();
				StringBuffer bufferError = new StringBuffer();
				for (int i = 0; i < errors.length; i++) {
					String error = errors[i];
					System.out.println("Error while parsing Ruleset Archive : " 	+ error);
					bufferError.append(error).append("\n");
				}
				throw new Exception(bufferError.toString());
			} else {
				// ----------------------------------------------------------------
				// [Optional] Optimize the ruleset if in RETE and if runtime
				// resources (time) permit.
				// ----------------------------------------------------------------

				IlrRulesetOptimConfig config = new IlrRulesetOptimConfig();
				config.hasherGeneration = true;   

				// adapt the optimization to your needs
				config.wmModifiedByCode = false;  

				// adapt the optimization to your needs
				ruleset.optimize(config);
			} 

			//	Create an engine based on the ruleset. 
			// ready to be used later, when needed
			engine = new IlrContext(ruleset);
			
		} 	catch (Exception exception) {
			System.out.println("Ilog engine has not been initialized for the following reason : " + exception.getMessage());
			exception.printStackTrace();
		}
	}
	
	// request the Ilog engine embedded to work
	public synchronized ComplianceForIlog getComplianceForThisEmployee(ComplianceForIlog complianceIn) {
		
		ComplianceForIlog compliance = null;
		if (engine != null) {
			
			// Set the parameter
			//engine.reset();		// Very important to reset .. to allow to call it several time. 
			//engine.resetToInitialState(true);
			engine.resetRuleflow();
			engine.setParameterValue("complianceForIlog",complianceIn);				
						
			// execute the engine
			IlrParameterMap outputs  = engine.execute();
			
			// get the return
			compliance= (ComplianceForIlog) outputs.getObjectValue("complianceForIlog");
		}
				
		return compliance;
		
	}
}
