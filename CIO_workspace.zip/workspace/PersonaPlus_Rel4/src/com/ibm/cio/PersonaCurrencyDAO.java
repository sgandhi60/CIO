package com.ibm.cio;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.log4j.Logger;

//public class PersonaCurrencyDAO extends BaseDAO{
public class PersonaCurrencyDAO{

	private Connection conn = null;
	private boolean isTestRun;

	private static Logger LOGGER = Logger.getLogger(PersonaCurrencyDAO.class);

	public PersonaCurrencyDAO(Connection connection, boolean testRun) {
		// initialization 
		conn = connection;
		isTestRun = testRun;

		if (isTestRun)
			LOGGER.debug(new StringBuffer("Created PersonaCurrencyDAO object successfully"));

	}

	
	/**
	 * Retrieves currency exchange rates from exchange rate table and updates it in currency table
	 * @return
	 */
	public int updateCurrencyXchgRates(Connection con){
			
		String query = null;
		PreparedStatement stmt = null;
		int result = -1;

		
		if (isTestRun) {
			LOGGER.debug(new StringBuffer("Entering PersonaCurrencyDAO::updateCurrencyXchgRates() <============"));
			LOGGER.debug(new StringBuffer("Updating Currency records"));
		}
		
		try {

			// invoke UPDATE query to update the currency table with exchange rates
			query = SQLQuery.getQuery(SQLQuery.PERSONA_CURRENCY_UPDATE);
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.prepareStatement(query);

			result = stmt.executeUpdate();

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Updated ").append(result).append(" Currency record(s)"));
			}

			// Close the Statement
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing PreparedStatement. Resources might not be released ", e);
				}//end catch
			}
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Exiting PersonaCurrencyDAO::updateCurrencyXchgRates() ============>"));
			}

			return result;
			
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer("Exception caught attempting to update currency records into table " + e.getMessage()));
		      e.printStackTrace();
		      return -1;
		}
	}
}
