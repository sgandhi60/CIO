package com.ibm.cio;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.log4j.Logger;

//public class PersonaGVIDAO extends BaseDAO{
public class PersonaGVIDAO{

	private Connection conn = null;
	private boolean isTestRun;

	private static Logger LOGGER = Logger.getLogger(PersonaGVIDAO.class);

	public PersonaGVIDAO(Connection connection, boolean testRun) {
		// initialization 
		conn = connection;
		isTestRun = testRun;

		if (isTestRun)
			LOGGER.debug(new StringBuffer("Created PersonaGVIDAO object successfully"));

	}
	
	/**
	 * Deletes records 
	 * @return
	 */
	public int deleteRecordsFromTempTable(){
		
		String query = null;
		PreparedStatement stmt = null;
		int result = -1;

		
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaGVIDAO::deleteRecordsFromTempTable() <============"));
		
		try {

			// invoke DELETE query to clean up the table
			query = SQLQuery.getQuery(SQLQuery.PERSONA_GVI_TEMP_DELETE);
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.prepareStatement(query);

			result = stmt.executeUpdate();

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Deleted ").append(result).append(" record(s)"));
			}

			// Close the Statement
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing PreparedStatement. Resources might not be released ", e);
				}//end catch
			}
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Exiting PersonaGVIDAO::deleteRecordsFromTempTable() ============>"));
			}

			return result;
			
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer("Exception caught attempting to delete records from table " + e.getMessage()));
		      e.printStackTrace();
		      return -1;
		}
	}

	
	/**
	 * Inserts records 
	 * @return
	 */
	public int insertRecordsIntoTempTable(){
			
		String query = null;
		PreparedStatement stmt = null;
		int result = -1;

		
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaGVIDAO::insertRecordsIntoTempTable() <============"));
		
		try {

			// invoke INSERT query to populate the table
			query = SQLQuery.getQuery(SQLQuery.PERSONA_GVI_TEMP_INSERT);
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.prepareStatement(query);

			result = stmt.executeUpdate();

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Inserted ").append(result).append(" record(s)"));
			}

			// Close the Statement
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing PreparedStatement. Resources might not be released ", e);
				}//end catch
			}
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Exiting PersonaGVIDAO::insertRecordsIntoTempTable() ============>"));
			}

			return result;
			
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer("Exception caught attempting to insert record into table " + e.getMessage()));
		      e.printStackTrace();
		      return -1;
		}
	}
	
	/**
	 * Deletes records 
	 * @return
	 */
	public int deleteRecordsFromTemp1Table(){
		
		String query = null;
		PreparedStatement stmt = null;
		int result = -1;

		
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaGVIDAO::deleteRecordsFromTemp1Table() <============"));
		
		try {

			// invoke DELETE query to clean up the table
			query = SQLQuery.getQuery(SQLQuery.PERSONA_GVI_TEMP1_DELETE);
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.prepareStatement(query);

			result = stmt.executeUpdate();

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Deleted ").append(result).append(" record(s)"));
			}

			// Close the Statement
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing PreparedStatement. Resources might not be released ", e);
				}//end catch
			}
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Exiting PersonaGVIDAO::deleteRecordsFromTemp1Table() ============>"));
			}

			return result;
			
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer("Exception caught attempting to delete records from table " + e.getMessage()));
		      e.printStackTrace();
		      return -1;
		}
	}

	
	/**
	 * Inserts records 
	 * @return
	 */
	public int insertRecordsIntoTemp1Table(){
			
		String query = null;
		PreparedStatement stmt = null;
		int result = -1;

		
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaGVIDAO::insertRecordsIntoTemp1Table() <============"));
		
		try {

			// invoke INSERT query to populate the table
			query = SQLQuery.getQuery(SQLQuery.PERSONA_GVI_TEMP1_INSERT);
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.prepareStatement(query);

			result = stmt.executeUpdate();

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Inserted ").append(result).append(" record(s)"));
			}

			// Close the Statement
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing PreparedStatement. Resources might not be released ", e);
				}//end catch
			}
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Exiting PersonaGVIDAO::insertRecordsIntoTemp1Table() ============>"));
			}

			return result;
			
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer("Exception caught attempting to insert record into table " + e.getMessage()));
		      e.printStackTrace();
		      return -1;
		}
	}

	/**
	 * Deletes existing records for serials in P_US_GVI_TEMP1 table from P_US_GVI_TEMP table 
	 * @return
	 */
	public int removeTemp1SerialsFromTempTable(){
		
		String query = null;
		PreparedStatement stmt = null;
		int result = -1;

		
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaGVIDAO::removeTemp1SerialsFromTempTable() <============"));
		
		try {

			// invoke DELETE query 
			query = SQLQuery.getQuery(SQLQuery.PERSONA_GVI_TEMP_TEMP1_DELETE);
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.prepareStatement(query);

			result = stmt.executeUpdate();

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Deleted ").append(result).append(" record(s)"));
			}

			// Close the Statement
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing PreparedStatement. Resources might not be released ", e);
				}//end catch
			}
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Exiting PersonaGVIDAO::removeTemp1SerialsFromTempTable() ============>"));
			}

			return result;
			
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer("Exception caught attempting to delete existing serials in P_US_GVI_TEMP1 table from P_US_GVI_TEMP table " + e.getMessage()));
		      e.printStackTrace();
		      return -1;
		}
	}

	/**
	 * Deletes records 
	 * @return
	 */
	public int deleteRecords(){
		
		String query = null;
		PreparedStatement stmt = null;
		int result = -1;

		
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaGVIDAO::deleteRecords() <============"));
		
		try {

			// invoke DELETE query to clean up the table
			query = SQLQuery.getQuery(SQLQuery.PERSONA_GVI_FILTERED_DELETE);
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.prepareStatement(query);

			result = stmt.executeUpdate();

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Deleted ").append(result).append(" record(s)"));
			}

			// Close the Statement
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing PreparedStatement. Resources might not be released ", e);
				}//end catch
			}
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Exiting PersonaGVIDAO::deleteRecords() ============>"));
			}

			return result;
			
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer("Exception caught attempting to delete records from table " + e.getMessage()));
		      e.printStackTrace();
		      return -1;
		}
	}

	
	/**
	 * Merge and Insert records 
	 * @return
	 */
	public int mergeAndInsertRecords(){
			
		String query = null;
		PreparedStatement stmt = null;
		int result = -1;

		
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaGVIDAO::mergeAndInsertRecords() <============"));
		
		try {

			// invoke INSERT query to populate the table
			query = SQLQuery.getQuery(SQLQuery.PERSONA_GVI_FILTERED_INSERT);
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.prepareStatement(query);

			result = stmt.executeUpdate();

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Inserted ").append(result).append(" record(s)"));
			}

			// Close the Statement
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing PreparedStatement. Resources might not be released ", e);
				}//end catch
			}
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Exiting PersonaGVIDAO::mergeAndInsertRecords() ============>"));
			}

			return result;
			
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer("Exception caught attempting to merge and insert record into table " + e.getMessage()));
		      e.printStackTrace();
		      return -1;
		}
	}
	
}
