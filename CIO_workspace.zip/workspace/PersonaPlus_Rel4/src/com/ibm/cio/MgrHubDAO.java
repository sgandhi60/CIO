package com.ibm.cio;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Properties;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.log4j.Logger;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;


//public class MgrHubDAO extends BaseDAO{
public class MgrHubDAO{

	private Connection conn = null;
	private boolean isTestRun;

	private static Logger LOGGER = Logger.getLogger(MgrHubDAO.class);

	public MgrHubDAO(Connection connection, boolean testRun) {
		// initialization 
		conn = connection;
		isTestRun = testRun;

		if (isTestRun)
			LOGGER.debug(new StringBuffer("Created MgrHubDAO object successfully"));

	}
	
	/**
	 * Builds Document based on the XML elements from Manager Hub data
	 * @return
	 */
	public Document buildXMLDoc(Connection con, Properties xmlElemsProps, Properties mgrHubProps){
			
		String query = null;
		Statement stmt = null;
        ResultSet rs = null;
		int totalMgrs = 0;
		Document doc = null;
//		String expDateTime = null;
		boolean isMgrHubOnTestRun = false;
		
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering MgrHubDAO::buildXMLDoc() <============"));

		try {
/*			
//			processDate = "2015-01-15";
			String processDate = mgrHubProps.getProperty("processDate");

			// invoke SELECT query to retrieve manager hub data from mgrHub table
			query = SQLQuery.getQuery(SQLQuery.PERSONA_COMPLIANCE_TO_MGRHUB_SELECT1) +
					"'" + processDate + "'" +
					SQLQuery.getQuery(SQLQuery.PERSONA_COMPLIANCE_TO_MGRHUB_SELECT2) +
					"'" + mgrHubProps.getProperty("OverallCompliantLevel") + "'" +
					SQLQuery.getQuery(SQLQuery.PERSONA_COMPLIANCE_TO_MGRHUB_SELECT3);
*/
			String processMonth = mgrHubProps.getProperty("processMonth");
			String processDate = processMonth + "01";

			// invoke SELECT query to retrieve manager hub data from mgrHub table
			query = SQLQuery.getQuery(SQLQuery.PERSONA_MGRHUB_SELECT1) +
					"'" + processMonth + "'" +
					SQLQuery.getQuery(SQLQuery.PERSONA_MGRHUB_SELECT2) +
					"'" + mgrHubProps.getProperty("OverallCompliantLevel") + "'" +
					SQLQuery.getQuery(SQLQuery.PERSONA_MGRHUB_SELECT3);
					
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
		    
 			rs = stmt.executeQuery(query);
 
 			if (rs!=null){
				if(rs.last()){
					totalMgrs = rs.getRow(); 
				    rs.beforeFirst();
				}
			
				if (isTestRun) {
					LOGGER.debug(new StringBuffer("Total # of manager records: ").append(totalMgrs));
				}

				if (totalMgrs <= 0 ) {
					LOGGER.error(new StringBuffer("No manager records exist in MGRHUB.FIRSTLINE_PC view "));
					return doc;
				}
			}else{
				//no result set retrieved
				if (isTestRun) {
					LOGGER.debug(new StringBuffer("No record found in MGRHUB.FIRSTLINE_PC view "));
				}
				return doc;
 			}	
		    
 		    String month = null;
 		    String year = null;

 		    try {
				LOGGER.debug(new StringBuffer("Date Format = ").append(mgrHubProps.getProperty("simpleDateFormat").trim()));
				SimpleDateFormat sdf = new SimpleDateFormat(mgrHubProps.getProperty("simpleDateFormat").trim());

 		 		Date pDate = sdf.parse(processDate);
 
 	 		    Calendar cal = Calendar.getInstance();
 	 		    cal.setTime(pDate);
 	 		    
 	 		    int yr = cal.get(Calendar.YEAR);
 	 		    int mon = cal.get(Calendar.MONTH);
// 	 		    int day = cal.get(Calendar.DAY_OF_MONTH);

 				if (isTestRun) {
//	 				LOGGER.debug(new StringBuffer("Process Date = ").append(processDate));
 	 				LOGGER.debug(new StringBuffer("Process Month = ").append(processMonth));
 	 				LOGGER.debug(new StringBuffer("Year = ").append(yr));
 					LOGGER.debug(new StringBuffer("Month = ").append(mon+1));
// 					LOGGER.debug(new StringBuffer("Day = ").append(day));
 				}
/* 				
	 		    // month is 0 based. so January is 0, February is 1, etc...
 	 		    if ( mon == 0 ) {
 	 		    	cal.set(Calendar.MONTH, 11);
 	 		    	cal.set(Calendar.YEAR, yr-1);
 	 		    } else {
 	 		    	cal.set(Calendar.MONTH, mon-1);
	 		    }
*/	    
 		    	month = cal.getDisplayName(Calendar.MONTH, Calendar.LONG, Locale.getDefault());;
 	 		    year = Integer.toString(cal.get(Calendar.YEAR));

 		    } catch (ParseException e) {
	            e.printStackTrace();
	        }
 	 		    		
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Month = ").append(month));
				LOGGER.debug(new StringBuffer("Year = ").append(year));
			}
	 		    		
 /* 	 		    
 	 		    // add 1 month to get the expireTime
 				cal.add(Calendar.MONTH, 1);
 	 		    expDateTime = dateFormat.format(cal.getTime());
 	        
 	        
 		    //get current date time with Calendar()
 		    Calendar cal = Calendar.getInstance();
 		    Long curDate = cal.getTimeInMillis();
 		    String curDateTime = dateFormat.format(curDate);
			
			// add 1 month to get the expireTime
			cal.add(Calendar.MONTH, 1);
		    long expDate = cal.getTimeInMillis();
 		    String expDateTime = dateFormat.format(expDate);
*/
			
			// get properties related to data parts in Description elements
			int total = new Integer(xmlElemsProps.getProperty("totalDataPartsInDescriptionElement").trim()).intValue();
			int start = new Integer(xmlElemsProps.getProperty("startingDataPart").trim()).intValue();
			int end = new Integer(xmlElemsProps.getProperty("endingDataPart").trim()).intValue();

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Total data parts in Description element : " + total));
				LOGGER.debug(new StringBuffer("Starting data parts in Description element : " + start));
				LOGGER.debug(new StringBuffer("Ending data parts in Description element : " + end));
			}
			
			//

			isMgrHubOnTestRun = (new Boolean(mgrHubProps.getProperty("isMgrHubOnTestRun")).booleanValue());
			LOGGER.info("isMgrHubOnTestRun: " + isMgrHubOnTestRun);
			
			// build XML file
			try {

				DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
				DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

				// root elements - mhTasks
				doc = docBuilder.newDocument();
				Element rootElement = doc.createElement(xmlElemsProps.getProperty("mhTasks.elementNode").trim());
				doc.appendChild(rootElement);
/*
				// Comments element for control elements
				Comment controlComment = doc.createComment("control");
				rootElement.appendChild(controlComment);
*/				
				// control elements
				Element control = doc.createElement(xmlElemsProps.getProperty("mhTasks.control.elementNode").trim());
				rootElement.appendChild(control);

				// source elements
				Element source = doc.createElement(xmlElemsProps.getProperty("mhTasks.control.source.elementNode").trim());
				source.appendChild(doc.createTextNode(xmlElemsProps.getProperty("mhTasks.control.source.data").trim()));
				control.appendChild(source);

				// sequence elements
				Element sequence = doc.createElement(xmlElemsProps.getProperty("mhTasks.control.sequence.elementNode").trim());
				// append correct sequence id
				if (isMgrHubOnTestRun) {
					// append sequence id for TEST server
					sequence.appendChild(doc.createTextNode(xmlElemsProps.getProperty("mhTasks.control.sequence.data.testserver").trim()));
				} else {
					// append sequence id for PROD server
					sequence.appendChild(doc.createTextNode(xmlElemsProps.getProperty("mhTasks.control.sequence.data.prodserver").trim()));
				}
				control.appendChild(sequence);

				// entries elements
				Element entries = doc.createElement(xmlElemsProps.getProperty("mhTasks.entries.elementNode").trim());
				rootElement.appendChild(entries);
				
/*				
				// set attribute to staff element
				Attr attr = doc.createAttribute("id");
				attr.setValue("1");
				staff.setAttributeNode(attr);

				// shorten way
				// staff.setAttribute("id", "1");

				// firstname elements
				Element firstname = doc.createElement("firstname");
				firstname.appendChild(doc.createTextNode("yong"));
				staff.appendChild(firstname);

				// salary elements
				Element salary = doc.createElement("salary");
				salary.appendChild(doc.createTextNode("100000"));
				staff.appendChild(salary);
*/
				// create entry element for each MGRCNUM record in the result set
				while (rs.next()) {
					
					// get Mgr CNUM from LDRCNUM
//					String mgrCnumStr = rs.getString("MGRCNUM").trim();
					String mgrCnumStr = rs.getString("LDRCNUM").trim();
					
					
					
/********TEST ONLY - REMOVE before PROD 				
					if (mgrCnumStr.equalsIgnoreCase("2G8065897")) 
						mgrCnumStr = "788681897";
					else if (mgrCnumStr.equalsIgnoreCase("808936897")) 
						mgrCnumStr = "438377897";
					else if (mgrCnumStr.equalsIgnoreCase("594754897")) 
						mgrCnumStr = "C-DGL9897";
**********************/
					
//					if (mgrCnumStr.equalsIgnoreCase("557603897")) {
											
					// entry elements
					Element entry = doc.createElement(xmlElemsProps.getProperty("mhTasks.entries.entry.elementNode").trim());
					entries.appendChild(entry);

					// appId elements
					Element appId = doc.createElement(xmlElemsProps.getProperty("mhTasks.entries.entry.appId.elementNode").trim());
					appId.appendChild(doc.createTextNode(xmlElemsProps.getProperty("mhTasks.entries.entry.appId.data").trim()));
					entry.appendChild(appId);

					// uniqueId elements
					Element uniqueId = doc.createElement(xmlElemsProps.getProperty("mhTasks.entries.entry.uniqueId.elementNode").trim());
					uniqueId.appendChild(doc.createTextNode(processMonth + "-" + mgrCnumStr));
					entry.appendChild(uniqueId);

					// categoryId elements
					Element categoryId = doc.createElement(xmlElemsProps.getProperty("mhTasks.entries.entry.categoryId.elementNode").trim());
					categoryId.appendChild(doc.createTextNode(xmlElemsProps.getProperty("mhTasks.entries.entry.categoryId.data").trim()));
					entry.appendChild(categoryId);

					// ownerCnum elements
					Element ownerCnum = doc.createElement(xmlElemsProps.getProperty("mhTasks.entries.entry.ownerCnum.elementNode").trim());
					ownerCnum.appendChild(doc.createTextNode(mgrCnumStr));
					entry.appendChild(ownerCnum);

					// empCnum elements
					String empCnumStr = xmlElemsProps.getProperty("mhTasks.entries.entry.empCnum.data").trim();
					if ((empCnumStr != null) && (empCnumStr.length() > 0)) {
						Element empCnum = doc.createElement(xmlElemsProps.getProperty("mhTasks.entries.entry.empCnum.elementNode").trim());
						empCnum.appendChild(doc.createTextNode(empCnumStr));
						entry.appendChild(empCnum);
					}

					// type elements
					Element type = doc.createElement(xmlElemsProps.getProperty("mhTasks.entries.entry.type.elementNode").trim());
					type.appendChild(doc.createTextNode(xmlElemsProps.getProperty("mhTasks.entries.entry.type.data").trim()));
					entry.appendChild(type);

					// state elements
					Element state = doc.createElement(xmlElemsProps.getProperty("mhTasks.entries.entry.state.elementNode").trim());
					state.appendChild(doc.createTextNode(xmlElemsProps.getProperty("mhTasks.entries.entry.state.data").trim()));
					entry.appendChild(state);

					// get # of Non-Compliant employees for this mgr cnum
					int numberofNonCompliants = new Integer(rs.getString("NUMBEROFNONCOMPLIANTS").trim()).intValue();

					if (mgrCnumStr.equalsIgnoreCase("032096649")) {
						LOGGER.debug(new StringBuffer("LDRCNUM = ").append(mgrCnumStr));
						LOGGER.debug(new StringBuffer("numberofNonCompliants = ").append(numberofNonCompliants));
					}

					// title elements
					Element title = doc.createElement(xmlElemsProps.getProperty("mhTasks.entries.entry.title.elementNode").trim());
					title.appendChild(doc.createTextNode(numberofNonCompliants + " " + 
										xmlElemsProps.getProperty("mhTasks.entries.entry.title.data1").trim() + 
										xmlElemsProps.getProperty("mhTasks.entries.entry.title.data2").trim()));
					entry.appendChild(title);

					String desc = xmlElemsProps.getProperty("mhTasks.entries.entry.description.data1").trim() +
							xmlElemsProps.getProperty("mhTasks.entries.entry.description.data2").trim() +
							xmlElemsProps.getProperty("mhTasks.entries.entry.description.data3").trim() + 
							xmlElemsProps.getProperty("mhTasks.entries.entry.description.data4").trim() + 
							xmlElemsProps.getProperty("mhTasks.entries.entry.description.data5").trim() + 
							month.trim() + ", " + year.trim() +
							xmlElemsProps.getProperty("mhTasks.entries.entry.description.data6").trim() +
							xmlElemsProps.getProperty("mhTasks.entries.entry.description.data7").trim() +
							numberofNonCompliants + " " +
							xmlElemsProps.getProperty("mhTasks.entries.entry.description.data8").trim(); 
					
					for (int i=start; i <= end; i++) {
						// description data parts
						String descDataPart = "mhTasks.entries.entry.description.data" + i;
						desc = desc + xmlElemsProps.getProperty(descDataPart).trim();
					}

					
					String newDesc = "";
					String tempDesc = "";
					int startPosition = 124;
					int testPosition = 124;
/*
					int startPosition = 129;
					int testPosition = 129;

					if (isTestRun) {
						LOGGER.debug(new StringBuffer("ORIG DESCRIPTION : " + desc));
						LOGGER.debug(new StringBuffer("desc.length : " + desc.length()));
					}
*/					
					while (desc.length() >= startPosition) {
//						LOGGER.debug(new StringBuffer("testPosition : " + testPosition));
						while (!Character.isWhitespace(desc.charAt(testPosition))) {
							testPosition = testPosition - 1;						
						}
//						LOGGER.debug(new StringBuffer("testPos : " + testPosition));

						tempDesc = tempDesc + desc.substring(0, testPosition) + System.getProperty("line.separator");
						desc = desc.substring(testPosition);
//						testPosition = startPosition + testPosition;
						testPosition = 124;
/*
						testPosition = 129;

						if (isTestRun) {
							LOGGER.debug(new StringBuffer("TEMP DESCRIPTION : " + tempDesc));
							LOGGER.debug(new StringBuffer("REMAINING DESCRIPTION : " + desc));
							LOGGER.debug(new StringBuffer("desc.length : " + desc.length()));
						}
*/
					}
					tempDesc = tempDesc + desc.substring(0);

//					LOGGER.debug(new StringBuffer("COMPLETE TEMP DESCRIPTION : " + tempDesc));

					newDesc = tempDesc.substring(9, tempDesc.length()-3);
//					LOGGER.debug(new StringBuffer("COMPLETE NEW DESCRIPTION : " + newDesc));

					Element description = doc.createElement(xmlElemsProps.getProperty("mhTasks.entries.entry.description.elementNode").trim());
					description.appendChild(doc.createCDATASection(newDesc));
//					description.appendChild(doc.createTextNode(newDesc));
					entry.appendChild(description);

					// warningTime elements
					String warningTimeStr = xmlElemsProps.getProperty("mhTasks.entries.entry.warningTime.data").trim();
					if ((warningTimeStr != null) && (warningTimeStr.length() > 0)) {
						Element warningTime = doc.createElement(xmlElemsProps.getProperty("mhTasks.entries.entry.warningTime.elementNode").trim());
						warningTime.appendChild(doc.createTextNode(warningTimeStr));
						entry.appendChild(warningTime);
					}

					// errorTime elements
					String errorTimeStr = xmlElemsProps.getProperty("mhTasks.entries.entry.errorTime.data").trim();
					if ((errorTimeStr != null) && (errorTimeStr.length() > 0)) {
						Element errorTime = doc.createElement(xmlElemsProps.getProperty("mhTasks.entries.entry.errorTime.elementNode").trim());
						errorTime.appendChild(doc.createTextNode(errorTimeStr));
						entry.appendChild(errorTime);
					}

					// expireTime elements
					String expireTimeStr = xmlElemsProps.getProperty("mhTasks.entries.entry.expireTime.data").trim();
					if ((expireTimeStr != null) && (expireTimeStr.length() > 0)) {
						Element expireTime = doc.createElement(xmlElemsProps.getProperty("mhTasks.entries.entry.expireTime.elementNode").trim());
						expireTime.appendChild(doc.createTextNode(expireTimeStr));
//						expireTime.appendChild(doc.createTextNode(expDateTime));
						entry.appendChild(expireTime);
					}

					// actions elements
					Element actions = doc.createElement(xmlElemsProps.getProperty("mhTasks.entries.entry.actions.elementNode").trim());
					entry.appendChild(actions);

					// set attribute "count" to actions element 
					// Number of action buttons to display in addition to DISMISS button which is default
					String totalActions = xmlElemsProps.getProperty("mhTasks.entries.entry.actions.count.data").trim();
					int count = new Integer(totalActions).intValue();
					Attr attrCount = doc.createAttribute(xmlElemsProps.getProperty("mhTasks.entries.entry.actions.count.attribute").trim());
					attrCount.setValue(totalActions);
					actions.setAttributeNode(attrCount);
					
					for (int i=1; i <= count; i++) {
						// action elements
						Element action = doc.createElement(xmlElemsProps.getProperty("mhTasks.entries.entry.actions.action.elementNode").trim());
						actions.appendChild(action);

						// actionType elements
						String actionTypeProp = "mhTasks.entries.entry.actions.action" + i + ".actionType.data";
						Element actionType = doc.createElement(xmlElemsProps.getProperty("mhTasks.entries.entry.actions.action.actionType.elementNode").trim());
						actionType.appendChild(doc.createTextNode(xmlElemsProps.getProperty(actionTypeProp).trim()));
						action.appendChild(actionType);

						// label elements
						String actionlabelProp = "mhTasks.entries.entry.actions.action" + i + ".label.data";
						Element label = doc.createElement(xmlElemsProps.getProperty("mhTasks.entries.entry.actions.action.label.elementNode").trim());
						label.appendChild(doc.createTextNode(xmlElemsProps.getProperty(actionlabelProp).trim()));
//						label.appendChild(doc.createTextNode(xmlElemsProps.getProperty("mhTasks.entries.entry.actions.action.label.data").trim()));
						action.appendChild(label);

						// url elements
						String actionUrlProp = "mhTasks.entries.entry.actions.action" + i + ".url.data";
						Element url = doc.createElement(xmlElemsProps.getProperty("mhTasks.entries.entry.actions.action.url.elementNode").trim());
						url.appendChild(doc.createTextNode(xmlElemsProps.getProperty(actionUrlProp).trim()));
//						url.appendChild(doc.createTextNode(xmlElemsProps.getProperty(actionUrlProp+"1").trim()));
/*						
						if ((xmlElemsProps.getProperty(actionUrlProp+"2") != null) &&
							(xmlElemsProps.getProperty(actionUrlProp+"2").trim().length() > 0 )) {

							url.appendChild(doc.createTextNode(System.getProperty("line.separator")));
							url.appendChild(doc.createTextNode(xmlElemsProps.getProperty(actionUrlProp+"2").trim()));
						}
*/						
//						url.appendChild(doc.createTextNode(xmlElemsProps.getProperty("mhTasks.entries.entry.actions.action.url.data").trim()));
						action.appendChild(url);
					}
				}
					
//				}  // Remove this ... if   557603897
				
			} catch (ParserConfigurationException pce) {
				pce.printStackTrace();
			}			
					
			// Connection must be on a unit-of-work boundary to allow close
			if (con != null) {
				con.commit();
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Total Transaction(s) committed = ").append(totalMgrs));
			}

		} catch (SQLException e) {
			LOGGER.error(new StringBuffer("Exception caught while getting base compliance records from table "+ e.getMessage()));
			e.printStackTrace();
			return doc;
			
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
				}//end catch
			}//end if
			
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing Statement. Resources might not be released ", e);
				}//end catch
			}//end if
		}//end finally
	
		if (isTestRun) {
			LOGGER.debug(new StringBuffer("Exiting MgrHubDAO::buildXMLDoc() ============>"));
		}

		return doc;
	}


	/**
	 * Builds XML file from Manager Hub data
	 * @return
	 */
	public int buildXMLFile(Document xmlDoc, Properties mgrHubProps){
			
		int RC = 0;

		String mgrHubXMLDirLocal = null;
		String mgrHubXMLFileLocal = null;
		String mgrHubXMLFileLocalTemp = null;

		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering MgrHubDAO::buildXMLFile() <============"));

		// build XML file from XML doc
		try {

			// retrieve local XML file directory from properties
			mgrHubXMLDirLocal = mgrHubProps.getProperty("mgrHubXMLDirLocal");
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Manager Hub XML dir = ").append(mgrHubXMLDirLocal));
			}
				 
			// if the directory does not exist, create it
			File mHubXMLDirLocal = new File(mgrHubXMLDirLocal);
			if (!mHubXMLDirLocal.exists()) {
				if (isTestRun) {
					LOGGER.debug(new StringBuffer("XML dir does not exist. Creating XML dir = ").append(mgrHubXMLDirLocal));
				}

				mHubXMLDirLocal.mkdir();
				if (isTestRun) {
					LOGGER.debug(new StringBuffer("Created XML dir = ").append(mHubXMLDirLocal));
				}
			} else {
				if (isTestRun) {
					LOGGER.debug(new StringBuffer("XML dir = ").append(mHubXMLDirLocal).append(" exists"));
				}
				
			}

			// retrieve local XML file name from properties
			mgrHubXMLFileLocal = mgrHubXMLDirLocal + mgrHubProps.getProperty("mgrHubXMLFileLocal");
			// build local XML (Temp) file name from properties
			mgrHubXMLFileLocalTemp = mgrHubXMLDirLocal + mgrHubProps.getProperty("mgrHubXMLFileLocalTemp");

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Manager Hub XML File Name = ").append(mgrHubXMLFileLocal));
				LOGGER.debug(new StringBuffer("Manager Hub XML File Name(Temp) = ").append(mgrHubXMLFileLocalTemp));
			}

			// if the XML file exists, delete it
			File mHubXMLFileLocalOld = new File(mgrHubXMLFileLocal);
			if (mHubXMLFileLocalOld.exists()) {
				if (isTestRun) {
					LOGGER.debug(new StringBuffer("XML File exists. Deleting XML file = ").append(mgrHubXMLFileLocal));
				}

				mHubXMLFileLocalOld.delete();
				if (isTestRun) {
					LOGGER.debug(new StringBuffer("Deleted XML file = ").append(mgrHubXMLFileLocal));
				}
			}

			// if the Temp XML file exists, delete it
			File mHubXMLFileLocalTempOld = new File(mgrHubXMLFileLocalTemp);
			if (mHubXMLFileLocalTempOld.exists()) {
				if (isTestRun) {
					LOGGER.debug(new StringBuffer("XML File exists. Deleting XML file = ").append(mgrHubXMLFileLocalTemp));
				}

				mHubXMLFileLocalTempOld.delete();
				if (isTestRun) {
					LOGGER.debug(new StringBuffer("Deleted XML file = ").append(mgrHubXMLFileLocalTemp));
				}
			}

			// create a new XML file
//			File mHubXMLFileLocalNew = new File(mgrHubXMLFileLocal);

			// create a new XML file (Temp)
			File mHubXMLFileLocalTempNew = new File(mgrHubXMLFileLocalTemp);
				
			// write the content into xml file
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			DOMSource domSource = new DOMSource(xmlDoc);
			
			StreamResult result = new StreamResult(mHubXMLFileLocalTempNew);
//			StreamResult result = new StreamResult(new File("C:\\file.xml"));

			// Output to console for testing
//			StreamResult result = new StreamResult(System.out);

			transformer.transform(domSource, result);
						
			if (isTestRun) {
				 LOGGER.debug(new StringBuffer("Saved Temporary Manager Hub XML File in = ").append(mgrHubXMLFileLocalTemp));
				 LOGGER.debug(new StringBuffer("Starting workaround to add space before <action> elements..."));
				 LOGGER.debug(new StringBuffer("Reading from " + mgrHubXMLFileLocalTemp + " and writing into " + mgrHubXMLFileLocal));
			}
				
			// Construct file input and output streams
			FileInputStream fis = new FileInputStream(mgrHubXMLFileLocalTemp);
			FileOutputStream fos = new FileOutputStream(mgrHubXMLFileLocal);
			 
			// Construct BufferedReaders 
			BufferedReader br = new BufferedReader(new InputStreamReader(fis));
			BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		 
			String line = null;
			while ((line = br.readLine()) != null) {
				if ( (line.startsWith("<action>")) || 
  					 (line.startsWith("<actionType>")) ||	
  					 (line.startsWith("<label>")) ||	
  					 (line.startsWith("<url>")) ||	
  					 (line.startsWith("</action>")) ) {

					line = " " + line;
				}
//				System.out.println(line);
				bw.write(line + "\n");
			}
		 
			br.close();
			bw.close();
			
			if (isTestRun) {
				 LOGGER.debug(new StringBuffer("Saved FINAL Manager Hub XML File = ").append(mgrHubXMLFileLocal));
			}

/*
			// create a new XML file
			File mHubXMLFileLocalNew = new File(mgrHubXMLFileLocal);

			// create a new XML file (Temp)
//			File mHubXMLFileLocalTempNew = new File(mgrHubXMLFileLocalTemp);
				
			// write the content into xml file
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			DOMSource domSource = new DOMSource(xmlDoc);
			
			StreamResult result = new StreamResult(mHubXMLFileLocalNew);
//			StreamResult result = new StreamResult(mHubXMLFileLocalTempNew);
//				StreamResult result = new StreamResult(new File("C:\\file.xml"));

			// Output to console for testing
//				StreamResult result = new StreamResult(System.out);

			transformer.transform(domSource, result);
			
			if (isTestRun) {
				 LOGGER.debug(new StringBuffer("Saved Manager Hub XML File = ").append(mHubXMLFileLocalNew));
			}
*/			
			
		
		} catch (TransformerException tfe) {
			LOGGER.error(new StringBuffer("Exception caught while transforming XML file from XML doc "+ tfe.getMessage()));
			tfe.printStackTrace();
			return -1;
		} catch (FileNotFoundException fnfe) {
			LOGGER.error(new StringBuffer("File Not found : "+ mgrHubXMLFileLocalTemp));
			fnfe.printStackTrace();
			return -1;
		} catch (IOException ioe) {
			LOGGER.error(new StringBuffer("File I/O Exception caught while building XML file from XML doc "+ioe.getMessage()));
			ioe.printStackTrace();
			return -1;
		} catch (Exception ex) {
			LOGGER.error(new StringBuffer("Exception caught while building XML file from XML doc "+ ex.getMessage()));
			ex.printStackTrace();
			return -1;
		}			

	
		if (isTestRun) {
			LOGGER.debug(new StringBuffer("Exiting MgrHubDAO::buildXMLFile() ============>"));
		}

		return RC;
	}

}
