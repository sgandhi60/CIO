package com.ibm.cio;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Vector;

import org.apache.log4j.Logger;

//public class PersonaKFRDAO extends BaseDAO{
public class PersonaWWERDAO{

	private Connection conn = null;
	private boolean isTestRun;
//	private Vector<String> cCodes = null;
	private Vector<String> cCodes = new Vector<String>(10, 10);
	private Vector<String> cCodesGCG = new Vector<String>(10, 10);
	private Vector<String> cCodesNonGCG = new Vector<String>(10, 10);
	private Vector cCodeStrs = null;

	private static Logger LOGGER = Logger.getLogger(PersonaWWERDAO.class);

	public PersonaWWERDAO(Connection connection, boolean testRun, Vector<String> countryCodes) {
		// initialization 
		conn = connection;
		isTestRun = testRun;
		cCodeStrs = countryCodes;
//		cCodes = countryCodes;

		int totalCountryCodes = cCodeStrs.size();
		
		for (int i=0; i < totalCountryCodes; i++) {
			String codeStr = (String)cCodeStrs.get(i);
			// Make a list of all CCs
			cCodes.add(codeStr.substring(0, 3));
			
			if (codeStr.substring(3).equals("Y")) {
				// Make a list of all GCG CCs
				cCodesGCG.add(codeStr.substring(0, 3));
			} else {
				// Make a list of all Non GCG CCs
				cCodesNonGCG.add(codeStr.substring(0, 3));
			}
		}

		LOGGER.info("Country Codes (ALL): ");			
		for (int i=0; i < cCodes.size(); i++) {
			LOGGER.info("countryCodeAll" + (i+1) + ": " + cCodes.get(i));				
		}

		LOGGER.info("Country Codes (NonGCG): ");			
		for (int i=0; i < cCodesNonGCG.size(); i++) {
			LOGGER.info("countryCodeNonGCG" + (i+1) + ": " + cCodesNonGCG.get(i));				
		}

		LOGGER.info("Country Codes (GCG): ");			
		for (int i=0; i < cCodesGCG.size(); i++) {
			LOGGER.info("countryCodeGCG" + (i+1) + ": " + cCodesGCG.get(i));				
		}

		if (isTestRun)
			LOGGER.debug(new StringBuffer("Created PersonaWWERDAO object successfully"));
	}


	
	/**
	 * Deletes records
	 * @return
	 */
	public int deleteRecords(){
		
		String query = null;
		PreparedStatement stmt = null;
		int result = -1;

		
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaWWERDAO::deleteRecords() <============"));
		
		try {

			// invoke DELETE query to clean up the table
			query = SQLQuery.getQuery(SQLQuery.PERSONA_WWER_DELETE);
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.prepareStatement(query);

			result = stmt.executeUpdate();

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Deleted ").append(result).append(" record(s)"));
			}

			// Close the Statement
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing PreparedStatement. Resources might not be released ", e);
				}//end catch
			}
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Exiting PersonaWWERDAO::deleteRecords() ============>"));
			}
			
			return result;
			
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer("Exception caught attempting to delete records from table " + e.getMessage()));
		      e.printStackTrace();
		      return -1;
		}
	}

	
	/**
	 * Inserts records
	 * @return
	 */
	public int insertRecords(){
			
		String query = null;
		PreparedStatement stmt = null;
		int result = -1;
		String cCodesStr = "'";
		
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaWWERDAO::insertRecords() <============"));
		
		try {

			int totalCountryCodes = cCodes.size();

			for (int i=0; i < totalCountryCodes; i++) {
				cCodesStr = cCodesStr + cCodes.get(i) + "'" ;
				if ( i < totalCountryCodes-1 )
					cCodesStr = cCodesStr + ",'" ;
			}
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Country Codes String: ").append(cCodesStr));

			// invoke INSERT query to populate the table
			query = SQLQuery.getQuery(SQLQuery.PERSONA_WWER_INSERT) + 
					cCodesStr + 
					SQLQuery.getQuery(SQLQuery.PERSONA_WWER_INSERT1);
			 
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.prepareStatement(query);

			result = stmt.executeUpdate();

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Inserted ").append(result).append(" record(s)"));
			}

			// Close the Statement
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing PreparedStatement. Resources might not be released ", e);
				}//end catch
			}
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Exiting PersonaWWERDAO::insertRecords() ============>"));
			}
				
			return result;
			
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer("Exception caught attempting to insert record into table " + e.getMessage()));
		      e.printStackTrace();
		      return -1;
		}
	}
	
	/**
	 * Deletes records
	 * @return
	 */
	public int deleteGroupedRecords(){
		
		String query = null;
		PreparedStatement stmt = null;
		int result = -1;

		
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaWWERDAO::deleteGroupedRecords() <============"));
		
		try {

			// invoke DELETE query to clean up the table
			query = SQLQuery.getQuery(SQLQuery.PERSONA_WWER_DELETE2);
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.prepareStatement(query);

			result = stmt.executeUpdate();

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Deleted ").append(result).append(" record(s)"));
			}

			// Close the Statement
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing PreparedStatement. Resources might not be released ", e);
				}//end catch
			}
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Exiting PersonaWWERDAO::deleteGroupedRecords() ============>"));
			}
			
			return result;
			
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer("Exception caught attempting to delete records from table " + e.getMessage()));
		      e.printStackTrace();
		      return -1;
		}
	}

	
	/**
	 * Inserts records
	 * @return
	 */
	public int insertGroupedRecords(){
			
		String query = null;
		PreparedStatement stmt = null;
		int result = -1;
		String cCodesStr = "'";
		
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaWWERDAO::insertGroupedRecords() <============"));
		
		try {

			int totalCountryCodes = cCodes.size();

			for (int i=0; i < totalCountryCodes; i++) {
				cCodesStr = cCodesStr + cCodes.get(i) + "'" ;
				if ( i < totalCountryCodes-1 )
					cCodesStr = cCodesStr + ",'" ;
			}
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Country Codes String: ").append(cCodesStr));

			// invoke INSERT query to populate the table
			query = SQLQuery.getQuery(SQLQuery.PERSONA_WWER_INSERT2);
			 
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.prepareStatement(query);

			result = stmt.executeUpdate();

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Inserted ").append(result).append(" record(s)"));
			}

			// Close the Statement
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing PreparedStatement. Resources might not be released ", e);
				}//end catch
			}
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Exiting PersonaWWERDAO::insertGroupedRecords() ============>"));
			}
				
			return result;
			
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer("Exception caught attempting to insert record into table " + e.getMessage()));
			e.printStackTrace();
			return -1;
		}
	}
	
	
	/**
	 * Deletes records
	 * @return
	 */
	public int deleteGroupedRecords3(){
		
		String query = null;
		PreparedStatement stmt = null;
		int result = -1;

		
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaWWERDAO::deleteGroupedRecords3() <============"));
		
		try {

			// invoke DELETE query to clean up the table
			query = SQLQuery.getQuery(SQLQuery.PERSONA_WWER_DELETE3);
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.prepareStatement(query);

			result = stmt.executeUpdate();

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Deleted ").append(result).append(" record(s)"));
			}

			// Close the Statement
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing PreparedStatement. Resources might not be released ", e);
				}//end catch
			}
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Exiting PersonaWWERDAO::deleteGroupedRecords3() ============>"));
			}
			
			return result;
			
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer("Exception caught attempting to delete records from table " + e.getMessage()));
		      e.printStackTrace();
		      return -1;
		}
	}

	
	/**
	 * Inserts records
	 * @return
	 */
	public int insertGroupedRecords3(){
			
		String query = null;
		PreparedStatement stmt = null;
		int result = -1;
		String cCodesStr = "'";
		
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaWWERDAO::insertGroupedRecords3() <============"));
		
		try {

			int totalCountryCodes = cCodes.size();

			for (int i=0; i < totalCountryCodes; i++) {
				cCodesStr = cCodesStr + cCodes.get(i) + "'" ;
				if ( i < totalCountryCodes-1 )
					cCodesStr = cCodesStr + ",'" ;
			}
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Country Codes String: ").append(cCodesStr));

			// invoke INSERT query to populate the table
			query = SQLQuery.getQuery(SQLQuery.PERSONA_WWER_INSERT3);
			 
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.prepareStatement(query);

			result = stmt.executeUpdate();

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Inserted ").append(result).append(" record(s)"));
			}

			// Close the Statement
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing PreparedStatement. Resources might not be released ", e);
				}//end catch
			}
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Exiting PersonaWWERDAO::insertGroupedRecords3() ============>"));
			}
				
			return result;
			
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer("Exception caught attempting to insert record into table " + e.getMessage()));
			e.printStackTrace();
			return -1;
		}
	}
	
}
