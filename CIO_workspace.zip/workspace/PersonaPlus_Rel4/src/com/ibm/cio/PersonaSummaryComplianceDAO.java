package com.ibm.cio;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import org.apache.log4j.Logger;

public class PersonaSummaryComplianceDAO{

	private Connection conn = null;
	private boolean isTestRun;

	private static Logger LOGGER = Logger.getLogger(PersonaSummaryComplianceDAO.class);

	public PersonaSummaryComplianceDAO(Connection connection, boolean testRun) {
		// initialization 
		conn = connection;
		isTestRun = testRun;

		if (isTestRun)
			LOGGER.debug(new StringBuffer("Created PersonaSummaryComplianceDAO object successfully"));

	}


	
	/**
	 * Deletes records
	 * @return
	 */
	public int deletePreSumaryCompliaceRecords(){
		
		String query = null;
		PreparedStatement stmt = null;
		int result = -1;

		
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaSummaryComplianceDAO::deletePreSumaryCompliaceRecords() <============"));
		
		try {

			// invoke DELETE query to clean up the table
			query = SQLQuery.getQuery(SQLQuery.PERSONA_PRESUMMARY_COMPLIANCE_DELETE);
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.prepareStatement(query);

			result = stmt.executeUpdate();

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Deleted ").append(result).append(" record(s)"));
			}

			// Close the Statement
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing PreparedStatement. Resources might not be released ", e);
				}//end catch
			}
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Exiting PersonaSummaryComplianceDAO::deletePreSumaryCompliaceRecords() ============>"));
			}

			return result;
			
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer("Exception caught attempting to delete records from table " + e.getMessage()));
		      e.printStackTrace();
		      return -1;
		}
	}

	
	/**
	 * Inserts PreSumaryCompliace records
	 * @return
	 */
	public int insertPreSumaryCompliaceRecords(){
			
		String query = null;
		PreparedStatement stmt = null;
		int result = -1;

		
		if (isTestRun) {
			LOGGER.debug(new StringBuffer("Entering PersonaSummaryComplianceDAO::insertPreSumaryCompliaceRecords() <============"));
		}
		
		try {

			// invoke INSERT query to populate the table
			query = SQLQuery.getQuery(SQLQuery.PERSONA_PRESUMMARY_COMPLIANCE_INSERT);
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.prepareStatement(query);

			result = stmt.executeUpdate();

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Inserted ").append(result).append(" record(s)"));
			}

			// Close the Statement
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing PreparedStatement. Resources might not be released ", e);
				}//end catch
			}
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Exiting PersonaSummaryComplianceDAO::insertPreSumaryCompliaceRecords() ============>"));
			}

			return result;
			
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer("Exception caught attempting to insert record into table " + e.getMessage()));
		    e.printStackTrace();
		    return -1;
		}
	}

	public int buildSvcTypeBasedSummaryComplianceData(String serviceType, Properties props, Properties colNamesProps){
		
		String query = null;
		Statement stmt = null;
        ResultSet rs = null;
		int totalEmps = 0;
		int counter = 0;
		String cnum = "";
		
		// Initialize Summary Compliance related fields 
		// (required to do it here so we can use in "catch" block)
		String compliance = "";
		String nc_Multi = "";
		String nc_Service = "";
		String nc_Explanation = "";
		Double wwer_USD = 0.0;
		int wwer_Count = 0;
		Double cmp_USD = 0.0;
		int cmp_Count = 0;
		Double ofc_SUT_USD = 0.0;
		int ofc_SUT_Count = 0;
		Double total_USD = 0.0;
		int total_Count = 0;
		Double wwer_LC = 0.0;
		Double cmp_LC = 0.0;
		Double ofc_SUT_LC = 0.0;
		Double total_LC = 0.0;
		String filter = "No";
		Double clip_Lvl = 0.0;
		String combinations = "";
				
		
		if (isTestRun) {
			LOGGER.debug(new StringBuffer("Entering PersonaComplianceDAO::buildSvcTypeBasedSummaryComplianceData() <============"));
			LOGGER.debug(new StringBuffer("Start --- Building Summary Compliance Records for ServiceType = " + serviceType));
		}
		try {
			// invoke SELECT query to retrieve employee base data from the table
			query = SQLQuery.getQuery(SQLQuery.PERSONA_PRESUMMARY_COMPLIANCE_SELECT);
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
		    
 			rs = stmt.executeQuery(query);
 
 			if (rs!=null){
				if(rs.last()){
					totalEmps = rs.getRow(); 
				    rs.beforeFirst();
				}
			
				if (isTestRun) {
					LOGGER.debug(new StringBuffer("Total # of employee records: ").append(totalEmps));
				}

				if (totalEmps <= 0 ) {
					LOGGER.error(new StringBuffer("No employee records exist in PRESUMMARY_COMPLIANCE table "));
					return -1;
				}
			}else{
				//no result set retrieved
				if (isTestRun) {
					LOGGER.debug(new StringBuffer("No records found in PRESUMMARY_COMPLIANCE table "));
				}
				return -1;
 			}	

			while (rs.next()) {
				
				// initialize before processing each record
				compliance = "";
				nc_Multi = "";
				nc_Service = "";
				nc_Explanation = "";
				wwer_USD = 0.0;
				wwer_Count = 0;
				cmp_USD = 0.0;
				cmp_Count = 0;
				ofc_SUT_USD = 0.0;
				ofc_SUT_Count = 0;
				total_USD = 0.0;
				total_Count = 0;
				wwer_LC = 0.0;
				cmp_LC = 0.0;
				ofc_SUT_LC = 0.0;
				total_LC = 0.0;
				filter = "No";
				clip_Lvl = 0.0;
				combinations = "";

				counter = counter + 1;
				cnum = rs.getString(colNamesProps.getProperty("stage1_CNUM").trim());
				
				// compliance
				if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.SMARTPHONE").trim())) {
					compliance = rs.getString(colNamesProps.getProperty("stage9_SMARTPHONECOMPLIANCE").trim());
					
				} else if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.BASICCELL").trim())) {
					compliance = rs.getString(colNamesProps.getProperty("stage9_CELLPHONECOMPLIANCE").trim());
					
				} else if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.HOMEOFFICEVOICE").trim())) {
					compliance = rs.getString(colNamesProps.getProperty("stage9_HOMEOFFICEVOICECOMPLIANCE").trim());
					
				} else if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.DATACARD").trim())) {
					compliance = rs.getString(colNamesProps.getProperty("stage9_DATACARDCOMPLIANCE").trim());
					
				} else if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.ALLSERVICES").trim())) {
					compliance = rs.getString(colNamesProps.getProperty("stage10_OVERALLCOMPLIANCE").trim());
					
				} // End compliance 				
				
				
				
				// nc_Multi
				if ( (serviceType.equalsIgnoreCase(props.getProperty("serviceType.SMARTPHONE").trim())) ||
				     (serviceType.equalsIgnoreCase(props.getProperty("serviceType.BASICCELL").trim())) ||
				     (serviceType.equalsIgnoreCase(props.getProperty("serviceType.HOMEOFFICEVOICE").trim())) ||
				     (serviceType.equalsIgnoreCase(props.getProperty("serviceType.DATACARD").trim())) ) {
					
					nc_Multi = rs.getString(colNamesProps.getProperty("stage10_EXPLANATION1MULTI").trim()) + " " +
							   rs.getString(colNamesProps.getProperty("stage10_EXPLANATION1BMULTI").trim());
				} // End NC_Multi 				
					
				
				
				// nc_Service
				if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.SMARTPHONE").trim())) {					
					nc_Service = rs.getString(colNamesProps.getProperty("stage10_EXPLANATION2BSMARTPHONE").trim());
					
				} else if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.BASICCELL").trim())) {
					nc_Service = rs.getString(colNamesProps.getProperty("stage10_EXPLANATION3BCELL").trim());
					
				} else if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.HOMEOFFICEVOICE").trim())) {
					nc_Service = rs.getString(colNamesProps.getProperty("stage10_EXPLANATION5BHOV").trim());
					
				} else if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.DATACARD").trim())) {
					nc_Service = rs.getString(colNamesProps.getProperty("stage10_EXPLANATION4BDATACARD").trim());

				} // End NC_Service 				
				
				
				
				// nc_Explanation
				if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.ALLSERVICES").trim())) {					
					nc_Explanation = rs.getString(colNamesProps.getProperty("stage11_SUMMARYOFNONCOMPLIANTEXPLANATION").trim());
				} // End NC_Explanation 				
					
				
				
				// wwer_USD
				if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.SMARTPHONE").trim())) {					
					wwer_USD = rs.getDouble(colNamesProps.getProperty("stage7_SMARTPHONEWWER").trim());
					
				} else if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.BASICCELL").trim())) {
					wwer_USD = rs.getDouble(colNamesProps.getProperty("stage7_BASICCELLWWER").trim());
					
				} else if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.HOMEOFFICEVOICE").trim())) {
					wwer_USD = rs.getDouble(colNamesProps.getProperty("stage7_HOMEVOICEWWER").trim());
					
				} else if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.DATACARD").trim())) {
					wwer_USD = rs.getDouble(colNamesProps.getProperty("stage7_DATACARDWWER").trim());
				
				} else if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.HOMEINTERNET").trim())) {
					wwer_USD = rs.getDouble(colNamesProps.getProperty("stage7_HOMEINTERNETWWER").trim());
				
				} else if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.CALLINGCARD").trim())) {
					wwer_USD = rs.getDouble(colNamesProps.getProperty("stage7_CALLINGCARD").trim());
				
				} else if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.CONFERENCING").trim())) {
					wwer_USD = rs.getDouble(colNamesProps.getProperty("stage7_CONFERENCING").trim());
				
				} else if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.HOTELINTERNET").trim())) {
					wwer_USD = rs.getDouble(colNamesProps.getProperty("stage7_HOTELINTERNET").trim());
				
				} else if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.HOTELTELEPHONE").trim())) {
					wwer_USD = rs.getDouble(colNamesProps.getProperty("stage7_HOTELTELEPHONE").trim());
				
				} else if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.UNCLASSFIED").trim())) {
					wwer_USD = rs.getDouble(colNamesProps.getProperty("stage7_UNCLASSIFIED").trim());
				
				} else if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.TABLET").trim())) {
					wwer_USD = rs.getDouble(colNamesProps.getProperty("stage7_TABLETWWER").trim());
				
				} else if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.ALLSERVICES").trim())) {
					wwer_USD = rs.getDouble(colNamesProps.getProperty("stage7_SMARTPHONEWWER").trim()) +
							   rs.getDouble(colNamesProps.getProperty("stage7_BASICCELLWWER").trim()) +
							   rs.getDouble(colNamesProps.getProperty("stage7_HOMEVOICEWWER").trim()) +
							   rs.getDouble(colNamesProps.getProperty("stage7_DATACARDWWER").trim()) +
							   rs.getDouble(colNamesProps.getProperty("stage7_HOMEINTERNETWWER").trim()) +
							   rs.getDouble(colNamesProps.getProperty("stage7_CALLINGCARD").trim()) +
							   rs.getDouble(colNamesProps.getProperty("stage7_CONFERENCING").trim()) +
							   rs.getDouble(colNamesProps.getProperty("stage7_HOTELINTERNET").trim()) +
							   rs.getDouble(colNamesProps.getProperty("stage7_HOTELTELEPHONE").trim()) +
							   rs.getDouble(colNamesProps.getProperty("stage7_UNCLASSIFIED").trim()) +
							   rs.getDouble(colNamesProps.getProperty("stage7_TABLETWWER").trim());
				
				} // End WWER_USD 				
				
				
				
				// wwer_Count
				if ( (wwer_USD < 0) || (wwer_USD > 0) ) {
					wwer_Count = 1;
				} else {
					wwer_Count = 0;
				} // End WWER_Count 			

				
				
				// cmp_USD
				if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.SMARTPHONE").trim())) {					
					cmp_USD = rs.getDouble(colNamesProps.getProperty("stage7_SMARTPHONEKFR").trim());
					
				} else if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.BASICCELL").trim())) {
					cmp_USD = rs.getDouble(colNamesProps.getProperty("stage7_BASICCELLKFR").trim());
					
				} else if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.HOMEOFFICEVOICE").trim())) {
					cmp_USD = rs.getDouble(colNamesProps.getProperty("stage7_HOMEVOICEKFR").trim());
					
				} else if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.DATACARD").trim())) {
					cmp_USD = rs.getDouble(colNamesProps.getProperty("stage7_DATACARDKFR").trim());
				
				} else if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.TABLET").trim())) {
					cmp_USD = rs.getDouble(colNamesProps.getProperty("stage7_TABLETKFR").trim());
				
				} else if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.ALLSERVICES").trim())) {
					cmp_USD = rs.getDouble(colNamesProps.getProperty("stage7_SMARTPHONEKFR").trim()) +
							   rs.getDouble(colNamesProps.getProperty("stage7_BASICCELLKFR").trim()) +
							   rs.getDouble(colNamesProps.getProperty("stage7_HOMEVOICEKFR").trim()) +
							   rs.getDouble(colNamesProps.getProperty("stage7_DATACARDKFR").trim()) +
							   rs.getDouble(colNamesProps.getProperty("stage7_TABLETKFR").trim());
				
				} // End CMP_USD 				
				
				
				
				// cmp_Count
				if ( (cmp_USD < 0) || (cmp_USD > 0) ) {
					cmp_Count = 1;
				} else {
					cmp_Count = 0;
				} // End CMP_Count			

				
				
				// ofc_SUT_USD
				if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.SUT").trim())) {					
					ofc_SUT_USD = rs.getDouble(colNamesProps.getProperty("stage7_SOFTPHONEGVI").trim());
					
				} else if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.OFFICEPHONE").trim())) {
					ofc_SUT_USD = rs.getDouble(colNamesProps.getProperty("stage7_OFFICEPHONEGVI").trim());

				} else if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.ALLSERVICES").trim())) {
					ofc_SUT_USD = rs.getDouble(colNamesProps.getProperty("stage7_SOFTPHONEGVI").trim()) +
							   rs.getDouble(colNamesProps.getProperty("stage7_OFFICEPHONEGVI").trim());
				
				} // End OFC_SUT_USD				
				
				
				
				// ofc_SUT_Count
				if ( (ofc_SUT_USD < 0) || (ofc_SUT_USD > 0) ) {
					ofc_SUT_Count = 1;
				} else {
					ofc_SUT_Count = 0;
				} // End OFC_SUT_Count				
				
				
				// total_USD
				total_USD = wwer_USD + cmp_USD + ofc_SUT_USD;

				
				
				// total_Count
				if ( (total_USD < 0) || (total_USD > 0) ) {
					total_Count = 1;
				} else {
					total_Count = 0;
				} // End Total_Count							

				
				
				// wwer_LC
				if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.SMARTPHONE").trim())) {					
					wwer_LC = rs.getDouble(colNamesProps.getProperty("stage13_SMARTPHONEWWERLOCCUR").trim());
					
				} else if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.BASICCELL").trim())) {
					wwer_LC = rs.getDouble(colNamesProps.getProperty("stage13_BASICCELLWWERLOCCUR").trim());
					
				} else if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.HOMEOFFICEVOICE").trim())) {
					wwer_LC = rs.getDouble(colNamesProps.getProperty("stage13_HOMEVOICEWWERLOCCUR").trim());
					
				} else if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.DATACARD").trim())) {
					wwer_LC = rs.getDouble(colNamesProps.getProperty("stage13_DATACARDWWERLOCCUR").trim());
				
				} else if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.HOMEINTERNET").trim())) {
					wwer_LC = rs.getDouble(colNamesProps.getProperty("stage13_HOMEINTERNETWWERLOCCUR").trim());
				
				} else if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.CALLINGCARD").trim())) {
					wwer_LC = rs.getDouble(colNamesProps.getProperty("stage13_CALLINGCARDLOCCUR").trim());
				
				} else if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.CONFERENCING").trim())) {
					wwer_LC = rs.getDouble(colNamesProps.getProperty("stage13_CONFERENCINGLOCCUR").trim());
				
				} else if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.HOTELINTERNET").trim())) {
					wwer_LC = rs.getDouble(colNamesProps.getProperty("stage13_HOTELINTERNETLOCCUR").trim());
				
				} else if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.HOTELTELEPHONE").trim())) {
					wwer_LC = rs.getDouble(colNamesProps.getProperty("stage13_HOTELTELEPHONELOCCUR").trim());
				
				} else if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.UNCLASSFIED").trim())) {
					wwer_LC = rs.getDouble(colNamesProps.getProperty("stage13_UNCLASSIFIEDLOCCUR").trim());
				
				} else if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.TABLET").trim())) {
					wwer_LC = rs.getDouble(colNamesProps.getProperty("stage13_TABLETWWERLOCCUR").trim());
				
				} else if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.ALLSERVICES").trim())) {
					wwer_LC = rs.getDouble(colNamesProps.getProperty("stage13_SMARTPHONEWWERLOCCUR").trim()) +
							  rs.getDouble(colNamesProps.getProperty("stage13_BASICCELLWWERLOCCUR").trim()) +
							  rs.getDouble(colNamesProps.getProperty("stage13_HOMEVOICEWWERLOCCUR").trim()) +
							  rs.getDouble(colNamesProps.getProperty("stage13_DATACARDWWERLOCCUR").trim()) +
							  rs.getDouble(colNamesProps.getProperty("stage13_HOMEINTERNETWWERLOCCUR").trim()) +
							  rs.getDouble(colNamesProps.getProperty("stage13_CALLINGCARDLOCCUR").trim()) +
							  rs.getDouble(colNamesProps.getProperty("stage13_CONFERENCINGLOCCUR").trim()) +
							  rs.getDouble(colNamesProps.getProperty("stage13_HOTELINTERNETLOCCUR").trim()) +
							  rs.getDouble(colNamesProps.getProperty("stage13_HOTELTELEPHONELOCCUR").trim()) +
							  rs.getDouble(colNamesProps.getProperty("stage13_UNCLASSIFIEDLOCCUR").trim()) +
							  rs.getDouble(colNamesProps.getProperty("stage13_TABLETWWERLOCCUR").trim());
				
				} // End WWER_LC 				

				
				
				// cmp_LC
				if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.SMARTPHONE").trim())) {					
					cmp_LC = rs.getDouble(colNamesProps.getProperty("stage13_SMARTPHONEKFRLOCCUR").trim());
					
				} else if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.BASICCELL").trim())) {
					cmp_LC = rs.getDouble(colNamesProps.getProperty("stage13_BASICCELLKFRLOCCUR").trim());
					
				} else if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.HOMEOFFICEVOICE").trim())) {
					cmp_LC = rs.getDouble(colNamesProps.getProperty("stage13_HOMEVOICEKFRLOCCUR").trim());
					
				} else if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.DATACARD").trim())) {
					cmp_LC = rs.getDouble(colNamesProps.getProperty("stage13_DATACARDKFRLOCCUR").trim());
				
				} else if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.TABLET").trim())) {
					cmp_LC = rs.getDouble(colNamesProps.getProperty("stage13_TABLETKFRLOCCUR").trim());
				
				} else if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.ALLSERVICES").trim())) {
					cmp_LC = rs.getDouble(colNamesProps.getProperty("stage13_SMARTPHONEKFRLOCCUR").trim()) +
							   rs.getDouble(colNamesProps.getProperty("stage13_BASICCELLKFRLOCCUR").trim()) +
							   rs.getDouble(colNamesProps.getProperty("stage13_HOMEVOICEKFRLOCCUR").trim()) +
							   rs.getDouble(colNamesProps.getProperty("stage13_DATACARDKFRLOCCUR").trim()) +
							   rs.getDouble(colNamesProps.getProperty("stage13_TABLETKFRLOCCUR").trim());
				
				} // End CMP_LC				

				
				
				// ofc_SUT_LC
				if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.SUT").trim())) {					
					ofc_SUT_LC = rs.getDouble(colNamesProps.getProperty("stage13_SOFTPHONEGVILOCCUR").trim());
					
				} else if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.OFFICEPHONE").trim())) {
					ofc_SUT_LC = rs.getDouble(colNamesProps.getProperty("stage13_OFFICEPHONEGVILOCCUR").trim());

				} else if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.ALLSERVICES").trim())) {
					ofc_SUT_LC = rs.getDouble(colNamesProps.getProperty("stage13_SOFTPHONEGVILOCCUR").trim()) +
							     rs.getDouble(colNamesProps.getProperty("stage13_OFFICEPHONEGVILOCCUR").trim());
				
				} // End OFC_SUT_LC 				
				
				
				
				// total_LC
				total_LC = wwer_LC + cmp_LC + ofc_SUT_LC;

				
				
				// filter
				if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.ALLSERVICES").trim())) {
					filter = "Yes";				
				} else if ( (total_USD > 0) || (total_USD < 0) ) {
					filter = "Yes";
				} else if (total_USD == 0) {
					filter = "No";
				} // end Filter

				
				
				// clip_Lvl
				if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.SMARTPHONE").trim())) {					
					clip_Lvl = rs.getDouble(colNamesProps.getProperty("stage9_COUNTRYCLIPLEVELSP").trim());
					
				} else if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.BASICCELL").trim())) {
					clip_Lvl = rs.getDouble(colNamesProps.getProperty("stage9_COUNTRYCLIPLEVELCP").trim());
					
				} else if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.HOMEOFFICEVOICE").trim())) {
					clip_Lvl = rs.getDouble(colNamesProps.getProperty("stage9_COUNTRYCLIPLEVELHOV").trim());
					
				} else if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.DATACARD").trim())) {
					clip_Lvl = rs.getDouble(colNamesProps.getProperty("stage9_COUNTRYCLIPLEVELDC").trim());

				} // End clip_Lvl 				
				
				
				
				// combinations
				if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.SMARTPHONE").trim())) {					
					combinations = rs.getString(colNamesProps.getProperty("stage9_COMBINATIONSP").trim());
					
				} else if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.BASICCELL").trim())) {
					combinations = rs.getString(colNamesProps.getProperty("stage9_COMBINATIONCP").trim());
					
				} else if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.HOMEOFFICEVOICE").trim())) {
					combinations = rs.getString(colNamesProps.getProperty("stage9_COMBINATIONHOV").trim());
					
				} else if (serviceType.equalsIgnoreCase(props.getProperty("serviceType.DATACARD").trim())) {
					combinations = rs.getString(colNamesProps.getProperty("stage9_COMBINATIONDC").trim());

				} // End combinations				

				if (cnum.equalsIgnoreCase("015133649")) {
					if (isTestRun) {
						LOGGER.debug(new StringBuffer("[").append(counter).append("] Service Type based summary Compliance Data for cnum = ").append(cnum));
						LOGGER.debug(new StringBuffer("compliance = " + compliance));
						LOGGER.debug(new StringBuffer("NC_Multi = " + nc_Multi));
						LOGGER.debug(new StringBuffer("NC_Service = " + nc_Service));
						LOGGER.debug(new StringBuffer("NC_Explanation = " + nc_Explanation));
						LOGGER.debug(new StringBuffer("WWER_USD = " + wwer_USD));
						LOGGER.debug(new StringBuffer("WWER_Count = " + wwer_Count));
						LOGGER.debug(new StringBuffer("CMP_USD = " + cmp_USD));
						LOGGER.debug(new StringBuffer("CMP_Count = " + cmp_Count));
						LOGGER.debug(new StringBuffer("OFC_SUT_USD = " + ofc_SUT_USD));
						LOGGER.debug(new StringBuffer("OFC_SUT_Count = " + ofc_SUT_Count));
						LOGGER.debug(new StringBuffer("Total_USD = " + total_USD));
						LOGGER.debug(new StringBuffer("Total_Count = " + total_USD));
						LOGGER.debug(new StringBuffer("WWER_LC = " + wwer_LC));
						LOGGER.debug(new StringBuffer("CMP_LC = " + cmp_LC));
						LOGGER.debug(new StringBuffer("OFC_SUT_LC = " + ofc_SUT_LC));
						LOGGER.debug(new StringBuffer("Total_LC = " + total_LC));
						LOGGER.debug(new StringBuffer("Filter = " + filter));
						LOGGER.debug(new StringBuffer("Clip_Lvl = " + clip_Lvl));
						LOGGER.debug(new StringBuffer("Combinations = " + combinations));
					}
				}

				
				// update fields into ResultSet to update each record

				// Summary Table Columns
				rs.updateString(colNamesProps.getProperty("summary_SERVICE_TYPE").trim(),serviceType);
				rs.updateString(colNamesProps.getProperty("summary_COMPLIANCE").trim(),compliance);
				rs.updateString(colNamesProps.getProperty("summary_NC_MULTI").trim(),nc_Multi);
				rs.updateString(colNamesProps.getProperty("summary_NC_SERVICE").trim(),nc_Service);
				rs.updateString(colNamesProps.getProperty("summary_NC_EXPLANATION").trim(),nc_Explanation);
				rs.updateDouble(colNamesProps.getProperty("summary_WWER_USD").trim(),wwer_USD);
				rs.updateInt(colNamesProps.getProperty("summary_WWER_COUNT").trim(),wwer_Count);
				rs.updateDouble(colNamesProps.getProperty("summary_CMP_USD").trim(),cmp_USD);
				rs.updateInt(colNamesProps.getProperty("summary_CMP_COUNT").trim(),cmp_Count);
				rs.updateDouble(colNamesProps.getProperty("summary_OFC_SUT_USD").trim(),ofc_SUT_USD);
				rs.updateInt(colNamesProps.getProperty("summary_OFC_SUT_COUNT").trim(),ofc_SUT_Count);
				rs.updateDouble(colNamesProps.getProperty("summary_TOTAL_USD").trim(),total_USD);
				rs.updateInt(colNamesProps.getProperty("summary_TOTAL_COUNT").trim(),total_Count);
				rs.updateDouble(colNamesProps.getProperty("summary_WWER_LC").trim(),wwer_LC);
				rs.updateDouble(colNamesProps.getProperty("summary_CMP_LC").trim(),cmp_LC);
				rs.updateDouble(colNamesProps.getProperty("summary_OFC_SUT_LC").trim(),ofc_SUT_LC);
				rs.updateDouble(colNamesProps.getProperty("summary_TOTAL_LC").trim(),total_LC);
				rs.updateDouble(colNamesProps.getProperty("summary_CLIP_LVL").trim(),clip_Lvl);
				rs.updateString(colNamesProps.getProperty("summary_COMBINATIONS").trim(),combinations);
				rs.updateString(colNamesProps.getProperty("summary_FILTER").trim(),filter);
				
		        rs.updateRow();
				if ((counter % 10000 == 0) || (counter == totalEmps)) {
					if (isTestRun)
						LOGGER.debug(new StringBuffer("[")
								.append(counter)
								.append("] Service Type based summary compliance data updated (but not committed yet) for CNUM = ")
								.append(cnum));
				}
				
			} // end while
					
			// Connection must be on a unit-of-work boundary to allow close
			if ( conn != null) {
				conn.commit();
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Total Transaction(s) committed = ").append(counter));
			}

		} catch (SQLException e) {
			if ( counter == 0) {
				LOGGER.error(new StringBuffer("Exception caught while getting base compliance records from table "+ e.getMessage()));
			} else {
				LOGGER.error(new StringBuffer("Exception caught while processing service type based summary compliance data "+ e.getMessage()));
				if (isTestRun) {
					LOGGER.error(new StringBuffer("[").append(counter).append("] Service Type based summary Compliance Data for cnum = ").append(cnum));
					LOGGER.error(new StringBuffer("compliance = " + compliance));
					LOGGER.error(new StringBuffer("NC_Multi = " + nc_Multi));
					LOGGER.error(new StringBuffer("NC_Service = " + nc_Service));
					LOGGER.error(new StringBuffer("NC_Explanation = " + nc_Explanation));
					LOGGER.error(new StringBuffer("WWER_USD = " + wwer_USD));
					LOGGER.error(new StringBuffer("WWER_Count = " + wwer_Count));
					LOGGER.error(new StringBuffer("CMP_USD = " + cmp_USD));
					LOGGER.error(new StringBuffer("CMP_Count = " + cmp_Count));
					LOGGER.error(new StringBuffer("OFC_SUT_USD = " + ofc_SUT_USD));
					LOGGER.error(new StringBuffer("OFC_SUT_Count = " + ofc_SUT_Count));
					LOGGER.error(new StringBuffer("Total_USD = " + total_USD));
					LOGGER.error(new StringBuffer("Total_Count = " + total_USD));
					LOGGER.error(new StringBuffer("WWER_LC = " + wwer_LC));
					LOGGER.error(new StringBuffer("CMP_LC = " + cmp_LC));
					LOGGER.error(new StringBuffer("OFC_SUT_LC = " + ofc_SUT_LC));
					LOGGER.error(new StringBuffer("Total_LC = " + total_LC));
					LOGGER.error(new StringBuffer("Filter = " + filter));
					LOGGER.error(new StringBuffer("Clip_Lvl = " + clip_Lvl));
					LOGGER.error(new StringBuffer("Combinations = " + combinations));
				}
			}

			e.printStackTrace();
			return -1;
			
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
				}//end catch
			}//end if
			
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing Statement. Resources might not be released ", e);
				}//end catch
			}//end if
		}//end finally
	
		if (isTestRun) {
			LOGGER.debug(new StringBuffer("End --- Building Summary Compliance Records for ServiceType = " + serviceType));
			LOGGER.debug(new StringBuffer("Exiting PersonaComplianceDAO::buildSvcTypeBasedSummaryComplianceData() ============>"));
		}

		return totalEmps;
	}

	/**
	 * Inserts SumaryCompliace records
	 * @return
	 */
	public int insertSumaryCompliaceRecords(){
			
		String query = null;
		PreparedStatement stmt = null;
		int result = -1;

		
		if (isTestRun) {
			LOGGER.debug(new StringBuffer("Entering PersonaSummaryComplianceDAO::insertSumaryCompliaceRecords() <============"));
		}
		
		try {

			// invoke INSERT query to populate the table
			query = SQLQuery.getQuery(SQLQuery.PERSONA_SUMMARY_COMPLIANCE_INSERT);
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.prepareStatement(query);

			result = stmt.executeUpdate();

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Inserted ").append(result).append(" record(s)"));
			}

			// Close the Statement
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing PreparedStatement. Resources might not be released ", e);
				}//end catch
			}
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Exiting PersonaSummaryComplianceDAO::insertSumaryCompliaceRecords() ============>"));
			}

			return result;
			
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer("Exception caught attempting to insert record into table " + e.getMessage()));
		    e.printStackTrace();
		    return -1;
		}
	}

}
