package com.ibm.cio;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Vector;

import org.apache.log4j.Logger;

//public class PersonaKFRDAO extends BaseDAO{
public class PersonaEPWSDAO{

	//private final String SQL_QUERY_CHECK_CDAY = "Select DAY_CALLS, XFER_COUNT from TBL_CDAY_BARRED Where MOBILE = ? and DAY_CALLS = ?";//'24/MAR/08'
//	private final String SQL_INSERT = "Insert into TBL_SIMLOSS"+
//										"(MOBILE, LANDLINE, CUSTTYPE, SIMSTATUS, REQDATE, REQTIME) "+
//										"values(?,?,?,?,?,?)";

	private Connection conn = null;
	private boolean isTestRun;
	private Vector<String> cCodes = new Vector<String>(10, 10);
	private Vector<String> cCodesGCG = new Vector<String>(10, 10);
	private Vector<String> cCodesNonGCG = new Vector<String>(10, 10);
	private Vector emplTypes = null;
	private Vector cCodeStrs = null;

	private static Logger LOGGER = Logger.getLogger(PersonaEPWSDAO.class);

	public PersonaEPWSDAO(Connection connection, boolean testRun, Vector countryCodes, Vector empTypes) {
		// initialization 
		conn = connection;
		isTestRun = testRun;
		cCodeStrs = countryCodes;
		emplTypes = empTypes;

		int totalCountryCodes = cCodeStrs.size();
		
		for (int i=0; i < totalCountryCodes; i++) {
			String codeStr = (String)cCodeStrs.get(i);
			// Make a list of all CCs
			cCodes.add(codeStr.substring(0, 3));
			
			if (codeStr.substring(3).equals("Y")) {
				// Make a list of all GCG CCs
				cCodesGCG.add(codeStr.substring(0, 3));
			} else {
				// Make a list of all Non GCG CCs
				cCodesNonGCG.add(codeStr.substring(0, 3));
			}
		}

		LOGGER.info("Country Codes (ALL): ");			
		for (int i=0; i < cCodes.size(); i++) {
			LOGGER.info("countryCodeAll" + (i+1) + ": " + cCodes.get(i));				
		}

		LOGGER.info("Country Codes (NonGCG): ");			
		for (int i=0; i < cCodesNonGCG.size(); i++) {
			LOGGER.info("countryCodeNonGCG" + (i+1) + ": " + cCodesNonGCG.get(i));				
		}

		LOGGER.info("Country Codes (GCG): ");			
		for (int i=0; i < cCodesGCG.size(); i++) {
			LOGGER.info("countryCodeGCG" + (i+1) + ": " + cCodesGCG.get(i));				
		}

		if (isTestRun)
			LOGGER.debug(new StringBuffer("Created PersonaEPWSDAO object successfully"));

//		logToken = new StringBuffer("[").append(callid).append("] [").append(mobile).append("] ").toString();
/*		try {
			conn = getConnection(jndiName, cell, callID);

		} catch (SQLException e) {
			LOGGER.error(new StringBuffer(logToken).append(" - A connection to the LDB was not established.  Check the DataSource settings."));
			e.printStackTrace();
		}
		*/
	}


	
	/**
	 * Deletes records
	 * @return
	 */
	public int deleteRecords(){
		
		String query = null;
		PreparedStatement stmt = null;
		int result = -1;

		
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaEPWSDAO::deleteRecords() <============"));
		
		try {

			// invoke DELETE query to clean up the table
			query = SQLQuery.getQuery(SQLQuery.PERSONA_EPWS_DELETE);
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.prepareStatement(query);

			result = stmt.executeUpdate();

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Deleted ").append(result).append(" record(s)"));
			}

			// Close the Statement
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing PreparedStatement. Resources might not be released ", e);
				}//end catch
			}
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Exiting PersonaEPWSDAO::deleteRecords() ============>"));
			}
			
			return result;
			
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer("Exception caught attempting to delete records from table " + e.getMessage()));
    	    e.printStackTrace();
			return -1;
		}
	}

	
	/**
	 * Inserts All records
	 * @return
	 */
	public int insertRecords(){
			
		String query = null;
		PreparedStatement stmt = null;
		int result = -1;
		String cCodesStr = "'";
		String empTypesStr = "'";

		
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaEPWSDAO::insertRecords() <============"));
		
		try {

			int totalCountryCodes = cCodes.size();
			int totalEmpTypes = emplTypes.size();

			for (int i=0; i < totalCountryCodes; i++) {
				cCodesStr = cCodesStr + cCodes.get(i) + "'" ;
				if ( i < totalCountryCodes-1 )
					cCodesStr = cCodesStr + ",'" ;
			}

/*			
			for (int i=0; i < totalCountryCodes; i++) {
				String codeStr = (String)cCodes.get(i);
				cCodesStr = cCodesStr + codeStr.substring(0, 3) + "'" ;
				if ( i < totalCountryCodes-1 )
					cCodesStr = cCodesStr + ",'" ;
			}
*/
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Country Codes String: ").append(cCodesStr));

			for (int i=0; i < totalEmpTypes; i++) {
				empTypesStr = empTypesStr + emplTypes.get(i) + "'" ;
				if ( i < totalEmpTypes-1 )
					empTypesStr = empTypesStr + ",'" ;
			}
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Employee Types String: ").append(empTypesStr));

			// invoke INSERT query to populate the table
			query = SQLQuery.getQuery(SQLQuery.PERSONA_EPWS_INSERT) + 
					cCodesStr + 
					SQLQuery.getQuery(SQLQuery.PERSONA_EPWS_INSERT_2) + 
					empTypesStr +
					SQLQuery.getQuery(SQLQuery.PERSONA_EPWS_INSERT_3);
			 
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.prepareStatement(query);

			result = stmt.executeUpdate();

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Inserted ").append(result).append(" record(s)"));
			}

			// Close the Statement
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing PreparedStatement. Resources might not be released ", e);
				}//end catch
			}
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Exiting PersonaEPWSDAO::insertRecords() ============>"));
			}
				
			return result;
			
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer("Exception caught attempting to insert record into table " + e.getMessage()));
		    e.printStackTrace();
		    return -1;
		}
	}
	
	/**
	 * Deletes records
	 * @return
	 */
	public int deleteRecords2(){
		
		String query = null;
		PreparedStatement stmt = null;
		int result = -1;
		
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaEPWSDAO::deleteRecords2() <============"));
		
		try {

			// invoke DELETE query to clean up the table
			query = SQLQuery.getQuery(SQLQuery.PERSONA_EPWS_DELETE2);
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.prepareStatement(query);

			result = stmt.executeUpdate();

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Deleted ").append(result).append(" record(s)"));
			}

			// Close the Statement
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing PreparedStatement. Resources might not be released ", e);
				}//end catch
			}
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Exiting PersonaEPWSDAO::deleteRecords2() ============>"));
			}
			
			return result;
			
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer("Exception caught attempting to delete records from table " + e.getMessage()));
    	    e.printStackTrace();
			return -1;
		}
	}

	
	/**
	 * Inserts records
	 * @return
	 */
	public int insertRecords2(){
			
		String query = null;
		PreparedStatement stmt = null;
		int result = -1;

		
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaEPWSDAO::insertRecords2() <============"));
		
		try {

			// invoke INSERT query to populate the table
			query = SQLQuery.getQuery(SQLQuery.PERSONA_EPWS_INSERT2);
			 
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.prepareStatement(query);

			result = stmt.executeUpdate();

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Inserted ").append(result).append(" record(s)"));
			}

			// Close the Statement
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing PreparedStatement. Resources might not be released ", e);
				}//end catch
			}
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Exiting PersonaEPWSDAO::insertRecords2() ============>"));
			}
				
			return result;
			
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer("Exception caught attempting to insert record into table " + e.getMessage()));
		    e.printStackTrace();
		    return -1;
		}
	}
	
	/**
	 * Deletes records
	 * @return
	 */
	public int deleteDirectConnectRecords(){
		
		String query = null;
		PreparedStatement stmt = null;
		int result = -1;

		
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaEPWSDAO::deleteDirectConnectRecords() <============"));
		
		try {

			// invoke DELETE query to clean up the table
			query = SQLQuery.getQuery(SQLQuery.PERSONA_EPWS_DIRECTCONNECT_DELETE);
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.prepareStatement(query);

			result = stmt.executeUpdate();

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Deleted ").append(result).append(" record(s)"));
			}

			// Close the Statement
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing PreparedStatement. Resources might not be released ", e);
				}//end catch
			}
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Exiting PersonaEPWSDAO::deleteDirectConnectRecords() ============>"));
			}
			
			return result;
			
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer("Exception caught attempting to delete records from table " + e.getMessage()));
    	    e.printStackTrace();
			return -1;
		}
	}

	
	/**
	 * Inserts records
	 * @return
	 */
	public int insertDirectConnectRecords(){
			
		String query = null;
		PreparedStatement stmt = null;
		int result = -1;
		String cCodesStr = "'";
		String empTypesStr = "'";

		
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaEPWSDAO::insertDirectConnectRecords() <============"));
		
		try {

			int totalCountryCodes = cCodes.size();
			int totalEmpTypes = emplTypes.size();

			for (int i=0; i < totalCountryCodes; i++) {
				cCodesStr = cCodesStr + cCodes.get(i) + "'" ;
				if ( i < totalCountryCodes-1 )
					cCodesStr = cCodesStr + ",'" ;
			}
/*			
			for (int i=0; i < totalCountryCodes; i++) {
				String codeStr = (String)cCodes.get(i);
				cCodesStr = cCodesStr + codeStr.substring(0, 3) + "'" ;
				if ( i < totalCountryCodes-1 )
					cCodesStr = cCodesStr + ",'" ;
			}
*/
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Country Codes String: ").append(cCodesStr));

			for (int i=0; i < totalEmpTypes; i++) {
				empTypesStr = empTypesStr + emplTypes.get(i) + "'" ;
				if ( i < totalEmpTypes-1 )
					empTypesStr = empTypesStr + ",'" ;
			}
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Employee Types String: ").append(empTypesStr));

			// invoke INSERT query to populate the table
			query = SQLQuery.getQuery(SQLQuery.PERSONA_EPWS_DIRECTCONNECT_INSERT) + 
					cCodesStr + 
					SQLQuery.getQuery(SQLQuery.PERSONA_EPWS_DIRECTCONNECT_INSERT_2) + 
					empTypesStr +
					SQLQuery.getQuery(SQLQuery.PERSONA_EPWS_DIRECTCONNECT_INSERT_3);
			 
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.prepareStatement(query);

			result = stmt.executeUpdate();

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Inserted ").append(result).append(" record(s)"));
			}

			// Close the Statement
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing PreparedStatement. Resources might not be released ", e);
				}//end catch
			}
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Exiting PersonaEPWSDAO::insertDirectConnectRecords() ============>"));
			}
				
			return result;
			
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer("Exception caught attempting to insert record into table " + e.getMessage()));
		    e.printStackTrace();
		    return -1;
		}
	}
	
	/**
	 * Deletes NON GCG based EPWS records
	 * @return
	 */
	public int deleteNonGCGBasedEPWSRecords(){
		
		String query = null;
		PreparedStatement stmt = null;
		int result = -1;

		
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaEPWSDAO::deleteNonGCGBasedEPWSRecords() <============"));
		
		try {

			// invoke DELETE query to clean up the table
			query = SQLQuery.getQuery(SQLQuery.PERSONA_EPWS_NONGCG_DELETE);
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.prepareStatement(query);

			result = stmt.executeUpdate();

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Deleted ").append(result).append(" record(s)"));
			}

			// Close the Statement
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing PreparedStatement. Resources might not be released ", e);
				}//end catch
			}
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Exiting PersonaEPWSDAO::deleteNonGCGBasedEPWSRecords() ============>"));
			}
			
			return result;
			
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer("Exception caught attempting to delete records from table " + e.getMessage()));
    	    e.printStackTrace();
			return -1;
		}
	}

	
	/**
	 * Inserts NON GCG based EPWS records
	 * @return
	 */
	public int insertNonGCGBasedEPWSRecords(){
			
		String query = null;
		PreparedStatement stmt = null;
		int result = -1;
		String cCodesStr = "'";

		
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaEPWSDAO::insertNonGCGBasedEPWSRecords() <============"));
		
		try {

			int totalCountryCodes = cCodesNonGCG.size();

			for (int i=0; i < totalCountryCodes; i++) {
				cCodesStr = cCodesStr + cCodesNonGCG.get(i) + "'" ;
				if ( i < totalCountryCodes-1 )
					cCodesStr = cCodesStr + ",'" ;
			}

			if (isTestRun)
				LOGGER.debug(new StringBuffer("Country Codes String: ").append(cCodesStr));

			// invoke INSERT query to populate the table
			query = SQLQuery.getQuery(SQLQuery.PERSONA_EPWS_NONGCG_INSERT) + 
					cCodesStr + 
					SQLQuery.getQuery(SQLQuery.PERSONA_EPWS_NONGCG_INSERT_2); 
			 
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.prepareStatement(query);

			result = stmt.executeUpdate();

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Inserted ").append(result).append(" record(s)"));
			}

			// Close the Statement
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing PreparedStatement. Resources might not be released ", e);
				}//end catch
			}
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Exiting PersonaEPWSDAO::insertNonGCGBasedEPWSRecords() ============>"));
			}
				
			return result;
			
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer("Exception caught attempting to insert record into table " + e.getMessage()));
		    e.printStackTrace();
		    return -1;
		}
	}
	
	/**
	 * Deletes GCG based EPWS records
	 * @return
	 */
	public int deleteGCGBasedEPWSRecords(){
		
		String query = null;
		PreparedStatement stmt = null;
		int result = -1;

		
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaEPWSDAO::deleteGCGBasedEPWSRecords() <============"));
		
		try {

			// invoke DELETE query to clean up the table
			query = SQLQuery.getQuery(SQLQuery.PERSONA_EPWS_GCG_DELETE);
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.prepareStatement(query);

			result = stmt.executeUpdate();

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Deleted ").append(result).append(" record(s)"));
			}

			// Close the Statement
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing PreparedStatement. Resources might not be released ", e);
				}//end catch
			}
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Exiting PersonaEPWSDAO::deleteGCGBasedEPWSRecords() ============>"));
			}
			
			return result;
			
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer("Exception caught attempting to delete records from table " + e.getMessage()));
    	    e.printStackTrace();
			return -1;
		}
	}

	
	/**
	 * Inserts GCG based EPWS records
	 * @return
	 */
	public int insertGCGBasedEPWSRecords(){
			
		String query = null;
		PreparedStatement stmt = null;
		int result = -1;
		String cCodesStr = "'";

		
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaEPWSDAO::insertGCGBasedEPWSRecords() <============"));
		
		try {

			int totalCountryCodes = cCodesGCG.size();

			for (int i=0; i < totalCountryCodes; i++) {
				cCodesStr = cCodesStr + cCodesGCG.get(i) + "'" ;
				if ( i < totalCountryCodes-1 )
					cCodesStr = cCodesStr + ",'" ;
			}

			if (isTestRun)
				LOGGER.debug(new StringBuffer("Country Codes String: ").append(cCodesStr));

			// invoke INSERT query to populate the table
			query = SQLQuery.getQuery(SQLQuery.PERSONA_EPWS_GCG_INSERT) + 
					cCodesStr + 
					SQLQuery.getQuery(SQLQuery.PERSONA_EPWS_GCG_INSERT_2); 
			 
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.prepareStatement(query);

			result = stmt.executeUpdate();

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Inserted ").append(result).append(" record(s)"));
			}

			// Close the Statement
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing PreparedStatement. Resources might not be released ", e);
				}//end catch
			}
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Exiting PersonaEPWSDAO::insertGCGBasedEPWSRecords() ============>"));
			}
				
			return result;
			
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer("Exception caught attempting to insert record into table " + e.getMessage()));
		    e.printStackTrace();
		    return -1;
		}
	}
	
	/**
	 * Deletes GCG Employee Clip Level based EPWS records
	 * @return
	 */
	public int deleteGCGEmplBasedEPWSRecords(){
		
		String query = null;
		PreparedStatement stmt = null;
		int result = -1;

		
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaEPWSDAO::deleteGCGEmplBasedEPWSRecords() <============"));
		
		try {

			// invoke DELETE query to clean up the table
			query = SQLQuery.getQuery(SQLQuery.PERSONA_EPWS_GCG_EMPL_DELETE);
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.prepareStatement(query);

			result = stmt.executeUpdate();

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Deleted ").append(result).append(" record(s)"));
			}

			// Close the Statement
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing PreparedStatement. Resources might not be released ", e);
				}//end catch
			}
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Exiting PersonaEPWSDAO::deleteGCGEmplBasedEPWSRecords() ============>"));
			}
			
			return result;
			
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer("Exception caught attempting to delete records from table " + e.getMessage()));
    	    e.printStackTrace();
			return -1;
		}
	}

	
	/**
	 * Inserts GCG Employee Clip Level based EPWS records
	 * @return
	 */
	public int insertGCGEmplBasedEPWSRecords(){
			
		String query = null;
		PreparedStatement stmt = null;
		int result = -1;
		String cCodesStr = "'";

		
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaEPWSDAO::insertGCGEmplBasedEPWSRecords() <============"));
		
		try {

			int totalCountryCodes = cCodesGCG.size();

			for (int i=0; i < totalCountryCodes; i++) {
				cCodesStr = cCodesStr + cCodesGCG.get(i) + "'" ;
				if ( i < totalCountryCodes-1 )
					cCodesStr = cCodesStr + ",'" ;
			}

			if (isTestRun)
				LOGGER.debug(new StringBuffer("Country Codes String: ").append(cCodesStr));

			// invoke INSERT query to populate the table
			query = SQLQuery.getQuery(SQLQuery.PERSONA_EPWS_GCG_EMPL_INSERT) + 
					cCodesStr + 
					SQLQuery.getQuery(SQLQuery.PERSONA_EPWS_GCG_EMPL_INSERT_2); 
			 
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.prepareStatement(query);

			result = stmt.executeUpdate();

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Inserted ").append(result).append(" record(s)"));
			}

			// Close the Statement
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing PreparedStatement. Resources might not be released ", e);
				}//end catch
			}
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Exiting PersonaEPWSDAO::insertGCGEmplBasedEPWSRecords() ============>"));
			}
				
			return result;
			
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer("Exception caught attempting to insert record into table " + e.getMessage()));
		    e.printStackTrace();
		    return -1;
		}
	}

}
