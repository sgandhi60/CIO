package com.ibm.cio;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.pbepc.ilog.ComplianceForIlog;
import com.pbepc.services.EmbeddedIlogService;

//public class PersonaComplianceDAO extends BaseDAO{
public class PersonaComplianceDAO{

	private Connection conn = null;
	private boolean isTestRun;

	private static Logger LOGGER = Logger.getLogger(PersonaComplianceDAO.class);

	public PersonaComplianceDAO(Connection connection, boolean testRun) {
		// initialization 
		conn = connection;
		isTestRun = testRun;

		if (isTestRun)
			LOGGER.debug(new StringBuffer("Created PersonaComplianceDAO object successfully"));

	}


	
	/**
	 * Deletes records
	 * @return
	 */
	public int deleteRecordsFromTest(){
		
		String query = null;
		PreparedStatement stmt = null;
		int result = -1;

		
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaComplianceDAO::deleteRecordsFromTest() <============"));
		
		try {

			// invoke DELETE query to clean up the table
			query = SQLQuery.getQuery(SQLQuery.PERSONA_COMPLIANCE_TEST_DELETE);
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.prepareStatement(query);

			result = stmt.executeUpdate();

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Deleted ").append(result).append(" record(s)"));
			}

			// Close the Statement
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing PreparedStatement. Resources might not be released ", e);
				}//end catch
			}
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Exiting PersonaComplianceDAO::deleteRecordsFromTest() ============>"));
			}

			return result;
			
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer("Exception caught attempting to delete records from table " + e.getMessage()));
		      e.printStackTrace();
		      return -1;
		}
	}

	
	/**
	 * Inserts KFR records
	 * @return
	 */
	public int insertKFRRecords(){
			
		String query = null;
		PreparedStatement stmt = null;
		int result = -1;

		
		if (isTestRun) {
			LOGGER.debug(new StringBuffer("Entering PersonaComplianceDAO::insertKFRRecords() <============"));
			LOGGER.debug(new StringBuffer("Inserting KFR records for compliance"));
		}
		
		try {

			// invoke INSERT query to populate the table with US KFR records
			query = SQLQuery.getQuery(SQLQuery.PERSONA_COMPLIANCE_TEST_INSERT_KFR);
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.prepareStatement(query);

			result = stmt.executeUpdate();

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Inserted ").append(result).append(" KFR record(s) for US"));
			}

			// Close the Statement
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing PreparedStatement. Resources might not be released ", e);
				}//end catch
			}

			// invoke INSERT query to populate the table with CA KFR records
			query = SQLQuery.getQuery(SQLQuery.PERSONA_COMPLIANCE_TEST_INSERT_KFR_CA);
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.prepareStatement(query);

			result = stmt.executeUpdate();

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Inserted ").append(result).append(" KFR record(s) for CA"));
			}

			// Close the Statement
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing PreparedStatement. Resources might not be released ", e);
				}//end catch
			}
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Exiting PersonaComplianceDAO::insertKFRRecords() ============>"));
			}

			return result;
			
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer("Exception caught attempting to insert KFR records into table " + e.getMessage()));
		      e.printStackTrace();
		      return -1;
		}
	}

	
	/**
	 * Inserts WWER records
	 * @return
	 */
	public int insertWWERRecords(){
			
		String query = null;
		PreparedStatement stmt = null;
		int result = -1;

		
		if (isTestRun) {
			LOGGER.debug(new StringBuffer("Entering PersonaComplianceDAO::insertWWERRecords() <============"));
			LOGGER.debug(new StringBuffer("Inserting WWER records for compliance"));
		}
		
		try {

			// invoke INSERT query to populate the table
			query = SQLQuery.getQuery(SQLQuery.PERSONA_COMPLIANCE_TEST_INSERT_WWER);
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.prepareStatement(query);

			result = stmt.executeUpdate();

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Inserted ").append(result).append(" WWER record(s)"));
			}

			// Close the Statement
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing PreparedStatement. Resources might not be released ", e);
				}//end catch
			}
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Exiting PersonaComplianceDAO::insertWWERRecords() ============>"));
			}

			return result;
			
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer("Exception caught attempting to insert WWER records into table " + e.getMessage()));
		      e.printStackTrace();
		      return -1;
		}
	}
	
	/**
	 * Inserts GVI records
	 * @return
	 */
	public int insertGVIRecords(){
			
		String query = null;
		PreparedStatement stmt = null;
		int result = -1;

		
		if (isTestRun) {
			LOGGER.debug(new StringBuffer("Entering PersonaComplianceDAO::insertGVIRecords() <============"));
			LOGGER.debug(new StringBuffer("Inserting GVI records for compliance"));
		}
		
		try {

			// invoke INSERT query to populate the table
			query = SQLQuery.getQuery(SQLQuery.PERSONA_COMPLIANCE_TEST_INSERT_GVI);
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.prepareStatement(query);

			result = stmt.executeUpdate();

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Inserted ").append(result).append(" GVI record(s)"));
			}

			// Close the Statement
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing PreparedStatement. Resources might not be released ", e);
				}//end catch
			}
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Exiting PersonaComplianceDAO::insertGVIRecords() ============>"));
			}

			return result;
			
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer("Exception caught attempting to insert GVI records into table " + e.getMessage()));
		      e.printStackTrace();
		      return -1;
		}
	}

	/**
	 * Deletes GROUPED records
	 * @return
	 */
	public int deleteGroupedRecords(){
		
		String query = null;
		PreparedStatement stmt = null;
		int result = -1;

		
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaComplianceDAO::deleteGroupedRecords() <============"));
		
		try {

			// invoke DELETE query to clean up the table
			query = SQLQuery.getQuery(SQLQuery.PERSONA_COMPLIANCE_TEST2_DELETE_GROUP);
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.prepareStatement(query);

			result = stmt.executeUpdate();

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Deleted ").append(result).append(" record(s)"));
			}

			// Close the Statement
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing PreparedStatement. Resources might not be released ", e);
				}//end catch
			}
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Exiting PersonaComplianceDAO::deleteGroupedRecords() ============>"));
			}

			return result;
			
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer("Exception caught attempting to delete records from table " + e.getMessage()));
		      e.printStackTrace();
		      return -1;
		}
	}

	
	/**
	 * Inserts GROUPED records
	 * @return
	 */
	public int insertGroupedRecords(){
			
		String query = null;
		PreparedStatement stmt = null;
		int result = -1;

		
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaComplianceDAO::insertGroupedRecords() <============"));
		
		try {

			// invoke INSERT query to populate the table
			query = SQLQuery.getQuery(SQLQuery.PERSONA_COMPLIANCE_TEST2_INSERT_GROUP);
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.prepareStatement(query);

			result = stmt.executeUpdate();

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Inserted ").append(result).append(" record(s)"));
			}

			// Close the Statement
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing PreparedStatement. Resources might not be released ", e);
				}//end catch
			}
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Exiting PersonaComplianceDAO::insertGroupedRecords() ============>"));
			}

			return result;
			
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer("Exception caught attempting to insert records into table " + e.getMessage()));
		      e.printStackTrace();
		      return -1;
		}
	}

	/**
	 * Deletes compliance records
	 * @return
	 */
	public int deleteCompliancePreRecords(){
		
		String query = null;
		PreparedStatement stmt = null;
		int result = -1;

		
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaComplianceDAO::deleteCompliancePreRecords() <============"));
		
		try {

			// invoke DELETE query to clean up the table
			query = SQLQuery.getQuery(SQLQuery.PERSONA_COMPLIANCE_PRE_DELETE);
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.prepareStatement(query);

			result = stmt.executeUpdate();

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Deleted ").append(result).append(" record(s)"));
			}

			// Close the Statement
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing PreparedStatement. Resources might not be released ", e);
				}//end catch
			}
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Exiting PersonaComplianceDAO::deleteCompliancePreRecords() ============>"));
			}

			return result;
			
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer("Exception caught attempting to delete records from table " + e.getMessage()));
		      e.printStackTrace();
		      return -1;
		}
	}

	
	/**
	 * Inserts compliance records
	 * @return
	 */
	public int insertCompliancePreRecords(){
			
		String query = null;
		PreparedStatement stmt = null;
		int result = -1;

		
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaComplianceDAO::insertCompliancePreRecords() <============"));
		
		try {

			// invoke INSERT query to populate the table
			query = SQLQuery.getQuery(SQLQuery.PERSONA_COMPLIANCE_PRE_INSERT);
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.prepareStatement(query);

			result = stmt.executeUpdate();

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Inserted ").append(result).append(" record(s)"));
			}

			// Close the Statement
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing PreparedStatement. Resources might not be released ", e);
				}//end catch
			}
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Exiting PersonaComplianceDAO::insertCompliancePreRecords() ============>"));
			}

			return result;
			
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer("Exception caught attempting to insert records into table "+ e.getMessage()));
			e.printStackTrace();
			return -1;
		}
	}

	
	/**
	 * Inserts Non Matching GCG CNUMs into compliance_pre records
	 * @return
	 */
	public int insertGCGBasedCompliancePreRecords(){
			
		String query = null;
		PreparedStatement stmt = null;
		int result = -1;

		
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaComplianceDAO::insertGCGBasedCompliancePreRecords() <============"));
		
		try {

			// invoke INSERT query to populate the table
			query = SQLQuery.getQuery(SQLQuery.PERSONA_COMPLIANCE_PRE_INSERT2);
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.prepareStatement(query);

			result = stmt.executeUpdate();

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Inserted ").append(result).append(" record(s)"));
			}

			// Close the Statement
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing PreparedStatement. Resources might not be released ", e);
				}//end catch
			}
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Exiting PersonaComplianceDAO::insertGCGBasedCompliancePreRecords() ============>"));
			}

			return result;
			
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer("Exception caught attempting to insert records into table "+ e.getMessage()));
			e.printStackTrace();
			return -1;
		}
	}
	
	
	/**
	 * Inserts Matching GCG CNUMs into compliance_pre records
	 * @return
	 */
	public int insertGCGEmplBasedCompliancePreRecords(){
			
		String query = null;
		PreparedStatement stmt = null;
		int result = -1;

		
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaComplianceDAO::insertGCGEmplBasedCompliancePreRecords() <============"));
		
		try {

			// invoke INSERT query to populate the table
			query = SQLQuery.getQuery(SQLQuery.PERSONA_COMPLIANCE_PRE_INSERT3);
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.prepareStatement(query);

			result = stmt.executeUpdate();

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Inserted ").append(result).append(" record(s)"));
			}

			// Close the Statement
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing PreparedStatement. Resources might not be released ", e);
				}//end catch
			}
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Exiting PersonaComplianceDAO::insertGCGEmplBasedCompliancePreRecords() ============>"));
			}

			return result;
			
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer("Exception caught attempting to insert records into table "+ e.getMessage()));
			e.printStackTrace();
			return -1;
		}
	}
	
	
	/**
	 * Updates Compliance_PRE table data from NULL to 0.00 for DECIMAL types
	 * @return
	 */
	public int updateCompliancePreRecords(){
			
		String query = null;
		Statement stmt = null;
        ResultSet rs = null;
		int totalEmps = 0;
		int colCounter = 0;
		int rowCounter = 0;
//		boolean isUpdateReqd = false;
		
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaComplianceDAO::updateCompliancePreRecords() <============"));

		try {
			// invoke SELECT query to retrieve employee base data from the table
			query = SQLQuery.getQuery(SQLQuery.PERSONA_COMPLIANCE_PRE_SELECT);
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
		    
 			rs = stmt.executeQuery(query);
 
 			if (rs!=null){
				if(rs.last()){
					totalEmps = rs.getRow(); 
				    rs.beforeFirst();
				}
			
				if (isTestRun) {
					LOGGER.debug(new StringBuffer("Total # of employee records: ").append(totalEmps));
				}

				if (totalEmps <= 0 ) {
					LOGGER.error(new StringBuffer("No employee records exist in COMPLIANCE_PRE table "));
					return -1;
				}
			}else{
				//no result set retrieved
				if (isTestRun) {
					LOGGER.debug(new StringBuffer("No record found in COMPLIANCE_PRE table "));
				}
				return -1;
 			}	

			while (rs.next()) {
				
				ResultSetMetaData rsmd = rs.getMetaData();
				int totalColumns = rsmd.getColumnCount();
				
				for (colCounter=1; colCounter <= totalColumns; colCounter++) {
/*
					if (isTestRun) {
					 	LOGGER.debug(new StringBuffer("ColumnType[").append(colCounter).append("] = ").append(rsmd.getColumnType(colCounter)));
					}
*/					
					// look for columns with DECIMAL type, 0 means NULL
					if ( (rsmd.getColumnType(colCounter) == java.sql.Types.DECIMAL) && 
					     (rs.getDouble(colCounter) == 0 ) )  { // 0 means NULL

						// update DECIMAL fields into ResultSet from null to 0.00 for each record
						rs.updateDouble(colCounter, 0.00);
					}

					// look for columns with INTEGER type, 0 means NULL
					if ( (rsmd.getColumnType(colCounter) == java.sql.Types.INTEGER) && 
					     (rs.getInt(colCounter) == 0 ) )  { // 0 means NULL

							// update INTEGER fields into ResultSet from null to 0 for each record
							rs.updateInt(colCounter, 0);
						}

				}
						
		        rs.updateRow();
		        rowCounter++;
				if ((rowCounter % 10000 == 0) || (rowCounter == totalEmps)) {
					if (isTestRun)
						LOGGER.debug(new StringBuffer("[")
								.append(rowCounter)
								.append("] Compliance data updated (but not committed yet)"));
				}

			}
					
			// Connection must be on a unit-of-work boundary to allow close
			if ( conn != null) {
				conn.commit();
				if (isTestRun)
					LOGGER.debug(new StringBuffer(" Total Transaction(s) committed = ").append(rowCounter));
			}

		} catch (SQLException e) {
			LOGGER.error(new StringBuffer("Exception caught while getting base compliance_pre records from table "+ e.getMessage()));
			e.printStackTrace();
			return -1;
			
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
				}//end catch
			}//end if
			
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing Statement. Resources might not be released ", e);
				}//end catch
			}//end if
		}//end finally
	
		if (isTestRun) {
			LOGGER.debug(new StringBuffer("Exiting PersonaComplianceDAO::updateCompliancePreRecords() ============>"));
		}

		return totalEmps;
	}

	/**
	 * Retrieves compliance data from iLog
	 * @return
	 */
//	public int updateComplianceDataUsingILog(Connection con, Properties colNamesProps){
	public int updateComplianceDataUsingILog(Properties colNamesProps){
			
		String query = null;
		Statement stmt = null;
//		PreparedStatement updateStmt = null;
        ResultSet rs = null;
//		int result = -1;
		int totalEmps = 0;
		int counter = 0;
		
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaComplianceDAO::updateComplianceDataUsingILog() <============"));

		try {
			// invoke SELECT query to retrieve employee base data from the table
			query = SQLQuery.getQuery(SQLQuery.PERSONA_COMPLIANCE_PRE_SELECT);
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
		    
 			rs = stmt.executeQuery(query);
 
 			if (rs!=null){
				if(rs.last()){
					totalEmps = rs.getRow(); 
				    rs.beforeFirst();
				}
			
				if (isTestRun) {
					LOGGER.debug(new StringBuffer("Total # of employee records: ").append(totalEmps));
				}

				if (totalEmps <= 0 ) {
					LOGGER.error(new StringBuffer("No employee records exist in COMPLIANCE_PRE table "));
					return -1;
				}
			}else{
				//no result set retrieved
				if (isTestRun) {
					LOGGER.debug(new StringBuffer("No record found in COMPLIANCE_PRE table "));
				}
				return -1;
 			}	
			
			// load Ilog engine - get ready
			EmbeddedIlogService ilog = new EmbeddedIlogService();			

			while (rs.next()) {
				
				ComplianceForIlog complianceIn = new ComplianceForIlog();

				// update compliance data for only first 1000 records
//				if ( counter >= 10 ) {
//					break;
//				} else {
					counter = counter + 1;
					
					String cnum = rs.getString(colNamesProps.getProperty("stage1_CNUM").trim());
	
					//Stage 1
					String countryCode = rs.getString(colNamesProps.getProperty("stage1_COUNTRYCODE").trim()); 
					complianceIn.setCountryCode(countryCode);

					//Stage 8
					Double cellPhoneAvg = rs.getDouble(colNamesProps.getProperty("stage4_CELLPHONEAVERAGE").trim()); 
					complianceIn.setCellphoneAverage(cellPhoneAvg);
	
					Double basicCellCPC = rs.getDouble(colNamesProps.getProperty("stage3_BASICCELLCPC").trim());
					complianceIn.setBasicCellCpc(basicCellCPC);
	
					Double smartPhoneAvg = rs.getDouble(colNamesProps.getProperty("stage4_SMARTPHONEAVERAGE").trim()); 
					complianceIn.setSmartphoneAverage(smartPhoneAvg);
					
					Double smartPhoneCPC = rs.getDouble(colNamesProps.getProperty("stage3_SMARTPHONECPC").trim());
					complianceIn.setSmartphoneCpc(smartPhoneCPC);
					
					Double dataCardCPC = rs.getDouble(colNamesProps.getProperty("stage3_DATACARDCPC").trim());
					complianceIn.setDatacardCpc(dataCardCPC);
	
					Double homeOfficeAvg = rs.getDouble(colNamesProps.getProperty("stage4_HOMEOFFICEVOICEAVERAGE").trim());
					complianceIn.setHomeOfficeAverage(homeOfficeAvg);
	
					Double dataCardAvg = rs.getDouble(colNamesProps.getProperty("stage4_DATACARDAVERAGE").trim()); 
					complianceIn.setDatacardAverage(dataCardAvg);
				
					//Stage 9a				
					String mobCmpSP = rs.getString(colNamesProps.getProperty("stage6_SMARTPHONEMOBCMP").trim());
					if (mobCmpSP == null) mobCmpSP = "";
					else complianceIn.setSpMobCmp(mobCmpSP);
					
					String mobWwerSP = rs.getString(colNamesProps.getProperty("stage6_SMARTPHONEMOBWWER").trim());
					if (mobWwerSP == null) mobWwerSP = "";
					else complianceIn.setSpMobWwer(mobWwerSP);
	
					// Rel 4.0 changes - Not in Olivier's Simulator code
//					String smartPhoneSvc = rs.getString(colNamesProps.getProperty("stage2_SMARTPHONESERVICE").trim());
					String smartPhoneSvc = rs.getString(colNamesProps.getProperty("stage9_ISEMPELIGIBLEFORSERVICESP").trim());
					if (smartPhoneSvc == null) smartPhoneSvc = "";
					else complianceIn.setSmartphoneService(smartPhoneSvc);

					Double countryClipLevelSP = rs.getDouble(colNamesProps.getProperty("stage9_COUNTRYCLIPLEVELSP").trim());
					
					if (smartPhoneSvc.equalsIgnoreCase("No"))
						countryClipLevelSP = 10.01;
					complianceIn.setCountryClipLevelSp(countryClipLevelSP);

					String cmpCountrySP = rs.getString(colNamesProps.getProperty("stage9_ISEMPWITHINACMPCOUNTRYSP").trim());
					if (cmpCountrySP == null) cmpCountrySP = "";
					else complianceIn.setCmpCountry(cmpCountrySP);
					
					Double smartPhoneCC = rs.getDouble(colNamesProps.getProperty("stage3_SMARTPHONECC").trim());
					complianceIn.setSmartphoneCc(smartPhoneCC);
					
					//Stage 9b
					String mobCmpCP = rs.getString(colNamesProps.getProperty("stage6_CELLPHONEMOBCMP").trim());
					if (mobCmpCP == null) mobCmpCP = "";
					else complianceIn.setCpMobCmp(mobCmpCP);
					
					String mobWwerCP = rs.getString(colNamesProps.getProperty("stage6_CELLPHONEMOBWWER").trim());
					if (mobWwerCP == null) mobWwerCP = "";
					else complianceIn.setCpMobWwer(mobWwerCP);
					
					// Rel 4.0 changes
//					String cellPhoneSvc = rs.getString(colNamesProps.getProperty("stage2_BASICCELLFEATUREPHONESERVICE").trim());
					String cellPhoneSvc = rs.getString(colNamesProps.getProperty("stage9_ISEMPELIGIBLEFORSERVICECP").trim());
					if (cellPhoneSvc == null) cellPhoneSvc = "";
					else complianceIn.setCellphoneService(cellPhoneSvc);
					
					Double countryClipLevelCP = rs.getDouble(colNamesProps.getProperty("stage9_COUNTRYCLIPLEVELCP").trim());
					
					if (cellPhoneSvc.equalsIgnoreCase("No"))
						countryClipLevelCP = 10.01;
					complianceIn.setCountryClipLevelCp(countryClipLevelCP);
					
					Double basicCellCC = rs.getDouble(colNamesProps.getProperty("stage3_BASICCELLCC").trim());
					complianceIn.setBasicCellCc(basicCellCC);

					//Stage 9c
					String datCmpDC = rs.getString(colNamesProps.getProperty("stage6_DATACARDDATCMP").trim());
					if (datCmpDC == null) datCmpDC = "";
					else complianceIn.setDcDatCmp(datCmpDC);
					
					String datWwerDC = rs.getString(colNamesProps.getProperty("stage6_DATACARDDATWWER").trim());
					if (datWwerDC == null) datWwerDC = "";
					else complianceIn.setDcDatWwer(datWwerDC);
					
					//String dataCardSvc = rs.getString(?????);
//					String dataCardSvc = "No";
//					if (dataCardSvc == null) dataCardSvc = "";
//					else 
//					complianceIn.setDatacardService(dataCardSvc);
					
					// Rel 4.0 changes - Not in Olivier's Simulator code
					String dataCardSvc = rs.getString(colNamesProps.getProperty("stage9_ISEMPELIGIBLEFORSERVICEDC").trim());
					if (dataCardSvc == null) dataCardSvc = "";
					else complianceIn.setDatacardService(dataCardSvc);
					
					Double countryClipLevelDC = rs.getDouble(colNamesProps.getProperty("stage9_COUNTRYCLIPLEVELDC").trim());
					
					if (dataCardSvc.equalsIgnoreCase("No"))
						countryClipLevelDC = 10.01;
					complianceIn.setCountryClipLevelDc(countryClipLevelDC);
					
					Double dataCardCC = rs.getDouble(colNamesProps.getProperty("stage3_DATACARDCC").trim());
					complianceIn.setDatacardCc(dataCardCC);
					
					//Stage 9d
					// Rel 4.0 changes
//					String hovCmpHve = "No";
					String hovCmpHve = rs.getString(colNamesProps.getProperty("stage9_EXCEPTIONMOBCMPHOV").trim());
					if (hovCmpHve == null) hovCmpHve = "";
					complianceIn.setHovCmp(hovCmpHve);

					String hovWwerHve = rs.getString(colNamesProps.getProperty("stage6_HOMEVOICEHVEWWER").trim());
					if (hovWwerHve == null) hovWwerHve = "";
					else complianceIn.setHovHveWwer(hovWwerHve);
					
					// Rel 4.0 changes - Not in Olivier's Simulator code
//					String hovSvc = rs.getString(colNamesProps.getProperty("stage2_HOMEOFFICELANDLINE").trim());
					String hovSvc = rs.getString(colNamesProps.getProperty("stage9_ISEMPELIGIBLEFORSERVICEHOV").trim());
					if (hovSvc == null) hovSvc = "";
					else complianceIn.setHomeofficevoiceService(hovSvc);
				
					Double countryClipLevelHov = rs.getDouble(colNamesProps.getProperty("stage9_COUNTRYCLIPLEVELHOV").trim());
					
					if (hovSvc.equalsIgnoreCase("No"))
						countryClipLevelHov = 10.01;
					complianceIn.setCountryClipLevelHov(countryClipLevelHov);
					
					Double hovCC = rs.getDouble(colNamesProps.getProperty("stage3_HOMEOFFICEVOICECC").trim());
					complianceIn.setHomeofficevoiceCc(hovCC);					
					
					//add HomeVoiceKFR 06092015
					Double hovCPC = rs.getDouble(colNamesProps.getProperty("stage3_HOMEOFFICEVOICECPC").trim());
					complianceIn.setHomeOfficeCpc(hovCPC);
										
					if (cnum.equalsIgnoreCase("001164624") ||
						cnum.equalsIgnoreCase("0D8266897") ||
						cnum.equalsIgnoreCase("027323649") ||
						cnum.equalsIgnoreCase("047118672") ||
						cnum.equalsIgnoreCase("078300672") ||
						cnum.equalsIgnoreCase("0A8224649") ||
						cnum.equalsIgnoreCase("991005897") ||
						cnum.equalsIgnoreCase("0D8905649") ||
						cnum.equalsIgnoreCase("158588724") ) {
						if (isTestRun) {
							 LOGGER.debug(new StringBuffer("[").append(counter).append("] Compliance Data Input to iLog engine for cnum = ").append(cnum));
							 LOGGER.debug(new StringBuffer(" Country Code = ").append(countryCode));
//							 LOGGER.debug(new StringBuffer(" Executive Level = ").append(execLevel));
							 LOGGER.debug(new StringBuffer(" Smart Phone CPC = ").append(smartPhoneCPC));
							 LOGGER.debug(new StringBuffer(" Data Card CPC = ").append(dataCardCPC));
							 LOGGER.debug(new StringBuffer(" Basic Cell CPC = ").append(basicCellCPC));
							 LOGGER.debug(new StringBuffer(" Smart Phone CC = ").append(smartPhoneCC));
							 LOGGER.debug(new StringBuffer(" Data Card CC = ").append(dataCardCC));
							 LOGGER.debug(new StringBuffer(" Basic Cell CC = ").append(basicCellCC));
							 LOGGER.debug(new StringBuffer(" Home OFffice Voice CC = ").append(hovCC));
							 LOGGER.debug(new StringBuffer(" Home OFffice Voice CPC = ").append(hovCPC));
							 LOGGER.debug(new StringBuffer(" Country Clip Level SP = ").append(countryClipLevelSP));
							 LOGGER.debug(new StringBuffer(" Country Clip Level CP = ").append(countryClipLevelCP));
							 LOGGER.debug(new StringBuffer(" Country Clip Level DC = ").append(countryClipLevelDC));		
							 LOGGER.debug(new StringBuffer(" Country Clip Level HOV = ").append(countryClipLevelHov));		
							 LOGGER.debug(new StringBuffer(" Cell Phone Average = ").append(cellPhoneAvg));
							 LOGGER.debug(new StringBuffer(" Data Card Average = ").append(dataCardAvg));
							 LOGGER.debug(new StringBuffer(" Smart Phone Average = ").append(smartPhoneAvg));
							 LOGGER.debug(new StringBuffer(" Home Office Average = ").append(homeOfficeAvg));

							 LOGGER.debug(new StringBuffer(" MOB-CMP SP= ").append(mobCmpSP));
							 LOGGER.debug(new StringBuffer(" MOB-WWER SP= ").append(mobWwerSP));
							 LOGGER.debug(new StringBuffer(" MOB-CMP CP= ").append(mobCmpCP));
							 LOGGER.debug(new StringBuffer(" MOB-WWER CP= ").append(mobWwerCP));
							 LOGGER.debug(new StringBuffer(" DAT-CMP DC= ").append(datCmpDC));
							 LOGGER.debug(new StringBuffer(" DAT-WWER DC= ").append(datWwerDC));
							 LOGGER.debug(new StringBuffer(" HOV-CMP HVE= ").append(hovCmpHve));
							 LOGGER.debug(new StringBuffer(" HOV-WWER HVE= ").append(hovWwerHve));
							 LOGGER.debug(new StringBuffer(" Smart Phone Service = ").append(smartPhoneSvc));
							 LOGGER.debug(new StringBuffer(" Cell Phone Service = ").append(cellPhoneSvc));
							 LOGGER.debug(new StringBuffer(" Data Card Service = ").append(dataCardSvc));
							 LOGGER.debug(new StringBuffer(" Home OFffice Voice Service = ").append(hovSvc));
							 LOGGER.debug(new StringBuffer(" Employee CMP Country SP = ").append(cmpCountrySP));

							 LOGGER.debug(new StringBuffer("[").append(counter).
									 append("] Invoking iLog Engine to get the compliance data for CNUM = ").append(cnum));
						}						
					}
	
					if ((counter % 10000 == 0) || (counter == totalEmps)) {
						if (isTestRun) {
							LOGGER.debug(new StringBuffer("[")
									.append(counter)
									.append("] Invoking iLog Engine to get the compliance data for CNUM = ")
									.append(cnum));
						}
					}
					
					// invoke iLog engine for this employee		
					ComplianceForIlog complianceOut = ilog.getComplianceForThisEmployee(complianceIn);
					Double clipLevelSp = 0.00;
					Double clipLevelCp = 0.00;
					Double clipLevelDc = 0.00;
					Double clipLevelHov = 0.00;
				
					// retrieve compliance fields from ComplianceOut object
					
					//Stage 8
					String basicCell = complianceOut.getBasicCell();
					String smartPhone = complianceOut.getSmartphone();
					String homeVoice = complianceOut.getHomevoice();
					String multiSvcCheck = complianceOut.getMultiServiceCheck();

					//Stage 8b
					String multiSvcCheck2 = complianceOut.getMultiServiceCheck2();				
					String basicCell2 = complianceOut.getBasicCellSecondExpense();
					String smartPhone2 = complianceOut.getSmartphoneSecondExpense();					
					String homeVoice2 = complianceOut.getHomeVoiceSecondExpense();				

					//Stage 9a
					String spCompliance = complianceOut.getSmartphoneCompliance();
					String kfrCpcSpecialBillingHasExpSp = complianceOut.getKfrCpcSpecialBillingHasExpSp();
					String wwerExpIsBetweenZeroAndClipLevelSp = complianceOut.getWwerexpIsBetweenZeroAndClipLevelSp();
					String wwerExpIsAboveClipLevelSp = complianceOut.getWwerExpIsAboveClipLevelSp();
					String isEmpWithinCmpCountrySp = complianceOut.getIsEmpWithinCmpCountrySp();
					String isEmpEligibleForServiceSp = complianceOut.getIsEmpEligibleForServiceSp();
					clipLevelSp = complianceOut.getCountryClipLevelSp();
					String kfrCcSpecialBillingHasExpSp = complianceOut.getKfrCcSpecialBillingHasExpSp();
					String exceptionMobCmpSp = complianceOut.getExceptionMobCmpSp();
					String exceptionMobWwerSp = complianceOut.getExceptionMobWwerSp();
					String combinationSp = wwerExpIsAboveClipLevelSp + isEmpWithinCmpCountrySp + 
							isEmpEligibleForServiceSp + kfrCcSpecialBillingHasExpSp + 
							exceptionMobCmpSp + exceptionMobWwerSp;
					
					//Stage 9b
					String cpCompliance = complianceOut.getCellphoneCompliance();
					String kfrCpcSpecialBillingHasExpCp = complianceOut.getKfrCpcSpecialBillingHasExpCp();
					String wwerexpIsBetweenZeroAndClipLevelCp = complianceOut.getWwerexpIsBetweenZeroAndClipLevelCp();
					String wwerExpIsAboveClipLevelCp = complianceOut.getWwerExpIsAboveClipLevelCp();
					String isEmpWithinCmpCountryCp = complianceOut.getIsEmpWithinCmpCountryCp();
					String isEmpEligibleForServiceCp = complianceOut.getIsEmpEligibleForServiceCp();
					clipLevelCp = complianceOut.getCountryClipLevelCp();
					String kfrCcSpecialBillingHasExpCp = complianceOut.getKfrCcSpecialBillingHasExpCp();
					String exceptionMobCmpCp = complianceOut.getExceptionMobCmpCp();
					String exceptionMobWwerCp = complianceOut.getExceptionMobWwerCp();
					String combinationCp = wwerExpIsAboveClipLevelCp + isEmpWithinCmpCountryCp + 
							isEmpEligibleForServiceCp + kfrCcSpecialBillingHasExpCp + 
							exceptionMobCmpCp + exceptionMobWwerCp;
					
					//Stage 9c
					String dcCompliance = complianceOut.getDatacardCompliance();
					String kfrCpcSpecialBillingHasExpDc = complianceOut.getKfrCpcSpecialBillingHasExpDc();
					String wwerexpIsBetweenZeroAndClipLevelDc = complianceOut.getWwerexpIsBetweenZeroAndClipLevelDc();
					String wwerExpIsAboveClipLevelDc = complianceOut.getWwerExpIsAboveClipLevelDc();
					String isEmpWithinCmpCountryDc = complianceOut.getIsEmpWithinCmpCountryDc();
					String isEmpEligibleForServiceDc = complianceOut.getIsEmpEligibleForServiceDc();
					clipLevelDc = complianceOut.getCountryClipLevelDc();
					String kfrCcSpecialBillingHasExpDc = complianceOut.getKfrCcSpecialBillingHasExpDc();
					String exceptionDatCmpDc = complianceOut.getExceptionDatCmpDc();
					String exceptionDatWwerDc = complianceOut.getExceptionDatWwerDc();
					String combinationDc = wwerExpIsAboveClipLevelDc + isEmpWithinCmpCountryDc + 
							isEmpEligibleForServiceDc + kfrCcSpecialBillingHasExpDc + 
							exceptionDatCmpDc + exceptionDatWwerDc;
					
					//Stage 9d
					String hovCompliance = complianceOut.getHomeofficevoiceCompliance();
					String kfrCpcSpecialBillingHasExpHov = complianceOut.getKfrCpcSpecialBillingHasExpHov();
					String wwerexpIsBetweenZeroAndClipLevelHov = complianceOut.getWwerexpIsBetweenZeroAndClipLevelHov();
					String wwerExpIsAboveClipLevelHov = complianceOut.getWwerExpIsAboveClipLevelHov();
					String isEmpWithinCmpCountryHov = complianceOut.getIsEmpWithinCmpCountryHov();
					String isEmpEligibleForServiceHov = complianceOut.getIsEmpEligibleForServiceHov();
					clipLevelHov = complianceOut.getCountryClipLevelHov();
					String kfrCcSpecialBillingHasExpHov = complianceOut.getKfrCcSpecialBillingHasExpHov();
					String exceptionMobCmpHov = complianceOut.getExceptionMobCmpHov();
					String exceptionMobHveWwerHov = complianceOut.getExceptionMobHveWwerHov();
					String combinationHov = wwerExpIsAboveClipLevelHov + isEmpWithinCmpCountryHov + 
							isEmpEligibleForServiceHov + kfrCcSpecialBillingHasExpHov + 
							exceptionMobCmpHov + exceptionMobHveWwerHov;
					
					//Stage 10
					String overallCompliance = complianceOut.getOverallCompliance();					
					String explanation1Multi = complianceOut.getExplanation1Multi();
					String explanation1Multi2 = complianceOut.getExplanation1Multi2();
					String explanation2Smartphone = complianceOut.getExplanation2Smartphone();
					String explanation2BSmartphone = complianceOut.getExplanation2BSmartphone();	
					String explanation3Cell = complianceOut.getExplanation3Cell();
					String explanation3BCell = complianceOut.getExplanation3BCell();
					String explanation4Datacard = complianceOut.getExplanation4Datacard();
					String explanation4BDatacard = complianceOut.getExplanation4BDatacard();
					String explanation5Hov = complianceOut.getExplanation5Hov();
					String explanation5BHov = complianceOut.getExplanation5BHov();
					String explanation6Hin = "";
					String explanation6BHin = "";
					String explanation7Tab = "";
					String explanation7BTab = "";
					String explanation8TBD = "";
					String explanation8BTBD = "";
					String collectionOfNonCompliantExplanation = complianceOut.getCollectionOfNonCompliantExplanation();
					
					//Stage 11
					String summaryOfNonCompliantExplanation = complianceOut.getSummaryOfNonCompliantExplanation();
	
					//Stage 12
					String realOverallCompliance = complianceOut.getRealOverallCompliance();
					
					if (cnum.equalsIgnoreCase("001164624") ||
						cnum.equalsIgnoreCase("0D8266897") ||
						cnum.equalsIgnoreCase("027323649") ||
						cnum.equalsIgnoreCase("047118672") ||
						cnum.equalsIgnoreCase("078300672") ||
						cnum.equalsIgnoreCase("0A8224649") ||
						cnum.equalsIgnoreCase("991005897") ||
						cnum.equalsIgnoreCase("0D8905649") ||
						cnum.equalsIgnoreCase("158588724") ) {
						if (isTestRun) {
							 LOGGER.debug(new StringBuffer(" Compliance Data Output from iLog engine for cnum = ").append(cnum));

							 LOGGER.debug(new StringBuffer(" basicCell = ").append(basicCell));
							 LOGGER.debug(new StringBuffer(" smartPhone = ").append(smartPhone));
							 LOGGER.debug(new StringBuffer(" homeVoice = ").append(homeVoice));
							 LOGGER.debug(new StringBuffer(" multiSvcCheck = ").append(multiSvcCheck));

							 LOGGER.debug(new StringBuffer(" multiSvcCheck2 = ").append(multiSvcCheck2));
							 LOGGER.debug(new StringBuffer(" basicCell2 = ").append(basicCell2));
							 LOGGER.debug(new StringBuffer(" smartPhone2 = ").append(smartPhone2));
							 LOGGER.debug(new StringBuffer(" homeVoice2 = ").append(homeVoice2));

							 LOGGER.debug(new StringBuffer(" spCompliance = ").append(spCompliance));
							 LOGGER.debug(new StringBuffer(" kfrCpcSpecialBillingHasExpSp = ").append(kfrCpcSpecialBillingHasExpSp));
							 LOGGER.debug(new StringBuffer(" wwerExpIsBetweenZeroAndClipLevelSp = ").append(wwerExpIsBetweenZeroAndClipLevelSp));
							 LOGGER.debug(new StringBuffer(" wwerExpIsAboveClipLevelSp = ").append(wwerExpIsAboveClipLevelSp));
							 LOGGER.debug(new StringBuffer(" isEmpWithinCmpCountrySp = ").append(isEmpWithinCmpCountrySp));		
							 LOGGER.debug(new StringBuffer(" isEmpEligibleForServiceSp = ").append(isEmpEligibleForServiceSp));		
							 LOGGER.debug(new StringBuffer(" clipLevelSp = ").append(clipLevelSp));		
							 LOGGER.debug(new StringBuffer(" kfrCcSpecialBillingHasExpSp = ").append(kfrCcSpecialBillingHasExpSp));
							 LOGGER.debug(new StringBuffer(" exceptionMobCmpSp = ").append(exceptionMobCmpSp));
							 LOGGER.debug(new StringBuffer(" exceptionMobWwerSp = ").append(exceptionMobWwerSp));
							 LOGGER.debug(new StringBuffer(" combinationSp = ").append(combinationSp));
							 
							 LOGGER.debug(new StringBuffer(" cpCompliance = ").append(cpCompliance));
							 LOGGER.debug(new StringBuffer(" kfrCpcSpecialBillingHasExpCp = ").append(kfrCpcSpecialBillingHasExpCp));
							 LOGGER.debug(new StringBuffer(" wwerexpIsBetweenZeroAndClipLevelCp = ").append(wwerexpIsBetweenZeroAndClipLevelCp));
							 LOGGER.debug(new StringBuffer(" wwerExpIsAboveClipLevelCp = ").append(wwerExpIsAboveClipLevelCp));
							 LOGGER.debug(new StringBuffer(" isEmpWithinCmpCountryCp = ").append(isEmpWithinCmpCountryCp));		
							 LOGGER.debug(new StringBuffer(" isEmpEligibleForServiceCp = ").append(isEmpEligibleForServiceCp));		
							 LOGGER.debug(new StringBuffer(" clipLevelCp = ").append(clipLevelCp));		
							 LOGGER.debug(new StringBuffer(" kfrCcSpecialBillingHasExpCp = ").append(kfrCcSpecialBillingHasExpCp));
							 LOGGER.debug(new StringBuffer(" exceptionMobCmpCp = ").append(exceptionMobCmpCp));
							 LOGGER.debug(new StringBuffer(" exceptionMobWwerCp = ").append(exceptionMobWwerCp));
							 LOGGER.debug(new StringBuffer(" combinationCp = ").append(combinationCp));
							 
							 LOGGER.debug(new StringBuffer(" dcCompliance = ").append(dcCompliance));
							 LOGGER.debug(new StringBuffer(" kfrCpcSpecialBillingHasExpDc = ").append(kfrCpcSpecialBillingHasExpDc));
							 LOGGER.debug(new StringBuffer(" wwerexpIsBetweenZeroAndClipLevelDc = ").append(wwerexpIsBetweenZeroAndClipLevelDc));
							 LOGGER.debug(new StringBuffer(" wwerExpIsAboveClipLevelDc = ").append(wwerExpIsAboveClipLevelDc));
							 LOGGER.debug(new StringBuffer(" isEmpWithinCmpCountryDc = ").append(isEmpWithinCmpCountryDc));		
							 LOGGER.debug(new StringBuffer(" isEmpEligibleForServiceDc = ").append(isEmpEligibleForServiceDc));		
							 LOGGER.debug(new StringBuffer(" clipLevelDc = ").append(clipLevelDc));		
							 LOGGER.debug(new StringBuffer(" kfrCcSpecialBillingHasExpDc = ").append(kfrCcSpecialBillingHasExpDc));
							 LOGGER.debug(new StringBuffer(" exceptionDatCmpDc = ").append(exceptionDatCmpDc));
							 LOGGER.debug(new StringBuffer(" exceptionDatWwerDc = ").append(exceptionDatWwerDc));
							 LOGGER.debug(new StringBuffer(" combinationDc = ").append(combinationDc));
							 
							 LOGGER.debug(new StringBuffer(" hovCompliance = ").append(hovCompliance));
							 LOGGER.debug(new StringBuffer(" kfrCpcSpecialBillingHasExpHov = ").append(kfrCpcSpecialBillingHasExpHov));
							 LOGGER.debug(new StringBuffer(" wwerexpIsBetweenZeroAndClipLevelHov = ").append(wwerexpIsBetweenZeroAndClipLevelHov));
							 LOGGER.debug(new StringBuffer(" wwerExpIsAboveClipLevelHov = ").append(wwerExpIsAboveClipLevelHov));
							 LOGGER.debug(new StringBuffer(" isEmpWithinCmpCountryHov = ").append(isEmpWithinCmpCountryHov));		
							 LOGGER.debug(new StringBuffer(" isEmpEligibleForServiceHov = ").append(isEmpEligibleForServiceHov));		
							 LOGGER.debug(new StringBuffer(" clipLevelHov = ").append(clipLevelHov));		
							 LOGGER.debug(new StringBuffer(" kfrCcSpecialBillingHasExpHov = ").append(kfrCcSpecialBillingHasExpHov));
							 LOGGER.debug(new StringBuffer(" exceptionMobCmpHov = ").append(exceptionMobCmpHov));
							 LOGGER.debug(new StringBuffer(" exceptionMobHveWwerHov = ").append(exceptionMobHveWwerHov));
							 LOGGER.debug(new StringBuffer(" combinationHov = ").append(combinationHov));

							 LOGGER.debug(new StringBuffer(" overallCompliance = ").append(overallCompliance));
							 LOGGER.debug(new StringBuffer(" explanation1Multi = ").append(explanation1Multi));
							 LOGGER.debug(new StringBuffer(" explanation1Multi2 = ").append(explanation1Multi2));
							 LOGGER.debug(new StringBuffer(" explanation2Smartphone = ").append(explanation2Smartphone));
							 LOGGER.debug(new StringBuffer(" explanation2BSmartphone = ").append(explanation2BSmartphone));
							 LOGGER.debug(new StringBuffer(" explanation3Cell = ").append(explanation3Cell));
							 LOGGER.debug(new StringBuffer(" explanation3BCell = ").append(explanation3BCell));
							 LOGGER.debug(new StringBuffer(" explanation4Datacard = ").append(explanation4Datacard));
							 LOGGER.debug(new StringBuffer(" explanation4BDatacard = ").append(explanation4BDatacard));
							 LOGGER.debug(new StringBuffer(" explanation5Hov = ").append(explanation5Hov));
							 LOGGER.debug(new StringBuffer(" explanation5BHov = ").append(explanation5BHov));
							 LOGGER.debug(new StringBuffer(" explanation6Hin = ").append(explanation6Hin));
							 LOGGER.debug(new StringBuffer(" explanation6BHin = ").append(explanation6BHin));
							 LOGGER.debug(new StringBuffer(" explanation7Tab = ").append(explanation7Tab));
							 LOGGER.debug(new StringBuffer(" explanation7BTab = ").append(explanation7BTab));
							 LOGGER.debug(new StringBuffer(" explanation8TBD = ").append(explanation8TBD));
							 LOGGER.debug(new StringBuffer(" explanation8BTBD = ").append(explanation8BTBD));
							 LOGGER.debug(new StringBuffer(" collectionOfNonCompliantExplanation = ").append(collectionOfNonCompliantExplanation));
							
							 LOGGER.debug(new StringBuffer(" summaryOfNonCompliantExplanation = ").append(summaryOfNonCompliantExplanation));

							 LOGGER.debug(new StringBuffer(" realOverallCompliance = ").append(realOverallCompliance));
						}
					}
					
/*** Why is this here ???????					
					if (cnum.equalsIgnoreCase("017986897") ||
					    cnum.equalsIgnoreCase("029694897")) {		
//							continue;
					}
********/
					
/*					
					// invoke UPDATE query to update employee base data into the table
					query = SQLQuery.getQuery(SQLQuery.PERSONA_COMPLIANCE_PRE_UPDATE);
					
					if (isTestRun)
						LOGGER.debug(new StringBuffer("executing query: ").append(query));
					
					updateStmt = conn.prepareStatement(query);
*/
					
					// update fields into ResultSet to update each record

					//Stage 8
					rs.updateString(colNamesProps.getProperty("stage8_BASICCELL").trim(),basicCell);
					rs.updateString(colNamesProps.getProperty("stage8_SMARTPHONE").trim(),smartPhone);
					rs.updateString(colNamesProps.getProperty("stage8_HOMEVOICE").trim(),homeVoice);
					rs.updateString(colNamesProps.getProperty("stage8_MULTISERVICECHECK").trim(),multiSvcCheck);
					
					//Stage 8B
					rs.updateString(colNamesProps.getProperty("stage8_MULTISERVICECHECK2").trim(),multiSvcCheck2);
					rs.updateString(colNamesProps.getProperty("stage8_BASICCELLMULTI2").trim(),basicCell2);
					rs.updateString(colNamesProps.getProperty("stage8_SMARTPHONEMULTI2").trim(),smartPhone2);
					rs.updateString(colNamesProps.getProperty("stage8_HOVMULTI2").trim(),homeVoice2);
/*
					if (cnum.equalsIgnoreCase("743261897") ||
						cnum.equalsIgnoreCase("744192897") ||
						cnum.equalsIgnoreCase("2D2781897") ||
						cnum.equalsIgnoreCase("0A5341897") ) {

						 		 LOGGER.debug(new StringBuffer(" Again cnum = ").append(cnum));
								 LOGGER.debug(new StringBuffer(" multiSvcCheck2 = ").append(multiSvcCheck2));
								 LOGGER.debug(new StringBuffer(" basicCell2 = ").append(basicCell2));
								 LOGGER.debug(new StringBuffer(" smartPhone2 = ").append(smartPhone2));

									rs.updateString("MULTISERVICECHECK2",multiSvcCheck2);
									rs.updateString(colNamesProps.getProperty("stage8_BASICCELLMULTI2").trim(),"Cell");
									rs.updateString(colNamesProps.getProperty("stage8_SMARTPHONEMULTI2").trim(),"SmartPhone");
					}
*/
					
					//Stage 9a
					rs.updateString(colNamesProps.getProperty("stage9_SMARTPHONECOMPLIANCE").trim(),spCompliance);
					rs.updateDouble(colNamesProps.getProperty("stage9_COUNTRYCLIPLEVELSP").trim(),clipLevelSp.doubleValue());
					rs.updateString(colNamesProps.getProperty("stage9_COMBINATIONSP").trim(),combinationSp);
					rs.updateString(colNamesProps.getProperty("stage9_KFRCPCSPECIALBILLINGHASEXPSP").trim(),kfrCpcSpecialBillingHasExpSp);
					rs.updateString(colNamesProps.getProperty("stage9_WWEREXPISBETWEENZEROANDCLIPLEVELSP").trim(),wwerExpIsBetweenZeroAndClipLevelSp);
					rs.updateString(colNamesProps.getProperty("stage9_WWEREXPISABOVECLIPLEVELSP").trim(),wwerExpIsAboveClipLevelSp);
//					rs.updateString(11,isEmpWithinCmpCountrySp);
					rs.updateString(colNamesProps.getProperty("stage9_ISEMPELIGIBLEFORSERVICESP").trim(),isEmpEligibleForServiceSp);
					rs.updateString(colNamesProps.getProperty("stage9_KFRCCSPECIALBILLINGHASEXPSP").trim(),kfrCcSpecialBillingHasExpSp);
					rs.updateString(colNamesProps.getProperty("stage9_EXCEPTIONMOBCMPSP").trim(),exceptionMobCmpSp);
					rs.updateString(colNamesProps.getProperty("stage9_EXCEPTIONMOBWWERSP").trim(),exceptionMobWwerSp);
					
					//Stage 9b
					rs.updateString(colNamesProps.getProperty("stage9_CELLPHONECOMPLIANCE").trim(),cpCompliance);
					rs.updateDouble(colNamesProps.getProperty("stage9_COUNTRYCLIPLEVELCP").trim(),clipLevelCp.doubleValue());
					rs.updateString(colNamesProps.getProperty("stage9_COMBINATIONCP").trim(),combinationCp);
					rs.updateString(colNamesProps.getProperty("stage9_KFRCPCSPECIALBILLINGHASEXPCP").trim(),kfrCpcSpecialBillingHasExpCp);
					rs.updateString(colNamesProps.getProperty("stage9_WWEREXPISBETWEENZEROANDCLIPLEVELCP").trim(),wwerexpIsBetweenZeroAndClipLevelCp);
					rs.updateString(colNamesProps.getProperty("stage9_WWEREXPISABOVECLIPLEVELCP").trim(),wwerExpIsAboveClipLevelCp);
//					rs.updateString(21,isEmpWithinCmpCountryCp);
					rs.updateString(colNamesProps.getProperty("stage9_ISEMPELIGIBLEFORSERVICECP").trim(),isEmpEligibleForServiceCp);
					rs.updateString(colNamesProps.getProperty("stage9_KFRCCSPECIALBILLINGHASEXPCP").trim(),kfrCcSpecialBillingHasExpCp);
					rs.updateString(colNamesProps.getProperty("stage9_EXCEPTIONMOBCMPCP").trim(),exceptionMobCmpCp);
					rs.updateString(colNamesProps.getProperty("stage9_EXCEPTIONMOBWWERCP").trim(),exceptionMobWwerCp);
					
					//Stage 9c
					rs.updateString(colNamesProps.getProperty("stage9_DATACARDCOMPLIANCE").trim(),dcCompliance);
					rs.updateDouble(colNamesProps.getProperty("stage9_COUNTRYCLIPLEVELDC").trim(),clipLevelDc.doubleValue());
					rs.updateString(colNamesProps.getProperty("stage9_COMBINATIONDC").trim(),combinationDc);
					rs.updateString(colNamesProps.getProperty("stage9_KFRCPCSPECIALBILLINGHASEXPDC").trim(),kfrCpcSpecialBillingHasExpDc);
					rs.updateString(colNamesProps.getProperty("stage9_WWEREXPISBETWEENZEROANDCLIPLEVELDC").trim(),wwerexpIsBetweenZeroAndClipLevelDc);
					rs.updateString(colNamesProps.getProperty("stage9_WWEREXPISABOVECLIPLEVELDC").trim(),wwerExpIsAboveClipLevelDc);
//					rs.updateString(31,isEmpWithinCmpCountryDc);
					rs.updateString(colNamesProps.getProperty("stage9_ISEMPELIGIBLEFORSERVICEDC").trim(),isEmpEligibleForServiceDc);
					rs.updateString(colNamesProps.getProperty("stage9_KFRCCSPECIALBILLINGHASEXPDC").trim(),kfrCcSpecialBillingHasExpDc);
					rs.updateString(colNamesProps.getProperty("stage9_EXCEPTIONMOBCMPDC").trim(),exceptionDatCmpDc);
					rs.updateString(colNamesProps.getProperty("stage9_EXCEPTIONMOBWWERDC").trim(),exceptionDatWwerDc);
					
					//Stage 9d
					rs.updateString(colNamesProps.getProperty("stage9_HOMEOFFICEVOICECOMPLIANCE").trim(),hovCompliance);
					rs.updateDouble(colNamesProps.getProperty("stage9_COUNTRYCLIPLEVELHOV").trim(),clipLevelHov.doubleValue());
					rs.updateString(colNamesProps.getProperty("stage9_COMBINATIONHOV").trim(),combinationHov);
					rs.updateString(colNamesProps.getProperty("stage9_KFRCPCSPECIALBILLINGHASEXPHOV").trim(),kfrCpcSpecialBillingHasExpHov);
					rs.updateString(colNamesProps.getProperty("stage9_WWEREXPISBETWEENZEROANDCLIPLEVELHOV").trim(),wwerexpIsBetweenZeroAndClipLevelHov);
					rs.updateString(colNamesProps.getProperty("stage9_WWEREXPISABOVECLIPLEVELHOV").trim(),wwerExpIsAboveClipLevelHov);
//					rs.updateString(31,isEmpWithinCmpCountryHov);
					rs.updateString(colNamesProps.getProperty("stage9_ISEMPELIGIBLEFORSERVICEHOV").trim(),isEmpEligibleForServiceHov);
					rs.updateString(colNamesProps.getProperty("stage9_KFRCCSPECIALBILLINGHASEXPHOV").trim(),kfrCcSpecialBillingHasExpHov);
					rs.updateString(colNamesProps.getProperty("stage9_EXCEPTIONMOBCMPHOV").trim(),exceptionMobCmpHov);
					rs.updateString(colNamesProps.getProperty("stage9_EXCEPTIONMOBWWERHOV").trim(),exceptionMobHveWwerHov);
					
					//Stage 10
					rs.updateString(colNamesProps.getProperty("stage10_OVERALLCOMPLIANCE").trim(),overallCompliance);
					rs.updateString(colNamesProps.getProperty("stage10_EXPLANATION1MULTI").trim(),explanation1Multi);
					rs.updateString(colNamesProps.getProperty("stage10_EXPLANATION1BMULTI").trim(),explanation1Multi2);
					rs.updateString(colNamesProps.getProperty("stage10_EXPLANATION2SMARTPHONE").trim(),explanation2Smartphone);
					rs.updateString(colNamesProps.getProperty("stage10_EXPLANATION2BSMARTPHONE").trim(),explanation2BSmartphone);
					rs.updateString(colNamesProps.getProperty("stage10_EXPLANATION3CELL").trim(),explanation3Cell);
					rs.updateString(colNamesProps.getProperty("stage10_EXPLANATION3BCELL").trim(),explanation3BCell);
					rs.updateString(colNamesProps.getProperty("stage10_EXPLANATION4DATACARD").trim(),explanation4Datacard);
					rs.updateString(colNamesProps.getProperty("stage10_EXPLANATION4BDATACARD").trim(),explanation4BDatacard);
					rs.updateString(colNamesProps.getProperty("stage10_EXPLANATION5HOV").trim(),explanation5Hov);
					rs.updateString(colNamesProps.getProperty("stage10_EXPLANATION5BHOV").trim(),explanation5BHov);
					rs.updateString(colNamesProps.getProperty("stage10_EXPLANATION6HIN").trim(),explanation6Hin);
					rs.updateString(colNamesProps.getProperty("stage10_EXPLANATION6BHIN").trim(),explanation6BHin);
					rs.updateString(colNamesProps.getProperty("stage10_EXPLANATION7TAB").trim(),explanation7Tab);
					rs.updateString(colNamesProps.getProperty("stage10_EXPLANATION7BTAB").trim(),explanation7Tab);
					rs.updateString(colNamesProps.getProperty("stage10_EXPLANATION8TBD").trim(),explanation8TBD);
					rs.updateString(colNamesProps.getProperty("stage10_EXPLANATION8BTBD").trim(),explanation8BTBD);
					rs.updateString(colNamesProps.getProperty("stage10_COLLECTIONOFNONCOMPLIANTEXPLANATION").trim(),collectionOfNonCompliantExplanation);

					//Stage 11
					rs.updateString(colNamesProps.getProperty("stage11_SUMMARYOFNONCOMPLIANTEXPLANATION").trim(),summaryOfNonCompliantExplanation);
					
					//Stage 12
					rs.updateString(colNamesProps.getProperty("stage12_REALOVERALLCOMPLIANCE").trim(),realOverallCompliance);
	
			        rs.updateRow();
					if ((counter % 10000 == 0) || (counter == totalEmps)) {
						if (isTestRun)
							LOGGER.debug(new StringBuffer("[")
									.append(counter)
									.append("] Compliance data updated (but not committed yet) for CNUM = ")
									.append(cnum));
					}

//				} //end if.. else... counter
			}
					
			// Connection must be on a unit-of-work boundary to allow close
			if ( conn != null) {
				conn.commit();
				if (isTestRun)
					LOGGER.debug(new StringBuffer(" Total Transaction(s) committed = ").append(counter));
			}

		} catch (SQLException e) {
			LOGGER.error(new StringBuffer("Exception caught while getting base compliance records from table "+ e.getMessage()));
			e.printStackTrace();
			return -1;
			
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
				}//end catch
			}//end if
			
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing Statement. Resources might not be released ", e);
				}//end catch
			}//end if
		}//end finally
	
		if (isTestRun) {
			LOGGER.debug(new StringBuffer("Exiting PersonaComplianceDAO::updateComplianceDataUsingILog() ============>"));
		}

		return totalEmps;
	}

	/**
	 * Deletes COMPLIANCE records
	 * @return
	 */
	public int deleteComplianceRecords(){
		
		String query = null;
		PreparedStatement stmt = null;
		int result = -1;

		
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaComplianceDAO::deleteComplianceRecords() <============"));
		
		try {

			// invoke DELETE query to clean up the table
			query = SQLQuery.getQuery(SQLQuery.PERSONA_COMPLIANCE_DELETE);
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.prepareStatement(query);

			result = stmt.executeUpdate();

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Deleted ").append(result).append(" record(s)"));
			}

			// Close the Statement
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing PreparedStatement. Resources might not be released ", e);
				}//end catch
			}
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Exiting PersonaComplianceDAO::deleteComplianceRecords() ============>"));
			}

			return result;
			
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer("Exception caught attempting to delete records from table " + e.getMessage()));
		      e.printStackTrace();
		      return -1;
		}
	}

	
	/**
	 * Inserts COMPLIANCE records
	 * @return
	 */
	public int insertComplianceRecords(){
		
		String query = null;
		PreparedStatement stmt = null;
		int result = -1;

		
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaComplianceDAO::insertComplianceRecords() <============"));
		
		try {

			// invoke INSERT query to populate the table
			query = SQLQuery.getQuery(SQLQuery.PERSONA_COMPLIANCE_INSERT);
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.prepareStatement(query);

			result = stmt.executeUpdate();

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Inserted ").append(result).append(" record(s)"));
			}

			// Close the Statement
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing PreparedStatement. Resources might not be released ", e);
				}//end catch
			}
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Exiting PersonaComplianceDAO::insertComplianceRecords() ============>"));
			}

			return result;
			
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer("Exception caught attempting to insert records into table "+ e.getMessage()));
			e.printStackTrace();
			return -1;
		}
	}

}
