package com.ibm.cio;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.log4j.Logger;

public class PersonaSvcCatDAO{

	private Connection conn = null;
	private boolean isTestRun;

	private static Logger LOGGER = Logger.getLogger(PersonaSvcCatDAO.class);

	public PersonaSvcCatDAO(Connection connection, boolean testRun) {
		// initialization 
		conn = connection;
		isTestRun = testRun;

		if (isTestRun)
			LOGGER.debug(new StringBuffer("Created PersonaSvcCatDAO object successfully"));

	}


	
	/**
	 * Deletes records 
	 * @return
	 */
	public int deleteRecords(){
		
		String query = null;
		PreparedStatement stmt = null;
		int result = -1;

		
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaSvcCatDAO::deleteRecords() <============"));
		
		try {

			// invoke DELETE query to clean up the table
			query = SQLQuery.getQuery(SQLQuery.PERSONA_SVC_CAT_DELETE);
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.prepareStatement(query);

			result = stmt.executeUpdate();

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Deleted ").append(result).append(" record(s)"));
			}

			// Close the Statement
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing PreparedStatement. Resources might not be released ", e);
				}//end catch
			}
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Exiting PersonaSvcCatDAO::deleteRecords() ============>"));
			}

			return result;
			
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer("Exception caught attempting to delete records from table " + e.getMessage()));
		      e.printStackTrace();
		      return -1;
		}
	}

	
	/**
	 * Inserts records
	 * @return
	 */
	public int insertRecords(){
			
		String query = null;
		PreparedStatement stmt = null;
		int result = -1;

		
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaSvcCatDAO::insertRecords() <============"));
		
		try {

			// invoke INSERT query to populate the table
			query = SQLQuery.getQuery(SQLQuery.PERSONA_SVC_CAT_INSERT);
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.prepareStatement(query);

			result = stmt.executeUpdate();

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Inserted ").append(result).append(" record(s)"));
			}

			// Close the Statement
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing PreparedStatement. Resources might not be released ", e);
				}//end catch
			}
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Exiting PersonaSvcCatDAO::insertRecords() ============>"));
			}

			return result;
			
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer("Exception caught attempting to insert record into table " + e.getMessage()));
		      e.printStackTrace();
		      return -1;
		}
	}
	
	/**
	 * Delete existing merged original and pseudo records
	 * @return
	 */
	public int deleteMergeddRecords(){
		
		String query = null;
		PreparedStatement stmt = null;
		int result = -1;

		
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaSvcCatDAO::deleteMergeddRecords() <============"));
		
		try {

			// invoke DELETE query to clean up the table
			query = SQLQuery.getQuery(SQLQuery.PERSONA_SVC_CAT_DELETE2);
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.prepareStatement(query);

			result = stmt.executeUpdate();

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Deleted ").append(result).append(" record(s)"));
			}

			// Close the Statement
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing PreparedStatement. Resources might not be released ", e);
				}//end catch
			}
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Exiting PersonaSvcCatDAO::deleteMergeddRecords() ============>"));
			}

			return result;
			
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer("Exception caught attempting to delete records from table " + e.getMessage()));
		      e.printStackTrace();
		      return -1;
		}
	}

	
	/**
	 * Merges original and pseudo records
	 * @return
	 */
	public int mergeOriginalAndPseudoRecords(){
			
		String query = null;
		PreparedStatement stmt = null;
		int result = -1;

		
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaSvcCatDAO::mergeOriginalAndPseudoRecords() <============"));
		
		try {

			// invoke INSERT query to populate the table
			query = SQLQuery.getQuery(SQLQuery.PERSONA_SVC_CAT_INSERT2);
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.prepareStatement(query);

			result = stmt.executeUpdate();

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Merged ").append(result).append(" Pseudo record(s)"));
			}

			// Close the Statement
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing PreparedStatement. Resources might not be released ", e);
				}//end catch
			}
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Exiting PersonaSvcCatDAO::mergeOriginalAndPseudoRecords() ============>"));
			}

			return result;
			
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer("Exception caught attempting to insert record into table " + e.getMessage()));
		      e.printStackTrace();
		      return -1;
		}
	}
	
	/**
	 * Deletes records 
	 * @return
	 */
	public int deleteGroupedRecords(){
		
		String query = null;
		PreparedStatement stmt = null;
		int result = -1;

		
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaSvcCatDAO::deleteGroupedRecords() <============"));
		
		try {

			// invoke DELETE query to clean up the table
			query = SQLQuery.getQuery(SQLQuery.PERSONA_SVC_CAT_DELETE3);
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.prepareStatement(query);

			result = stmt.executeUpdate();

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Deleted ").append(result).append(" record(s)"));
			}

			// Close the Statement
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing PreparedStatement. Resources might not be released ", e);
				}//end catch
			}
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Exiting PersonaSvcCatDAO::deleteGroupedRecords() ============>"));
			}

			return result;
			
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer("Exception caught attempting to delete records from table " + e.getMessage()));
		      e.printStackTrace();
		      return -1;
		}
	}

	
	/**
	 * Inserts records
	 * @return
	 */
	public int insertGroupedRecords(){
			
		String query = null;
		PreparedStatement stmt = null;
		int result = -1;

		
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaSvcCatDAO::insertGroupedRecords() <============"));
		
		try {

			// invoke INSERT query to populate the table
			query = SQLQuery.getQuery(SQLQuery.PERSONA_SVC_CAT_INSERT3);
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.prepareStatement(query);

			result = stmt.executeUpdate();

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Inserted ").append(result).append(" record(s)"));
			}

			// Close the Statement
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing PreparedStatement. Resources might not be released ", e);
				}//end catch
			}
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Exiting PersonaSvcCatDAO::insertGroupedRecords() ============>"));
			}

			return result;
			
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer("Exception caught attempting to insert record into table " + e.getMessage()));
		      e.printStackTrace();
		      return -1;
		}
	}

	/**
	 * Delete existing records for CNUMs in P_SCASSET2 table from P_SCASSET2 table 
	 * @return
	 
	public int removeCNUMsFromTable(){
		
		String query = null;
		PreparedStatement stmt = null;
		int result = -1;

		
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaSvcCatDAO::removeCNUMsFromTable() <============"));
		
		try {

			// invoke DELETE query 
			query = SQLQuery.getQuery(SQLQuery.PERSONA_SVC_CAT_SCASSET_SCASSET2_DELETE);
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.prepareStatement(query);

			result = stmt.executeUpdate();

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Deleted ").append(result).append(" record(s)"));
			}

			// Close the Statement
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing PreparedStatement. Resources might not be released ", e);
				}//end catch
			}
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Exiting PersonaSvcCatDAO::removeCNUMsFromTable() ============>"));
			}

			return result;
			
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer("Exception caught attempting to delete existing Delete existing CNUMs in P_SCASSET2 table from P_SCASSET2 table " + e.getMessage()));
		      e.printStackTrace();
		      return -1;
		}
	}
*/
	/**
	 * Deletes records 
	 * @return
	 
	public int deleteMergedRecords(){
		
		String query = null;
		PreparedStatement stmt = null;
		int result = -1;

		
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaSvcCatDAO::deleteMergedRecords() <============"));
		
		try {

			// invoke DELETE query to clean up the table
			query = SQLQuery.getQuery(SQLQuery.PERSONA_SVC_CAT_FILTERED_DELETE);
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.prepareStatement(query);

			result = stmt.executeUpdate();

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Deleted ").append(result).append(" record(s)"));
			}

			// Close the Statement
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing PreparedStatement. Resources might not be released ", e);
				}//end catch
			}
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Exiting PersonaSvcCatDAO::deleteMergedRecords() ============>"));
			}

			return result;
			
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer("Exception caught attempting to delete records from table " + e.getMessage()));
		      e.printStackTrace();
		      return -1;
		}
	}
*/
	
	/**
	 * Merge and Insert records 
	 * @return
	public int mergeAndInsertRecords(){
			
		String query = null;
		PreparedStatement stmt = null;
		int result = -1;

		
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaSvcCatDAO::mergeAndInsertRecords() <============"));
		
		try {

			// invoke INSERT query to populate the table
			query = SQLQuery.getQuery(SQLQuery.PERSONA_SVC_CAT_FILTERED_INSERT);
			if (isTestRun)
				LOGGER.debug(new StringBuffer("executing query: ").append(query));

			stmt = conn.prepareStatement(query);

			result = stmt.executeUpdate();

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Inserted ").append(result).append(" record(s)"));
			}

			// Close the Statement
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.warn("Problem closing PreparedStatement. Resources might not be released ", e);
				}//end catch
			}
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Exiting PersonaSvcCatDAO::mergeAndInsertRecords() ============>"));
			}

			return result;
			
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer("Exception caught attempting to merge and insert record into table " + e.getMessage()));
		      e.printStackTrace();
		      return -1;
		}
	}
*/	
}
