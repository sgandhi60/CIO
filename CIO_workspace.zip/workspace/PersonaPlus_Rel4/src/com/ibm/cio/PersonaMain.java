package com.ibm.cio;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;
import java.util.Properties;
import java.util.Vector;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPReply;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.w3c.dom.Document;
//logging imports


public class PersonaMain {


	private final static Logger LOGGER = Logger.getLogger(PersonaMain.class);
	
	public static final String PERSONA_PROP_ROOT = "propertyFileRoot.properties";

	public static final String PERSONA_DBSERVER_PROD_PASSWORD = "persona4ibm";

	public static final String PERSONA_DBSERVER_DEV_PASSWORD = "persona4ibm";

	public static final String PERSONA_FTPSERVER_PROD_PASSWORD = "RosJ8mpk";

	public static final String PERSONA_FTPSERVER_DEV_PASSWORD = "RosJ8mpk";

	private Connection getDBConnection(Properties props) {
		
		String urlPrefix = null;
		String host = null;
		String port = null;
		String database = null;
		String url = null;
		String username = null;
		String password = null;
		String securityMechanism = null;
		
		Connection con = null;
		boolean isTestRun = false;
		
		isTestRun = (new Boolean(props.getProperty("isTestRun")).booleanValue());

		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaMain::getDBConnection() <============"));

		try {
			boolean isProd = false;
			isProd = (new Boolean(props.getProperty("isProd")).booleanValue());

			boolean isDevDB = false;
			isDevDB = (new Boolean(props.getProperty("isDevDB")).booleanValue());

			if (isProd) {
				host = props.getProperty("dbserver.prod.ipaddress");
				port = props.getProperty("dbserver.prod.port");
				username = props.getProperty("dbserver.prod.username");
				password = PERSONA_DBSERVER_PROD_PASSWORD;
				database = props.getProperty("dbserver.prod.database");				
				securityMechanism = props.getProperty("dbserver.prod.securityMechanism");				

				if (isTestRun) 
					LOGGER.debug(new StringBuffer("Connecting to PROD Database"));
			} else {
				host = props.getProperty("dbserver.dev.ipaddress");
				port = props.getProperty("dbserver.dev.port");
				username = props.getProperty("dbserver.dev.username");
				password = PERSONA_DBSERVER_DEV_PASSWORD;

				if (isDevDB) {
					database = props.getProperty("dbserver.dev.database");
					if (isTestRun) 
						LOGGER.debug(new StringBuffer("Connecting to DEV Database"));
				}
				else {
					database = props.getProperty("dbserver.test.database");
					if (isTestRun) 
						LOGGER.debug(new StringBuffer("Connecting to TEST Database"));
				}
					
				securityMechanism = props.getProperty("dbserver.dev.securityMechanism");				
			}
			
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("DBSERVER host = ").append(host));
				LOGGER.debug(new StringBuffer("DBSERVER port = ").append(port));
				LOGGER.debug(new StringBuffer("DBSERVER username = ").append(username));
				LOGGER.debug(new StringBuffer("DBSERVER password = ").append("*******"));
				LOGGER.debug(new StringBuffer("DBSERVER database = ").append(database));
				LOGGER.debug(new StringBuffer("DBSERVER securityMechanism = ").append(securityMechanism));
			}
			
			urlPrefix = props.getProperty("dbserver.urlprefix");
		    url = urlPrefix + "//" + host + ":" + port + "/" + database;
			if (isTestRun)
				LOGGER.debug(new StringBuffer("DB URL = ").append(url));
			
			// build Properties object to be used with DB connection
			Properties properties = new java.util.Properties(); 
           
			// Create Properties object
			properties.put("user", username);          
			properties.put("password", password);      
			properties.put("securityMechanism", securityMechanism); 
//			properties.put("securityMechanism", new String("" + com.ibm.db2.jcc.DB2BaseDataSource.CLEAR_TEXT_PASSWORD_SECURITY + "")); 
			
			// Create connection			
			// Load the driver
			String driver = props.getProperty("dbserver.db2jdbcdriver");
			if (isTestRun)
				LOGGER.debug(new StringBuffer("DB2 JDBC driver = ").append(driver));
			Class.forName(driver);
			
//			Class.forName("com.ibm.db2.jcc.DB2Driver");
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Loaded JDBC driver"));

			// Create the connection using the IBM Data Server Driver for JDBC and SQLJ
//			con = DriverManager.getConnection(url, username, password);
			con = DriverManager.getConnection(url, properties); 
			
			// Commit changes manually
			con.setAutoCommit(false);
			
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Created a JDBC connection to the data source"));
		}
	    
	    catch (ClassNotFoundException e)
	    {
	      LOGGER.error("Could not load JDBC driver");
	      LOGGER.error("Exception: " + e);
	      e.printStackTrace();
	    }

		catch (SQLException ex) {
			LOGGER.error("A connection to the DB was not established.  Check the DB Server properties.");
			LOGGER.error("DB URL = " + url);
			
			if (ex != null) {
				LOGGER.error("Error msg: " + ex.getMessage());
				LOGGER.error("SQLSTATE: " + ex.getSQLState());
				LOGGER.error("Error code: " + ex.getErrorCode());
				ex.printStackTrace();
			}
	    }
		
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Exiting PersonaMain::getDBConnection() ============>"));

		return con;
	}

	private int filterDirectConnectEPWSData(Connection con, boolean isTestRun, Vector countryCodes, Vector empTypes) {

		int RC = -1;
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaMain::filterDirectConnectEPWSData() <============"));

		try {
			
			PersonaEPWSDAO personaEPWSDAO = new PersonaEPWSDAO(con, isTestRun, countryCodes, empTypes);
			
			//Delete existing records
			RC = personaEPWSDAO.deleteDirectConnectRecords();
			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success deleting existing records"));

			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error deleting existing records"));		
				return RC;
			}
			
			// Connection must be on a unit-of-work boundary to allow close
			con.commit();
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Transaction committed"));
			
			RC = -1;
			//Insert records 
			RC = personaEPWSDAO.insertDirectConnectRecords();
			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success inserting records"));
			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error inserting records"));
				return RC;
			}
	
			// Connection must be on a unit-of-work boundary to allow close
			con.commit();
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Transaction committed"));

			RC = -1;
			//Delete existing records
			RC = personaEPWSDAO.deleteNonGCGBasedEPWSRecords();
			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success deleting existing records"));

			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error deleting existing records"));		
				return RC;
			}
			
			// Connection must be on a unit-of-work boundary to allow close
			con.commit();
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Transaction committed"));
			
			RC = -1;
			//Insert records 
			RC = personaEPWSDAO.insertNonGCGBasedEPWSRecords();
			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success inserting records"));
			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error inserting records"));
				return RC;
			}
	
			// Connection must be on a unit-of-work boundary to allow close
			con.commit();
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Transaction committed"));

			RC = -1;
			//Delete existing records
			RC = personaEPWSDAO.deleteGCGBasedEPWSRecords();
			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success deleting existing records"));

			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error deleting existing records"));		
				return RC;
			}
			
			// Connection must be on a unit-of-work boundary to allow close
			con.commit();
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Transaction committed"));
			
			RC = -1;
			//Insert records 
			RC = personaEPWSDAO.insertGCGBasedEPWSRecords();
			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success inserting records"));
			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error inserting records"));
				return RC;
			}
	
			// Connection must be on a unit-of-work boundary to allow close
			con.commit();
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Transaction committed"));

			RC = -1;
			//Delete existing records
			RC = personaEPWSDAO.deleteGCGEmplBasedEPWSRecords();
			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success deleting existing records"));

			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error deleting existing records"));		
				return RC;
			}
			
			// Connection must be on a unit-of-work boundary to allow close
			con.commit();
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Transaction committed"));
			
			RC = -1;
			//Insert records 
			RC = personaEPWSDAO.insertGCGEmplBasedEPWSRecords();
			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success inserting records"));
			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error inserting records"));
				return RC;
			}
	
			// Connection must be on a unit-of-work boundary to allow close
			con.commit();
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Transaction committed"));

			if (isTestRun)
				LOGGER.debug(new StringBuffer("Exiting PersonaMain::filterDirectConnectEPWSData() ============>"));

		}

		catch (SQLException ex) {
			LOGGER.error("Error while deleting/inserting EPWS records.");
			
			if (ex != null) {
				LOGGER.error("Error msg: " + ex.getMessage());
				LOGGER.error("SQLSTATE: " + ex.getSQLState());
				LOGGER.error("Error code: " + ex.getErrorCode());
				ex.printStackTrace();
			}
			return -1;
	    }
		
		return RC;
	}


	private int filterEPWSData(Connection con, boolean isTestRun, Vector countryCodes, Vector empTypes) {

		int RC = -1;
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaMain::filterEPWSData() <============"));

		try {
			
			PersonaEPWSDAO personaEPWSDAO = new PersonaEPWSDAO(con, isTestRun, countryCodes, empTypes);
			
			//Delete existing records
			RC = personaEPWSDAO.deleteRecords();
			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success deleting existing records"));

			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error deleting existing records"));						
				return RC;
			}
			
			// Connection must be on a unit-of-work boundary to allow close
			con.commit();
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Transaction committed"));
			
			RC = -1;
			//Insert records 
			RC = personaEPWSDAO.insertRecords();
			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success inserting records"));
			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error inserting records"));
				return RC;
			}
	
			// Connection must be on a unit-of-work boundary to allow close
			con.commit();
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Transaction committed"));
			
			RC = -1;
			//Delete existing records
			RC = personaEPWSDAO.deleteRecords2();
			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success deleting existing records"));

			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error deleting existing records"));						
				return RC;
			}
			
			// Connection must be on a unit-of-work boundary to allow close
			con.commit();
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Transaction committed"));
			
			RC = -1;
			//Insert records 
			RC = personaEPWSDAO.insertRecords2();
			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success inserting records"));
			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error inserting records"));
				return RC;
			}
	
			// Connection must be on a unit-of-work boundary to allow close
			con.commit();
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Transaction committed"));

			if (isTestRun)
				LOGGER.debug(new StringBuffer("Exiting PersonaMain::filterEPWSData() ============>"));

		}

		catch (SQLException ex) {
			LOGGER.error("Error while deleting/inserting EPWS records.");
			
			if (ex != null) {
				LOGGER.error("Error msg: " + ex.getMessage());
				LOGGER.error("SQLSTATE: " + ex.getSQLState());
				LOGGER.error("Error code: " + ex.getErrorCode());
				ex.printStackTrace();
			}
			return -1;
	    }
		
		return RC;
	}

	private int updateCurrencyXchangeRates(Connection con, boolean isTestRun) {
			
		int RC = -1;
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaMain::updateCurrencyXchangeRates() <============"));
	
		try {
			
			PersonaCurrencyDAO personaCurrencyDAO = new PersonaCurrencyDAO(con, isTestRun);
			
			//update currency data using Exchange Rates table
			RC = personaCurrencyDAO.updateCurrencyXchgRates(con);

			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success updating currency exchange rate records for ").append(RC).append(" countries"));
	
			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error updating currency exchange rate records"));						
				return RC;
			}
	
			// Connection must be on a unit-of-work boundary to allow close
			if ( con != null) {
				con.commit();
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Transaction committed"));
			}

			if (isTestRun)
				LOGGER.debug(new StringBuffer("Exiting PersonaMain::updateCurrencyXchangeRates() ============>"));
	
		}
	
		catch (SQLException ex) {
			LOGGER.error("Error while updating currency exchange rate records.");
			
			if (ex != null) {
				LOGGER.error("Error msg: " + ex.getMessage());
				LOGGER.error("SQLSTATE: " + ex.getSQLState());
				LOGGER.error("Error code: " + ex.getErrorCode());
				ex.printStackTrace();
			}
			return -1;
	   }
		
		return RC;
	}

	private int filterKFRData(Connection con, boolean isTestRun) {
			
		int RC = -1;
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaMain::filterKFRData() <============"));

		try {
			
			PersonaKFRDAO personaKFRDAO = new PersonaKFRDAO(con, isTestRun);
			
			
			// US Records 
			
			//Delete existing records
			RC = personaKFRDAO.deleteRecords();
			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success deleting existing records"));

			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error deleting existing records"));						
				return RC;
			}
			
			// Connection must be on a unit-of-work boundary to allow close
			con.commit();
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Transaction committed"));
			
			RC = -1;
			//Insert records 
			RC = personaKFRDAO.insertRecords();
			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success inserting records"));
			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error inserting records"));
				return RC;
			}
	
			// Connection must be on a unit-of-work boundary to allow close
			con.commit();
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Transaction committed"));
			
			RC = -1;
			//Delete existing records
			RC = personaKFRDAO.deleteItemizedRecords();
			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success deleting existing CC and CPC records"));

			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error deleting existing CC and CPC records"));						
				return RC;
			}
			
			// Connection must be on a unit-of-work boundary to allow close
			con.commit();
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Transaction committed"));
			
			RC = -1;
			//Insert records 
			RC = personaKFRDAO.insertItemizedCPCRecords();
			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success inserting CPC records"));
			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error inserting CPC records"));
				return RC;
			}
	
			// Connection must be on a unit-of-work boundary to allow close
			con.commit();
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Transaction committed"));
			
			RC = -1;
			//Insert records 
			RC = personaKFRDAO.insertItemizedCCRecords();
			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success inserting CC records"));
			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error inserting CC records"));
				return RC;
			}
	
			// Connection must be on a unit-of-work boundary to allow close
			con.commit();
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Transaction committed"));
			
			
			
			// CA records 
			
			//Delete existing CA records
			RC = personaKFRDAO.deleteCARecords();
			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success deleting existing CA records"));

			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error deleting existing CA records"));						
				return RC;
			}
			
			// Connection must be on a unit-of-work boundary to allow close
			con.commit();
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Transaction committed"));
			
			RC = -1;
			//Insert CA records 
			RC = personaKFRDAO.insertCARecords();
			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success inserting CA records"));
			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error inserting CA records"));
				return RC;
			}
	
			// Connection must be on a unit-of-work boundary to allow close
			con.commit();
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Transaction committed"));
			

			if (isTestRun)
				LOGGER.debug(new StringBuffer("Exiting PersonaMain::filterKFRData() ============>"));

		}

		catch (SQLException ex) {
			LOGGER.error("Error while deleting/inserting KFR records.");
			
			if (ex != null) {
				LOGGER.error("Error msg: " + ex.getMessage());
				LOGGER.error("SQLSTATE: " + ex.getSQLState());
				LOGGER.error("Error code: " + ex.getErrorCode());
				ex.printStackTrace();
			}
			return -1;
	    }
		
		return RC;
	}


	private int filterWWERData(Connection con, boolean isTestRun, Vector countryCodes) {

		int RC = -1;
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaMain::filterWWERData() <============"));

		try {
			
			PersonaWWERDAO personaWWERDAO = new PersonaWWERDAO(con, isTestRun, countryCodes);
			
			//Delete existing records
			RC = personaWWERDAO.deleteRecords();
			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success deleting existing records"));

			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error deleting existing records"));						
				return RC;
			}
			
			// Connection must be on a unit-of-work boundary to allow close
			con.commit();
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Transaction committed"));
			
			RC = -1;
			//Insert records 
			RC = personaWWERDAO.insertRecords();
			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success inserting records"));
			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error inserting records"));
				return RC;
			}
	
			// Connection must be on a unit-of-work boundary to allow close
			con.commit();
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Transaction committed"));
			
			RC = -1;
			//Delete existing records
			RC = personaWWERDAO.deleteGroupedRecords();
			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success deleting existing records"));

			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error deleting existing records"));						
				return RC;
			}
			
			// Connection must be on a unit-of-work boundary to allow close
			con.commit();
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Transaction committed"));
			
			RC = -1;
			//Insert records 
			RC = personaWWERDAO.insertGroupedRecords();
			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success inserting records"));
			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error inserting records"));
				return RC;
			}
	
			// Connection must be on a unit-of-work boundary to allow close
			con.commit();
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Transaction committed"));

			
			RC = -1;
			//Delete existing records
			RC = personaWWERDAO.deleteGroupedRecords3();
			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success deleting existing records"));

			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error deleting existing records"));						
				return RC;
			}
			
			// Connection must be on a unit-of-work boundary to allow close
			con.commit();
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Transaction committed"));
			
			RC = -1;
			//Insert records 
			RC = personaWWERDAO.insertGroupedRecords3();
			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success inserting records"));
			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error inserting records"));
				return RC;
			}
	
			// Connection must be on a unit-of-work boundary to allow close
			con.commit();
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Transaction committed"));

			if (isTestRun)
				LOGGER.debug(new StringBuffer("Exiting PersonaMain::filterWWERData() ============>"));

		}

		catch (SQLException ex) {
			LOGGER.error("Error while deleting/inserting WWER records.");
			
			if (ex != null) {
				LOGGER.error("Error msg: " + ex.getMessage());
				LOGGER.error("SQLSTATE: " + ex.getSQLState());
				LOGGER.error("Error code: " + ex.getErrorCode());
				ex.printStackTrace();
			}
			return -1;
	    }
		
		return RC;
	}


	private int filterSvcCatData(Connection con, boolean isTestRun) {
			
		int RC = -1;
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaMain::filterSvcCatData() <============"));

		try {
			
			PersonaSvcCatDAO personaSvcCatDAO = new PersonaSvcCatDAO(con, isTestRun);
			
			//Delete existing records
			RC = personaSvcCatDAO.deleteRecords();
			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success deleting existing records"));

			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error deleting existing records"));						
				return RC;
			}
			
			// Connection must be on a unit-of-work boundary to allow close
			con.commit();
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Transaction committed"));
			
			RC = -1;
			//Insert records 
			RC = personaSvcCatDAO.insertRecords();
			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success inserting records"));
			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error inserting records"));
				return RC;
			}
	
			// Connection must be on a unit-of-work boundary to allow close
			con.commit();
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Transaction committed"));

			RC = -1;
			//Delete existing merged original and pseudo records
			RC = personaSvcCatDAO.deleteMergeddRecords();
			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success deleting existing records"));

			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error deleting existing records"));						
				return RC;
			}
			
			// Connection must be on a unit-of-work boundary to allow close
			con.commit();
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Transaction committed"));
			
			RC = -1;
			//Merge original and pseudo records 
			RC = personaSvcCatDAO.mergeOriginalAndPseudoRecords();
			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success inserting Pseudo records"));
			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error inserting Pseudo records"));
				return RC;
			}
			
			// Connection must be on a unit-of-work boundary to allow close
			con.commit();
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Transaction committed"));

			RC = -1;
			//Delete existing records
			RC = personaSvcCatDAO.deleteGroupedRecords();
			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success deleting existing records"));

			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error deleting existing records"));						
				return RC;
			}
			
			// Connection must be on a unit-of-work boundary to allow close
			con.commit();
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Transaction committed"));
			
			RC = -1;
			//Insert records 
			RC = personaSvcCatDAO.insertGroupedRecords();
			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success inserting records"));
			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error inserting records"));
				return RC;
			}
	
			// Connection must be on a unit-of-work boundary to allow close
			con.commit();
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Transaction committed"));
			
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Exiting PersonaMain::filterSvcCatData() ============>"));

		}

		catch (SQLException ex) {
			LOGGER.error("Error while deleting/inserting SvcCat records.");
			
			if (ex != null) {
				LOGGER.error("Error msg: " + ex.getMessage());
				LOGGER.error("SQLSTATE: " + ex.getSQLState());
				LOGGER.error("Error code: " + ex.getErrorCode());
				ex.printStackTrace();
			}
			return -1;
	    }
		
		return RC;
	}


	private int filterGVIData(Connection con, boolean isTestRun) {
			
		int RC = -1;
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaMain::filterGVIData() <============"));

		try {
			
			PersonaGVIDAO personaGVIDAO = new PersonaGVIDAO(con, isTestRun);
			
			//Delete existing records
			RC = personaGVIDAO.deleteRecordsFromTempTable();
			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success deleting existing records"));

			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error deleting existing records"));						
				return RC;
			}
			
			// Connection must be on a unit-of-work boundary to allow close
			con.commit();
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Transaction committed"));
			
			RC = -1;
			//Insert records 
			RC = personaGVIDAO.insertRecordsIntoTempTable();
			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success inserting records"));
			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error inserting records"));
				return RC;
			}
			
			// Connection must be on a unit-of-work boundary to allow close
			con.commit();
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Transaction committed"));
			
			RC = -1;
			//Delete existing records
			RC = personaGVIDAO.deleteRecordsFromTemp1Table();
			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success deleting existing records"));

			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error deleting existing records"));						
				return RC;
			}
			
			// Connection must be on a unit-of-work boundary to allow close
			con.commit();
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Transaction committed"));
			
			RC = -1;
			//Insert records 
			RC = personaGVIDAO.insertRecordsIntoTemp1Table();
			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success inserting records"));
			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error inserting records"));
				return RC;
			}
			
			// Connection must be on a unit-of-work boundary to allow close
			con.commit();
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Transaction committed"));
			
			RC = -1;
			//Delete existing records for serials in P_US_GVI_TEMP1 table from P_US_GVI_TEMP table 
			RC = personaGVIDAO.removeTemp1SerialsFromTempTable();
			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success deleting existing serials in P_US_GVI_TEMP! table from P_US_GVI_TEMP table "));

			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error deleting existing serials in P_US_GVI_TEMP! table from P_US_GVI_TEMP table "));						
				return RC;
			}
			
			// Connection must be on a unit-of-work boundary to allow close
			con.commit();
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Transaction committed"));
			
			
			
			RC = -1;
			//Delete existing records
			RC = personaGVIDAO.deleteRecords();
			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success deleting existing records"));

			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error deleting existing records"));						
				return RC;
			}
			
			// Connection must be on a unit-of-work boundary to allow close
			con.commit();
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Transaction committed"));
			
			RC = -1;
			//Merge and Insert records 
			RC = personaGVIDAO.mergeAndInsertRecords();
			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success merging and inserting records"));
			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error merging and inserting records"));
				return RC;
			}
	
			// Connection must be on a unit-of-work boundary to allow close
			con.commit();
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Transaction committed"));

			if (isTestRun)
				LOGGER.debug(new StringBuffer("Exiting PersonaMain::filterGVIData() ============>"));

		}

		catch (SQLException ex) {
			LOGGER.error("Error while deleting/inserting GVI records.");
			
			if (ex != null) {
				LOGGER.error("Error msg: " + ex.getMessage());
				LOGGER.error("SQLSTATE: " + ex.getSQLState());
				LOGGER.error("Error code: " + ex.getErrorCode());
				ex.printStackTrace();
			}
			return -1;
	    }
		
		return RC;
	}

	private int buildComplianceData(Connection con, boolean isTestRun) {
		
		int RC = -1;
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaMain::buildComplianceData() <============"));

		try {
			
			PersonaComplianceDAO personaComplianceDAO = new PersonaComplianceDAO(con, isTestRun);
			
			//Delete existing records
			RC = personaComplianceDAO.deleteRecordsFromTest();
			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success deleting existing records"));

			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error deleting existing records"));						
				return RC;
			}
			
			// Connection must be on a unit-of-work boundary to allow close
			con.commit();
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Transaction committed"));
			
			RC = -1;
			//Insert KFR records 
			RC = personaComplianceDAO.insertKFRRecords();
			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success inserting KFR records"));
			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error inserting KFR records"));
				return RC;
			}
	
			// Connection must be on a unit-of-work boundary to allow close
			con.commit();
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Transaction committed"));
			
			RC = -1;
			//Insert WWER records 
			RC = personaComplianceDAO.insertWWERRecords();
			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success inserting WWER records"));
			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error inserting WWER records"));
				return RC;
			}
	
			// Connection must be on a unit-of-work boundary to allow close
			con.commit();
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Transaction committed"));
			
			RC = -1;
			//Insert GVI records 
			RC = personaComplianceDAO.insertGVIRecords();
			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success inserting GVI records"));
			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error inserting GVI records"));
				return RC;
			}
	
			// Connection must be on a unit-of-work boundary to allow close
			con.commit();
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Transaction committed"));		
			
			
			RC = -1;
			//Delete existing GROUPED records
			RC = personaComplianceDAO.deleteGroupedRecords();
			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success deleting existing grouped records"));

			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error deleting existing grouped records"));						
				return RC;
			}
			
			// Connection must be on a unit-of-work boundary to allow close
			con.commit();
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Transaction committed"));
			
			RC = -1;
			//Insert GROUPED records 
			RC = personaComplianceDAO.insertGroupedRecords();
			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success inserting grouped records"));
			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error inserting grouped records"));
				return RC;
			}
	
			// Connection must be on a unit-of-work boundary to allow close
			con.commit();
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Transaction committed"));

			RC = -1;
			
			//Delete existing records from Compliance_pre table
			RC = personaComplianceDAO.deleteCompliancePreRecords();
			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success deleting existing Compliance_Pre records"));

			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error deleting existing Compliance_Pre records"));						
				return RC;
			}
			
			// Connection must be on a unit-of-work boundary to allow close
			con.commit();
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Transaction committed"));
			
			// END - SBG
			
			RC = -1;
			//Insert Compliance_Pre records 
			RC = personaComplianceDAO.insertCompliancePreRecords();
			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success inserting Compliance_Pre records"));
			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error inserting Compliance_Pre records"));
				return RC;
			}
	
			// Connection must be on a unit-of-work boundary to allow close
			con.commit();
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Transaction committed"));
			
			RC = -1;
			//Insert Compliance_Pre records 
			RC = personaComplianceDAO.insertGCGBasedCompliancePreRecords();
			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success inserting Compliance_Pre records"));
			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error inserting Compliance_Pre records"));
				return RC;
			}
	
			// Connection must be on a unit-of-work boundary to allow close
			con.commit();
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Transaction committed"));
			
			RC = -1;
			//Insert Compliance_Pre records 
			RC = personaComplianceDAO.insertGCGEmplBasedCompliancePreRecords();
			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success inserting Compliance_Pre records"));
			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error inserting Compliance_Pre records"));
				return RC;
			}
	
			// Connection must be on a unit-of-work boundary to allow close
			con.commit();
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Transaction committed"));

			RC = -1;
			//Update Compliance_Pre records for NULL to 0.00
			RC = personaComplianceDAO.updateCompliancePreRecords();
			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success updating Compliance_Pre records"));
			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error updating Compliance_Pre records"));
				return RC;
			}
	
			// Connection must be on a unit-of-work boundary to allow close
			con.commit();
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Transaction committed"));

			if (isTestRun)
				LOGGER.debug(new StringBuffer("Exiting PersonaMain::buildComplianceData() ============>"));

		}

		catch (SQLException ex) {
			LOGGER.error("Error while deleting/inserting Compliance records.");
			
			if (ex != null) {
				LOGGER.error("Error msg: " + ex.getMessage());
				LOGGER.error("SQLSTATE: " + ex.getSQLState());
				LOGGER.error("Error code: " + ex.getErrorCode());
				ex.printStackTrace();
			}
			return -1;
	    }
		
		return RC;
	}

	
	private int updateComplianceData(Connection con, boolean isTestRun, Properties colNamesProps) {
		
		int RC = -1;
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaMain::updateComplianceData() <============"));
	
		try {
			
			PersonaComplianceDAO personaComplianceDAO = new PersonaComplianceDAO(con, isTestRun);
			
			//update compliance data using iLog engine
			RC = personaComplianceDAO.updateComplianceDataUsingILog(colNamesProps);
//			RC = personaComplianceDAO.updateComplianceDataUsingILog(con, colNamesProps);
	/*			emplsComplianceIn = personaComplianceDAO.getComplianceDataFromILog2();
				if (emplsComplianceIn != null) {
					RC = emplsComplianceIn.length;
				}
	*/			
			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success updating compliance data records for ").append(RC).append(" employee(s)"));
	
			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error updating compliance data records"));						
				return RC;
			}
	
			// Connection must be on a unit-of-work boundary to allow close
			if ( con != null) {
				con.commit();
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Transaction committed"));
			}

			if (isTestRun)
				LOGGER.debug(new StringBuffer("Exiting PersonaMain::updateComplianceData() ============>"));
	
		}
	
		catch (SQLException ex) {
			LOGGER.error("Error while updating compliance data records.");
			
			if (ex != null) {
				LOGGER.error("Error msg: " + ex.getMessage());
				LOGGER.error("SQLSTATE: " + ex.getSQLState());
				LOGGER.error("Error code: " + ex.getErrorCode());
				ex.printStackTrace();
			}
			return -1;
	   }
		
		return RC;
	}

	private int copyToComplianceTable(Connection con, boolean isTestRun) {
		
		int RC = -1;
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaMain::copyToComplianceTable() <============"));

		try {
			
			PersonaComplianceDAO personaComplianceDAO = new PersonaComplianceDAO(con, isTestRun);
			
			// COMMENT OUT THIS SECTION BEFORE MIGRATING TO SERVER 
			// AS WE DON'T NEED TO DELETE COMPLIANCE RECORDS
			
			// BEGIN -SBG
			/*
			
			//Delete existing Compliance records
			RC = personaComplianceDAO.deleteComplianceRecords();
			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success deleting existing Compliance records"));

			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error deleting existing Compliance records"));						
				return RC;
			}
			
			// Connection must be on a unit-of-work boundary to allow close
			con.commit();
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Transaction committed"));
			
		   */
			// END - SBG
			
			RC = -1;
			//Insert Compliance records 
			RC = personaComplianceDAO.insertComplianceRecords();
			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success inserting Compliance records"));
			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error inserting Compliance records"));
				return RC;
			}
	
			// Connection must be on a unit-of-work boundary to allow close
			con.commit();
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Transaction committed"));

			if (isTestRun)
				LOGGER.debug(new StringBuffer("Exiting PersonaMain::copyToComplianceTable() ============>"));

		}

		catch (SQLException ex) {
			LOGGER.error("Error while deleting/inserting Compliance records.");
			
			if (ex != null) {
				LOGGER.error("Error msg: " + ex.getMessage());
				LOGGER.error("SQLSTATE: " + ex.getSQLState());
				LOGGER.error("Error code: " + ex.getErrorCode());
				ex.printStackTrace();
			}
			return -1;
	    }
		
		return RC;
	}


	private FTPClient getFTPClient(Properties props) {
		
		String host = null;
//		String portStr = null;
		String username = null;
		String password = null;
		
		FTPClient ftpCl = null;
		boolean isTestRun = false;
		
		isTestRun = (new Boolean(props.getProperty("isTestRun")).booleanValue());

		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaMain::getFTPClient() <============"));

		try {
			boolean isProd = false;
			isProd = (new Boolean(props.getProperty("isProd")).booleanValue());

			if (isProd) {
				host = props.getProperty("ftpserver.prod.ipaddress");
//				portStr = props.getProperty("ftpserver.prod.port");
				username = props.getProperty("ftpserver.prod.username");
				password = PERSONA_FTPSERVER_PROD_PASSWORD;

				if (isTestRun) 
					LOGGER.debug(new StringBuffer("Connecting to PROD FTP Client"));
				
			} else {
				host = props.getProperty("ftpserver.dev.ipaddress");
//				portStr = props.getProperty("ftpserver.dev.port");
				username = props.getProperty("ftpserver.dev.username");
				password = PERSONA_FTPSERVER_DEV_PASSWORD;

				if (isTestRun) 
					LOGGER.debug(new StringBuffer("Connecting to DEV/TEST FTP Client"));
			}
			
//			int port = new Integer(portStr).intValue();
			
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("FTPSERVER host = ").append(host));
//				LOGGER.debug(new StringBuffer("FTPSERVER port = ").append(port));
				LOGGER.debug(new StringBuffer("FTPSERVER username = ").append(username));
				LOGGER.debug(new StringBuffer("FTPSERVER password = ").append("*******"));
			}
			
			ftpCl = new FTPClient();
			
//			ftpCl.connect(host, port);
			ftpCl.connect(host);
			String replyStr = ftpCl.getReplyString();
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Reply from Connect call = " ).append(replyStr));
			}

			boolean isLoginPass = ftpCl.login(username, password);
/*			replyStr = ftpCl.getReplyString();
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Reply from Login call = " ).append(replyStr));
			}
*/			
			if (!isLoginPass) {
				ftpCl.logout();

				if (isTestRun) {
					LOGGER.debug(new StringBuffer("Login to FTP Server was NOT successful"));
					LOGGER.debug(new StringBuffer("Exiting PersonaMain::getFTPClient() ============>"));
				}
				return null;				
			}
	
			int reply = ftpCl.getReplyCode();
			if (!FTPReply.isPositiveCompletion(reply))
			{
				ftpCl.disconnect();
				
				if (isTestRun) {
					LOGGER.debug(new StringBuffer("Connection to FTP Server was NOT successful"));
					LOGGER.debug(new StringBuffer("Exiting PersonaMain::getFTPClient() ============>"));
				}
				return null;
			}
			if (isTestRun)
				LOGGER.debug(new StringBuffer("Successfully created a FTP connection to FTP Server on ").append(host));
			
		}

		catch (Exception ex) {
			LOGGER.error("A connection to the FTP Server was not established.  Check the FTP Server properties.");
			
			if (ex != null) {
				LOGGER.error("Error msg: " + ex.getMessage());
				ex.printStackTrace();
			}
	    }
		
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Exiting PersonaMain::getFTPClient() ============>"));

		return ftpCl;
	}

	private int buildXMLFileData(Connection con, boolean isTestRun, Properties xmlElemsProps, Properties mgrHubProps) {
			
		Document doc = null;
		
		int RC = -1;
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaMain::buildXMLFileData() <============"));
	
		try {
			
			MgrHubDAO mgrHubDAO = new MgrHubDAO(con, isTestRun);
			
			//build XML file using manager hub data
			doc = mgrHubDAO.buildXMLDoc(con, xmlElemsProps, mgrHubProps);
			
			if ( doc == null ) {
				RC = -1;
			} else {
				RC = 1;
			}
				
			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success building XML Doc from manager hub data"));
	
			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error building XML Doc from manager hub data"));						
				return RC;
			}
	
			// Connection must be on a unit-of-work boundary to allow close
			if ( con != null) {
				con.commit();
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Transaction committed"));
			}
	
			RC = -1;
			//build XML file using manager hub data
			RC = mgrHubDAO.buildXMLFile(doc, mgrHubProps);
			
			if (RC>=0){
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Success building XML file from manager hub data"));
	
			}else{
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Error building XML file from manager hub data"));						
				return RC;
			}
	
			// Connection must be on a unit-of-work boundary to allow close
			if ( con != null) {
				con.commit();
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Transaction committed"));
			}

			if (isTestRun)
				LOGGER.debug(new StringBuffer("Exiting PersonaMain::buildXMLFileData() ============>"));
	
		}
	
		catch (SQLException ex) {
			LOGGER.error("Error while updating compliance data records.");
			
			if (ex != null) {
				LOGGER.error("Error msg: " + ex.getMessage());
				LOGGER.error("SQLSTATE: " + ex.getSQLState());
				LOGGER.error("Error code: " + ex.getErrorCode());
				ex.printStackTrace();
			}
			return -1;
	   }
		
		return RC;
	}

	
	private int uploadXMLFileToServer(FTPClient ftpClient, boolean isTestRun, Properties mgrHubProps) {
			
		int RC = -1;
		String username = null;
		
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaMain::uploadXMLFileToServer() <============"));
		try {

			ftpClient.enterLocalPassiveMode();

			ftpClient.setFileType(FTP.ASCII_FILE_TYPE);
			
			// set record type format to variable blocked
			ftpClient.sendSiteCommand("recfm=VB");
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Record Type format (recfm)is set to VB (Variable Blocked)"));
			}
			
			// set record length to 133 bytes
			ftpClient.sendSiteCommand("lrecl=133");
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Record Length (lrecl) is set to 133 bytes"));
			}
			
			// set character encoding translations
			ftpClient.sendSiteCommand("sbd=(37,1208)");
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("character encoding is set to sbd=(37,1208)"));
			}
			
			// retrieve local XML file directory from properties
			String mgrHubXMLDirLocal = mgrHubProps.getProperty("mgrHubXMLDirLocal");
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Manager Hub XML dir(Local) = ").append(mgrHubXMLDirLocal));
			}
				 
			// retrieve local XML file name from properties
			String mgrHubXMLFileLocal = mgrHubXMLDirLocal + mgrHubProps.getProperty("mgrHubXMLFileLocal");
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Manager Hub XML File Name(Local) = ").append(mgrHubXMLFileLocal));
			}

			// retrieve remote XML file directory (DataSet) from properties
			String mgrHubXMLDirRemote = mgrHubProps.getProperty("mgrHubXMLDirRemote");
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Manager Hub XML dir(Remote) = ").append(mgrHubXMLDirRemote));
			}
				 
			// retrieve remote XML file name from properties
			String mgrHubXMLFileRemote = mgrHubProps.getProperty("mgrHubXMLFileRemote");
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Manager Hub XML File Name(Remote) = ").append(mgrHubXMLFileRemote));
			}

			// uploads XML file using an InputStream
//			File mHubXMLFileRemote = new File(mgrHubXMLFileRemote);
			
			boolean isProd = false;
			isProd = (new Boolean(mgrHubProps.getProperty("isProd")).booleanValue());

			if (isProd) {
				username = mgrHubProps.getProperty("ftpserver.prod.username");
			} else {
				username = mgrHubProps.getProperty("ftpserver.dev.username");
			}

			// retrieve dataset info from properties file
			String dataSet = username + "." + mgrHubXMLDirRemote;
			String xmlFileOnFtpServer = "'" + dataSet + "'";
			if (isTestRun) {
				LOGGER.debug(new StringBuffer("DataSet = ").append(dataSet));
				LOGGER.debug(new StringBuffer("xmlFileOnFtpServer = ").append(xmlFileOnFtpServer));
			}
/*
			boolean success = ftpClient.changeWorkingDirectory("'" + dataSet + "'");
			if (success) {
				if (isTestRun) {
					LOGGER.debug(new StringBuffer("Successfully changed working directory"));
				}
			}
			else {
				if (isTestRun) {
					LOGGER.debug(new StringBuffer("Failed to change working directory. See server's reply"));
				}
				return RC;
			}
*/			

			// uploads XML file using an InputStream
			File mHubXMLFileLocal = new File(mgrHubXMLFileLocal);
			InputStream inputStream = new FileInputStream(mHubXMLFileLocal);


//			String firstRemoteFile = "Projects.zip";

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Start uploading XML file = ").append(mgrHubXMLFileLocal));
			}
			
//			boolean done = ftpClient.storeFile(mgrHubXMLFileRemote, inputStream);
			boolean done = ftpClient.storeFile(xmlFileOnFtpServer, inputStream);
			inputStream.close();
			if (done) {
				if (isTestRun) 
					LOGGER.debug(new StringBuffer("Successfully uploaded XML file = ").append(mgrHubXMLFileLocal));
/*				
				// change xml file permission
				ftpClient.sendSiteCommand("chmod " + "777 " + xmlFileOnFtpServer);
				if (isTestRun) {
					LOGGER.debug(new StringBuffer("Uploaded xml file permission is set to 777 on FTP server"));
				}
*/			

				RC = 0;
			} else {
				if (isTestRun) 
					LOGGER.debug(new StringBuffer("XML file NOT uploaded = ").append(mgrHubXMLFileLocal));

				RC = -1;
			}
/*
			boolean completed = ftpClient.completePendingCommand();
			if (completed) {
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Successfully uploaded XML file = ").append(mgrHubXMLFileLocal));
			}
*/
		} catch (IOException ex) {
			LOGGER.error("Error while uploading XML file to FTP server");
			
			if (ex != null) {
				LOGGER.error("Error msg: " + ex.getMessage());
				ex.printStackTrace();
			}
			
			return -1;

		} finally {
			try {
				if (ftpClient.isConnected()) {
					ftpClient.logout();
					ftpClient.disconnect();
				}
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}	

		if (isTestRun)
			LOGGER.debug(new StringBuffer("Exiting PersonaMain::uploadXMLFileToServer() ============>"));
		
		return RC;
	}

	private int buildSummaryComplianceData(Connection con, boolean isTestRun, Vector<String> srviceTypes, Properties props, Properties colNamesProps) {
		
		int RC = -1;
		if (isTestRun)
			LOGGER.debug(new StringBuffer("Entering PersonaMain::buildSummaryComplianceData() <============"));

		try {
			
			PersonaSummaryComplianceDAO personaSummaryComplianceDAO = new PersonaSummaryComplianceDAO(con, isTestRun);
			
			int totalSvcTypes = srviceTypes.size();
			if (isTestRun)
				LOGGER.debug("totalSvcTypes = " + totalSvcTypes);
			
			int totalRecords = 0;
			
			for (int i=0; i < totalSvcTypes; i++) {
				
				String svcType = srviceTypes.get(i);
				if (isTestRun) {
					LOGGER.debug(new StringBuffer("Begin Processing ServiceType["+ (i+1) + "] = " + svcType));
				}
				
				// delete the records from PRESUMMARY_COMPLIANCE table
				RC = -1; // Initialize for each service type
				RC = personaSummaryComplianceDAO.deletePreSumaryCompliaceRecords();
				if (RC>=0){
					if (isTestRun)
						LOGGER.debug(new StringBuffer("Success deleting existing records"));

				}else{
					if (isTestRun)
						LOGGER.debug(new StringBuffer("Error deleting existing records"));						
					return RC;
				}
				
				// Connection must be on a unit-of-work boundary to allow close
				con.commit();
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Transaction committed"));
				
				RC = -1;
				//Insert PreSumaryCompliace records
				RC = personaSummaryComplianceDAO.insertPreSumaryCompliaceRecords();
				if (RC>=0){
					if (isTestRun)
						LOGGER.debug(new StringBuffer("Success inserting records"));
				}else{
					if (isTestRun)
						LOGGER.debug(new StringBuffer("Error inserting records"));
					return RC;
				}
		
				// Connection must be on a unit-of-work boundary to allow close
				con.commit();
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Transaction committed"));

				RC = -1; // Initialize for each service type
				RC = personaSummaryComplianceDAO.buildSvcTypeBasedSummaryComplianceData(svcType, props, colNamesProps);
				if (RC>=0){
					if (isTestRun)
						LOGGER.debug(new StringBuffer("Success building ServoiceType based Summary Compliance records"));

				}else{
					if (isTestRun)
						LOGGER.debug(new StringBuffer("Error building ServoiceType based Summary Compliance records"));						
					return RC;
				}
				
				// Connection must be on a unit-of-work boundary to allow close
				con.commit();
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Transaction committed"));
				
				RC = -1;
				//Insert PreSumaryCompliace records into SUMMARY_COMPLIANCE table
				RC = personaSummaryComplianceDAO.insertSumaryCompliaceRecords();
				if (RC>=0){
					
					// add recently inserted record count in total count
					totalRecords = totalRecords + RC;
					
					if (isTestRun) {
						LOGGER.debug(new StringBuffer("Success inserting records"));
						LOGGER.debug(new StringBuffer("Total records inserted in Summary table after ServiceType["+ (i+1) + "] - (so far) = " + totalRecords));
					}
				}else{
					if (isTestRun)
						LOGGER.debug(new StringBuffer("Error inserting records"));
					return RC;
				}
		
				// Connection must be on a unit-of-work boundary to allow close
				con.commit();
				if (isTestRun)
					LOGGER.debug(new StringBuffer("Transaction committed"));
	
				if (isTestRun) {
					LOGGER.debug(new StringBuffer("End Processing ServiceType["+ (i+1) + "] = " + svcType));
				}

			} // end for

			if (isTestRun) {
				LOGGER.debug(new StringBuffer("Total records inserted in Summary table (FINAL) = " + totalRecords));
				LOGGER.debug(new StringBuffer("Exiting PersonaMain::buildSummaryComplianceData() ============>"));
			}
		}

		catch (SQLException ex) {
			LOGGER.error("Error while deleting/inserting Compliance records.");
			
			if (ex != null) {
				LOGGER.error("Error msg: " + ex.getMessage());
				LOGGER.error("SQLSTATE: " + ex.getSQLState());
				LOGGER.error("Error code: " + ex.getErrorCode());
				ex.printStackTrace();
			}
			return -1;
	    }
		
		return RC;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		// Property files related info
		String propertyFileRoot = null;
		String propRootFileName = null;
		String propFileName = null;
		String log4jPropFileName = null;
		String colNamesFileName = null;
		String xmlElementsFileName = null;

		Properties infoProps = null;
		Properties props = null;
		Properties colNamesProps = null;
		Properties xmlElementsProps = null;
		
		FTPClient ftpClient = null;
		
		Vector<String> countryCodes = new Vector<String>(10, 10);
		Vector<String> empTypes = new Vector<String>(5, 5);
		Vector<String> svcTypes = new Vector<String>(5, 5);

		ClassLoader loader = Thread.currentThread().getContextClassLoader();
		
		boolean isTestRun = false;
		boolean accessEPWSFromDirectConnect = false;
		boolean isMgrHubOnlyRun = false;
		boolean isMgrHubRunRequired = false;
		boolean copyToComplianceTable = false;
		boolean createSummaryCompliance = false;
		
		Connection conn = null;
//		Connection directConn = null;

		System.out.println(" ");
	 	    
        //  Get the property files root location
		try {
			propRootFileName = PERSONA_PROP_ROOT;
		    InputStream is = loader.getResourceAsStream(propRootFileName);
			infoProps = new Properties();
			infoProps.load(is);

			System.out.println("Success loading Root properties file: " + propRootFileName);
			is.close();

			System.out.println(" ");

			Enumeration<?> e = infoProps.propertyNames();
			System.out.println("Persona Root Properties: ");		

			while (e.hasMoreElements()) {
				String key = (String) e.nextElement();
				String keyValue = (String) infoProps.getProperty(key).trim();
				System.out.println(key + "=" + keyValue);
			}
			
			propertyFileRoot = infoProps.getProperty("propertyFileRoot");
			System.out.println("Properties file Root Path: " + propertyFileRoot);

		} catch (IOException ioe) {
			System.err.println("Failed to load Root properties file: " + propRootFileName);
			ioe.printStackTrace();
			System.exit(1);
		}
			
		System.out.println(" ");
		
		// load log4jConfigFile properties
		// if the log4jConfigFile is not set, then no point in trying
		log4jPropFileName = propertyFileRoot + infoProps.getProperty("log4jConfigFile");
		System.out.println("Log4j Properties file name: " + log4jPropFileName);
		System.out.println(" ");	
		
		if (log4jPropFileName != null) {
			try {
				InputStream is = new FileInputStream(log4jPropFileName);
				
				Properties prop = new Properties();
				prop.load(is);
				is.close();
				String logDir = prop.getProperty("log4j.appender.R.File");
				if (logDir != null) {
					File logDirFile = new File(logDir).getParentFile();
					logDirFile.mkdirs();
					System.out.println("logdir " + logDirFile.toString() + " created successfully");
				}
			} catch (Exception e) {
				System.err.println("Unable to create dir(s) for Log4j log files");
				LOGGER.fatal("Unable to create dir(s) for Log4j log files");
				e.printStackTrace();
			}

			//PropertyConfigurator.configure(url);
			PropertyConfigurator.configure(log4jPropFileName);
			LOGGER.info("log4j configured from " + log4jPropFileName);
		}
		
		// From here, you can start using Logger
		LOGGER.info("********   NEW SCAN START  ************  " + new SimpleDateFormat("MM/dd/yy HH:mm:ss").format(new Date()));		
		
		//  Get the Persona properties file
		try {	    
			propFileName = propertyFileRoot + infoProps.getProperty("propertyFileName");
			LOGGER.info("Properties file name: " + propFileName);

		    InputStream inStream = new FileInputStream(propFileName);
			props = new Properties();
			props.load(inStream);
			
			LOGGER.info("Success loading properties file: " + propFileName);
			inStream.close();

			// get all property names
			Enumeration e = props.propertyNames();
			
			// Convert Enumeration to List
			List list = Collections.list(e);
			
			// Sort list
	        Collections.sort(list);
	        
	        //Convert list back to Enumeration
	        e = Collections.enumeration(list);
	        
			LOGGER.info("Persona Properties: ");

			while (e.hasMoreElements()) {
				String key = (String) e.nextElement();
				String keyValue = (String) props.getProperty(key).trim();
//				if (key.contains("password")) 
//					keyValue = "******** (The # of mask characters may be different)";
				LOGGER.info("Key = " + key + "  Value = " + keyValue);

				if ( key.startsWith("countryCode") && keyValue.length() > 0) {
					countryCodes.add(keyValue);
				} else if ( key.startsWith("empType") && keyValue.length() > 0) {
					empTypes.add(keyValue);
				} else if ( key.startsWith("serviceType") && ( key.indexOf('.') == -1 ) && keyValue.length() > 0) {
					svcTypes.add(keyValue);
				}
			}
			
			int totalCountryCodes = countryCodes.size();
			int totalEmpTypes = empTypes.size();
			int totalSvcTypes = svcTypes.size();
			LOGGER.info("totalCountryCodes: " + totalCountryCodes);
			LOGGER.info("totalEmpTypes: " + totalEmpTypes);
			LOGGER.info("totalSvcTypes: " + totalSvcTypes);

			LOGGER.info("Country Codes: ");			
			for (int i=0; i < totalCountryCodes; i++) {
				LOGGER.info("countryCode" + (i+1) + ": " + countryCodes.get(i));				
			}

			LOGGER.info("Employee Types: ");			
			for (int i=0; i < totalEmpTypes; i++) {
				LOGGER.info("empType" + (i+1) + ": " + empTypes.get(i));				
			}

			LOGGER.info("Service Types: ");			
			for (int i=0; i < totalSvcTypes; i++) {
				LOGGER.info("serviceType" + (i+1) + ": " + svcTypes.get(i));				
			}

		} catch (IOException ioe) {
			ioe.printStackTrace();
			LOGGER.fatal("Failed to load properties file: " + propFileName);
		}
 
		//  Get the Column Names properties file
		try {	    
			colNamesFileName = propertyFileRoot + infoProps.getProperty("columnNamesFile");
			LOGGER.info("Column Names Properties file name: " + colNamesFileName);

		    InputStream inStream = new FileInputStream(colNamesFileName);
		    colNamesProps = new Properties();
		    colNamesProps.load(inStream);
			
			LOGGER.info("Success loading Column Names Properties file: " + colNamesFileName);
			inStream.close();

			// get all column names
			Enumeration e = colNamesProps.propertyNames();
			
			// Convert Enumeration to List
			List list = Collections.list(e);
			
			// Sort list
	        Collections.sort(list);
	        
	        //Convert list back to Enumeration
	        e = Collections.enumeration(list);
	        
			LOGGER.info("Column Names: ");

			while (e.hasMoreElements()) {
				String key = (String) e.nextElement();
				String keyValue = (String) colNamesProps.getProperty(key).trim();
				LOGGER.info("Key = " + key + "  Value = " + keyValue);
			}

		} catch (IOException ioe) {
			ioe.printStackTrace();
			LOGGER.fatal("Failed to load Column Names Properties file: " + colNamesFileName);
		}
		
		//  Get the XML Elements properties file
		try {	    
			xmlElementsFileName = propertyFileRoot + infoProps.getProperty("xmlElementsFile");
			LOGGER.info("XML Elements Properties file name: " + xmlElementsFileName);

		    InputStream inStream = new FileInputStream(xmlElementsFileName);
		    xmlElementsProps = new Properties();
		    xmlElementsProps.load(inStream);
			
			LOGGER.info("Success loading Column Names Properties file: " + xmlElementsFileName);
			inStream.close();

			// get all column names
			Enumeration e = xmlElementsProps.propertyNames();
			
			// Convert Enumeration to List
			List list = Collections.list(e);
			
			// Sort list
	        Collections.sort(list);
	        
	        //Convert list back to Enumeration
	        e = Collections.enumeration(list);
	        
			LOGGER.info("XML Elements: ");

			while (e.hasMoreElements()) {
				String key = (String) e.nextElement();
				String keyValue = (String) xmlElementsProps.getProperty(key).trim();
				LOGGER.info("Key = " + key + "  Value = " + keyValue);
			}

		} catch (IOException ioe) {
			ioe.printStackTrace();
			LOGGER.fatal("Failed to load XML Elements Properties file: " + xmlElementsFileName);
		}

		
		int returnCode = -1;
		
		final String[] numWord = props.getProperty("numWordProp").split(",");
		for (int i=0; i < numWord.length; i++) {
			LOGGER.info("numWord[" + i + "]= " + numWord[i]);
		}

		final String[] wordFind = props.getProperty("wordFindProp").split(",");
		for (int i=0; i < wordFind.length; i++) {
			LOGGER.info("wordFind[" + i + "]= " + wordFind[i]);
		}

		final String[] wordChange = props.getProperty("wordChangeProp").split(",");
		for (int i=0; i < wordChange.length; i++) {
			LOGGER.info("wordChange[" + i + "]= " + wordChange[i]);
		}
		
		
		// Creating a Hashtable
		Hashtable<String, String> htProps = new Hashtable<String, String>();
		if ( wordFind.length == wordChange.length) {

			LOGGER.info("PizzaInitServlet: init: Adding Key and Value pairs to Hashtable...");
			for (int i=0; i < wordFind.length; i++) {
				
				// Adding Key and Value pairs to Hashtable
				htProps.put(wordFind[i], wordChange[i]);
			}
			
		} else {
			
			LOGGER.info("PizzaInitServlet: init: # of entries in numWordProp: " + numWord.length);
			LOGGER.info("PizzaInitServlet: init: # of entries in wordChangeProp: " + wordChange.length);
			LOGGER.info("PizzaInitServlet: init: # of entries in wordFindProp and wordChangeProp MUST be SAME");
		}

		LOGGER.info("PizzaInitServlet: init: # of entries in hashtable: " + htProps.size());
		
		
		

		// get flag for Direct Connect for EPWS
		accessEPWSFromDirectConnect = (new Boolean(props.getProperty("accessEPWSFromDirectConnect")).booleanValue());

		// get flag to generate MgrHub Data ONLY
		isMgrHubOnlyRun = (new Boolean(props.getProperty("isMgrHubOnlyRun")).booleanValue());

		// get flag to decide whether to generate MgrHub data on TEST server or not
		isMgrHubRunRequired = (new Boolean(props.getProperty("isMgrHubRunRequired")).booleanValue());

		// get flag to decide whether to copy the records to Compliance table from Compliance_pre table
		copyToComplianceTable = (new Boolean(props.getProperty("copyToComplianceTable")).booleanValue());

		// get flag to decide whether to create the records in Summary Compliance table from Compliance_pre table or not
		createSummaryCompliance = (new Boolean(props.getProperty("createSummaryCompliance")).booleanValue());

		// get flag to find out PROD or Dev/Test run
//		isProd = (new Boolean(props.getProperty("isProd")).booleanValue());

		PersonaMain personaMain = new PersonaMain();

		conn = personaMain.getDBConnection(props);

		isTestRun = (new Boolean(props.getProperty("isTestRun")).booleanValue());
		
		boolean isMgrHubSuccess = false;
		
		if (conn != null) {	

			LOGGER.info("isMgrHubOnlyRun: " + isMgrHubOnlyRun);
			LOGGER.info("isMgrHubSuccess: " + isMgrHubSuccess);

			if (isMgrHubOnlyRun) {	// Generate ONLY MgrHub data

				LOGGER.error("Starting Manager Hub Run Only...");

				// build XML file from Mgr Hub tables
				returnCode = personaMain.buildXMLFileData(conn, isTestRun, xmlElementsProps, props);
//				returnCode = -1;
		 		
		 		if ( returnCode >= 0 ) {
		 			// get connection from FTP Client to FTP server
					ftpClient = personaMain.getFTPClient(props);

			 		if ( ftpClient != null) {
			 			// upload XML file to FTP server
						returnCode = personaMain.uploadXMLFileToServer(ftpClient, isTestRun, props);
						
			 		} else {																	
						LOGGER.error("ERROR connecting to FTP Server.");
						returnCode = -1;

			 		}
			 		if ( returnCode >= 0 ) {
			 			isMgrHubSuccess = true;
			 		}
		 		}
		 		
			} else { // Perform Persona + MgrHub
				
				// Start with Persona
				
//				returnCode = personaMain.buildComplianceData(conn, isTestRun);
//		 		returnCode = -1;

				LOGGER.info("accessEPWSFromDirectConnect: " + accessEPWSFromDirectConnect);
				
	 			// process EPWS data
		 		if (accessEPWSFromDirectConnect) {
		 			returnCode = personaMain.filterDirectConnectEPWSData(conn, isTestRun, countryCodes, empTypes);
				} else {
					returnCode = personaMain.filterEPWSData(conn, isTestRun, countryCodes, empTypes);
				}  //EPWS

//		returnCode = 0;
		 		
		 		if ( returnCode >= 0 ) {
					// update currency exchange rates
		 			returnCode = personaMain.updateCurrencyXchangeRates(conn, isTestRun);
	
			 		if ( returnCode >= 0 ) {
			 			// process KFR data
			 			returnCode = personaMain.filterKFRData(conn, isTestRun);
		
			 			if ( returnCode >= 0 ) {
							// process WWER data
			 				returnCode = personaMain.filterWWERData(conn, isTestRun, countryCodes);
		
					 		if ( returnCode >= 0 ) {
								// process Service Catalog Asset data
					 			returnCode = personaMain.filterSvcCatData(conn, isTestRun);
		
						 		if ( returnCode >= 0 ) {
									// process GVI data
						 			returnCode = personaMain.filterGVIData(conn, isTestRun);
		
							 		if ( returnCode >= 0 ) {
										// build Compliance data
							 			returnCode = personaMain.buildComplianceData(conn, isTestRun);
		
								 		if ( returnCode >= 0 ) {
											// access iLog Engine
								 			returnCode = personaMain.updateComplianceData(conn, isTestRun, colNamesProps);

								 			// Release 3.2 changes
									 		if ( returnCode >= 0 ) {
									 			
									 			LOGGER.info("createSummaryCompliance: " + createSummaryCompliance);
									 			
												if (createSummaryCompliance) {

													// build Summary Compliance Table
													returnCode = personaMain.buildSummaryComplianceData(conn, isTestRun, svcTypes, props, colNamesProps);

												} // createSummaryCompliance

										 		if ( returnCode >= 0 ) {
										 			
										 			LOGGER.info("copyToComplianceTable: " + copyToComplianceTable);
										 			
													// decide to generate mgrHub data
											 		if (copyToComplianceTable) {
														// Copy into Compliance table
											 			returnCode = personaMain.copyToComplianceTable(conn, isTestRun);
	
											 			// START - Generate MgrHub data
														if ( returnCode >= 0 ) {
	
															LOGGER.info("isMgrHubRunRequired: " + isMgrHubRunRequired);
	
															// decide to generate mgrHub data
													 		if (isMgrHubRunRequired) {
																// build XML file from Mgr Hub tables
																returnCode = personaMain.buildXMLFileData(conn, isTestRun, xmlElementsProps, props);
	//													 		returnCode = -1;
														 		
														 		if ( returnCode >= 0 ) {
														 			// get connection from FTP Client to FTP server
																	ftpClient = personaMain.getFTPClient(props);
												
															 		if ( ftpClient != null) {														 			
															 			// upload XML file to FTP server
																		returnCode = personaMain.uploadXMLFileToServer(ftpClient, isTestRun, props);
																	
															 		} else {																	
																		LOGGER.error("ERROR connecting to FTP Server.");
																		returnCode = -1;
																		
																	} // upload XML file
															 		
															 		if ( returnCode >= 0 ) {
															 			isMgrHubSuccess = true;
															 		}
															 		
														 		} // connection from FTP Client
														 		
													 		} // decide to generate mgrHub data
													 		
														} // END - Generate MgrHub data
														
											 		} // Decide to copy to compliance table
											 			
										 		} // Copy into Compliance table
										 		
									 		} // build Summary Compliance Table

								 		} // access iLog Engine
								 		
							 		} // build Compliance data
							 		
						 		} // GVI
						 		
					 		} // Service Catalog
					 		
				 		} // WWER
			 			
		 			} // KFR
			 		
		 		}  // Currency exchange
		 		
			} // END...Perform Persona + MgrHub

		} else {
			LOGGER.error("ERROR connecting to DB.");
			returnCode = -1;		}
		
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				LOGGER.warn("Problem closing Connection. Resources might not be released ", e);
			}//end catch
		}//end if				

		LOGGER.info("isMgrHubSuccess: " + isMgrHubSuccess);
		LOGGER.info("isMgrHubRunRequired: " + isMgrHubRunRequired);

		if (isMgrHubSuccess) {
 			LOGGER.info("********   MGRHUB RUN FINISHED WITH SUCCESS ************  " + new SimpleDateFormat("MM/dd/yy HH:mm:ss").format(new Date()));		
 		} else {
 	 		if (isMgrHubRunRequired) {
 				LOGGER.info("********   ERROR ----  MGRHUB RUN FINISHED WITH ERRORS  ************  " + new SimpleDateFormat("MM/dd/yy HH:mm:ss").format(new Date()));		
 	 		} else {
 				LOGGER.info("********   INFO ----  MGRHUB RUN NOT REQUIRED  ************  " + new SimpleDateFormat("MM/dd/yy HH:mm:ss").format(new Date()));		
 	 		}
 		}

 		if ( returnCode >= 0 ) {
 			LOGGER.info("********   SCAN FINISHED WITH SUCCESS ************  " + new SimpleDateFormat("MM/dd/yy HH:mm:ss").format(new Date()));		
 		} else {
			LOGGER.info("********   ERROR ----  SCAN FINISHED WITH ERRORS  ************  " + new SimpleDateFormat("MM/dd/yy HH:mm:ss").format(new Date()));		
 		}

	}

}
