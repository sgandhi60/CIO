package com.ibm.ivr.cvs.dao;

// jdbc imports
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import javax.sql.DataSource;

// logging imports
import org.apache.log4j.Logger;

/**
 * This is the base class for all DAO objects. Contains generic operations used
 * by all DAO objects.
 *
 */


public class BaseDAO {
	
	private final static Logger LOGGER = Logger.getLogger(BaseDAO.class);
	
	/**
	 * Returns a connection to DB
	 * 
	 * @return DB connection object
	 * @throws SQLException if the connection to the DB fails
	 */
	
	public final Connection getConnection(String jndiName, String sessionid) throws SQLException {
		
		String logToken = new StringBuffer("[").append(sessionid).append("] ").toString();
		
		LOGGER.debug(new StringBuffer(logToken).append("Getting the DataSource for JNDI=").append(jndiName));
		
		DataSource ds = DBServiceLocator.getDBDataSource(jndiName,sessionid);
		
		if (ds == null) {
			throw new SQLException(new StringBuffer("DB DataSource is null, it may not be defined correctly - ").append(jndiName).toString());
		}//end if
		
		return ds.getConnection();
	}//end method getConnection
	
	/**
	 * Closes the given DB resources
	 * 
	 * @param conn DB connection object
	 * @param stmt Statement object
	 * @param rs ResultSet object
	 */
	public final void releaseResource(final Connection conn, final Statement stmt, final ResultSet rs,String sessionid) {
		
		String logToken = new StringBuffer("[").append(sessionid).append("] ").toString();
		
		if (rs != null) {
			try {
				rs.close();
			} catch (SQLException e) {
			}//end catch
		}//end if
		
		if (stmt != null) {
			try {
				stmt.close();
			} catch (SQLException e) {
				LOGGER.warn(new StringBuffer(logToken).append("Problem closing PreparedStatement. Resources might not be released: ").append(e.getMessage()));
				//LOGGER.warn("Problem closing PreparedStatement. Resources might not be released", e);
			}//end catch
		}//end if
		
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				LOGGER.warn(new StringBuffer(logToken).append("Problem closing Connection Resources might not be released: ").append(e.getMessage()));
				//LOGGER.warn("Problem closing Connection. Resources might not be released", e);
			}//end catch
		}//end if				
	}//end method releaseResource

	/**
	 * Closes the given DB resources
	 * 	but keeps connection
	 * 
	 * @param stmt Statement object
	 * @param rs ResultSet object
	 */
	public final void releaseResource(final Statement stmt, final ResultSet rs, String sessionid) {
		
		String logToken = new StringBuffer("[").append(sessionid).append("] ").toString();
		
		if (rs != null) {
			try {
				rs.close();
			} catch (SQLException e) {
			}//end catch
		}//end if
		
		if (stmt != null) {
			try {
				stmt.close();
			} catch (SQLException e) {
				LOGGER.warn(new StringBuffer(logToken).append("Problem closing PreparedStatement. Resources might not be released: ").append(e.getMessage()));
				//LOGGER.warn("Problem closing PreparedStatement. Resources might not be released", e);
			}//end catch
		}//end if
		
	}//end method releaseResource	
	
}//end class BaseDAO
