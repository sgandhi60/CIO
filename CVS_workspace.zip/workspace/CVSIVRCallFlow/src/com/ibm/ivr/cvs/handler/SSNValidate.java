package com.ibm.ivr.cvs.handler;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;
import com.ibm.ivr.cvs.dao.CertificationDAO;
import com.ibm.ivr.cvs.dao.DAOException;
import com.ibm.ivr.cvs.data.Employee;

/**
 * Servlet implementation class SSNValidate
 */
public class SSNValidate extends HttpServlet {
       
 	private static final long serialVersionUID = 7804657022661031996L;
	private static Logger LOGGER = Logger.getLogger(SSNValidate.class);

	/**
     * @see HttpServlet#HttpServlet()
     */
    public SSNValidate() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		// get session from Servlet request, created if not existed yet
		HttpSession session = request.getSession(true);
		String callid = (String) session.getAttribute("callid");
		boolean testCall = ((Boolean) session.getAttribute("testCall")).booleanValue();

		//create the log Token for later use, use StringBuffer to reduce number
		// of String objects
		String logToken = new StringBuffer("[").append(callid).append("] ").toString();
			 
		 if (testCall)
		 	LOGGER.debug(new StringBuffer(logToken).append("Entering Handler: SSNValidate::"));
		 
		 CertificationDAO certDAO = (CertificationDAO)session.getServletContext().getAttribute("certificationDAO");
		 Employee employee = (Employee) session.getAttribute("employee");
		 String ssn_option = (String)session.getAttribute("ssn_option");
		 String identifierEntered = (String)session.getAttribute("identifierEntered");
		 String depSSNNumberEntered = (String)session.getAttribute("depSSNNumberEntered");
		 
		 //boolean statusResult = false;
		 String hRC = "S";
		 
		 // 
		   try{
			   if(!certDAO.updateDependentSSN(employee, identifierEntered, depSSNNumberEntered, ssn_option, callid)){
				   LOGGER.error(new StringBuffer(logToken).append("Error updating dependent SSN:: Check Application Logs"));
				   hRC = "E";
			   }
		   }catch (DAOException de){
		     LOGGER.error(new StringBuffer(logToken).append("Exception updating dependent SSN::"+de.toString()));
		     if (de.getMessage() != null && de.getMessage().equalsIgnoreCase("Failed to connect to DB"))
		    	 hRC = "C";
		     else
	            hRC = "E";
		   }
		   
		   		   
		 // Store the handler processing result
		 session.setAttribute("hRC", hRC);
		 
		 if (testCall)
			 	LOGGER.debug(new StringBuffer(logToken).append("Leaving Handler: SSNValidate::")
			 			                               .append("  hRC::")
			 			                               .append(session.getAttribute("hRC")));
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request,response);
	}

}
