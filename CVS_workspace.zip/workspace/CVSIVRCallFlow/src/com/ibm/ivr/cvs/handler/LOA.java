package com.ibm.ivr.cvs.handler;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.ibm.ivr.cvs.dao.LoaDAO;
import com.ibm.ivr.cvs.dao.DAOException;
import com.ibm.ivr.cvs.data.Employee;

public class LOA extends HttpServlet {
       
	/**
	 * 
	 */
	private static final long serialVersionUID = -1655024333955860245L;
	private static Logger LOGGER = Logger.getLogger(LOA.class);

	/**
     * @see HttpServlet#HttpServlet()
     */
    public LOA() {
        super();
        // TODO Auto-generated constructor stub xx
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		// get session from Servlet request, created if not existed yet
		HttpSession session = request.getSession(true);
		String callid = (String) session.getAttribute("callid");
		boolean testCall = ((Boolean) session.getAttribute("testCall")).booleanValue();

		//create the log Token for later use, use StringBuffer to reduce number
		// of String objects
		String logToken = new StringBuffer("[").append(callid).append("] ").toString();
			 
		 if (testCall)
		 	LOGGER.debug(new StringBuffer(logToken).append("Entering Handler: LOA::"));
		 
		 LoaDAO loaDAO = (LoaDAO)session.getServletContext().getAttribute("loaDAO");
		 
		 // Retrieve common session variables for LOA activities
		 Employee employee = (Employee) session.getAttribute("employee");		 
		 String loaCmd = (String) session.getAttribute("loaCmd");
		 
		 if (testCall)
		 	LOGGER.debug(new StringBuffer(logToken).append("loaCmd::")
		 			                               .append(loaCmd));

		 //boolean statusResult = false;
		 String hRC = "S";
		 
		 // 
		   try{
			   if (loaCmd != null && loaCmd.trim().equalsIgnoreCase("new")){
				// Remove re-record flag in the event the caller returned to the MM somehow.  
				   session.removeAttribute("LOAzeroLengthCheck");
				// Retrieve Session variables needed by LOA Handler
					 String loaExpectedLastDay = (String) session.getAttribute("loaExpectedLastDay");
					 String loaReturnToWorkDay = (String) session.getAttribute("loaReturnToWorkDay");
					 String loaNewDesc1 = (String) session.getAttribute("loaNewDesc1");
					 String loaNewDesc2 = (String) session.getAttribute("loaNewDesc2");
					 String loaNewDesc3 = (String) session.getAttribute("loaNewDesc3");
					 String loaNewDesc4 = (String) session.getAttribute("loaNewDesc4");
					 String loaNewDesc5 = (String) session.getAttribute("loaNewDesc5");
					 String loaNewDesc6 = (String) session.getAttribute("loaNewDesc6");

					 if (testCall)
						 	LOGGER.debug(new StringBuffer(logToken).append("loaExpectedLastDay::")
						 			                               .append(loaExpectedLastDay)
						 			                               .append("  loaReturnToWorkDay::")
						 			                               .append(loaReturnToWorkDay)
						 			                               .append(" loaNewDesc1::")
						 			                               .append(loaNewDesc1)
						 			                               .append(" loaNewDesc2::")
						 			                               .append(loaNewDesc2)
						 			                               .append(" loaNewDesc3::")
						 			                               .append(loaNewDesc3)
						 			                               .append(" loaNewDesc4::")
						 			                               .append(loaNewDesc4)
						 			                               .append(" loaNewDesc5::")
						 			                               .append(loaNewDesc5)
						 			                               .append(" loaNewDesc6::")
						 			                               .append(loaNewDesc6));
					 // loaNewDesc1  set by 32503
					 // loaNewDesc2  set by 32504, 32511
					 // loaNewDesc3  set by 32506
					 // loaNewDesc4  set by 32505
					 // loaNewDesc5  set by 32800
					 // loaNewDesc6  set by 32805
					 
					 //
					 // Set loaType  
					 //
					 String loaType = " ";
					 if (loaNewDesc3.trim().equalsIgnoreCase("1"))
						 loaType = "C";
					 else if (loaNewDesc3.trim().equalsIgnoreCase("2"))
						 loaType = "I";
					 else if (loaNewDesc3.trim().equalsIgnoreCase("3"))
						 loaType = "R";
					 else
						 loaType = "C";

					 //
					 // Set loa_reason
					 //
					 String loa_reason = " ";
					 if (loaNewDesc1.trim().equalsIgnoreCase("3"))
						 loa_reason = "A";
					 //not a possible combination
					 //else if (loaNewDesc1.trim().equalsIgnoreCase("1") && loaNewDesc2.trim().equalsIgnoreCase("4"))
					 //	 loa_reason = "C";
					 else if (loaNewDesc1.trim().equalsIgnoreCase("2") && loaNewDesc2.trim().equalsIgnoreCase("4"))
						 loa_reason = "C";
					 else if (loaNewDesc1.trim().equalsIgnoreCase("7") && loaNewDesc6.trim().equalsIgnoreCase("1"))
						 loa_reason = "H";
					 else if (loaNewDesc1.trim().equalsIgnoreCase("7") && loaNewDesc6.trim().equalsIgnoreCase("2"))
						 loa_reason = "D";
					 else if (loaNewDesc1.trim().equalsIgnoreCase("6") && loaNewDesc5.trim().equalsIgnoreCase("1"))
						 loa_reason = "E";
					 else if (loaNewDesc1.trim().equalsIgnoreCase("6") && loaNewDesc5.trim().equalsIgnoreCase("2"))
						 loa_reason = "I";
					 else if (loaNewDesc1.trim().equalsIgnoreCase("6") && loaNewDesc5.trim().equalsIgnoreCase("3"))
						 loa_reason = "R";
					//not a possible combination
					// else if (loaNewDesc1.trim().equalsIgnoreCase("1") && loaNewDesc2.trim().equalsIgnoreCase("3"))
					//	 loa_reason = "F";
					 else if (loaNewDesc1.trim().equalsIgnoreCase("2") && loaNewDesc2.trim().equalsIgnoreCase("3"))
						 loa_reason = "F";
					 else if (loaNewDesc1.trim().equalsIgnoreCase("1") && loaNewDesc2.trim().equalsIgnoreCase("2"))
						 loa_reason = "M";
					//not a possible combination
					// else if (loaNewDesc1.trim().equalsIgnoreCase("2") && loaNewDesc2.trim().equalsIgnoreCase("2"))
					//	 loa_reason = "M";
					 else if (loaNewDesc1.trim().equalsIgnoreCase("4"))
						 loa_reason = "P";
					 else if (loaNewDesc1.trim().equalsIgnoreCase("5"))
						 loa_reason = "W";
					 else if (loaNewDesc1.trim().equalsIgnoreCase("1") && loaNewDesc2.trim().equalsIgnoreCase("1"))
						 loa_reason = "S";
					//not a possible combination
					// else if (loaNewDesc1.trim().equalsIgnoreCase("2") && loaNewDesc2.trim().equalsIgnoreCase("1"))
					// loa_reason = "S";

					 //
					 // loa_reason2
					 //
					 // January 05, 2011   Field not used.  Setting default value.
					 String loa_reason2 = " ";
					 /*
					 if (loaNewDesc1.trim().equalsIgnoreCase("1"))
						 loa_reason2 = "D";
					 else if (loaNewDesc1.trim().equalsIgnoreCase("2"))
						 loa_reason2 = "F";
					 else if (loaNewDesc1.trim().equalsIgnoreCase("3"))
						 loa_reason2 = "M";
					 else if (loaNewDesc1.trim().equalsIgnoreCase("4"))
						 loa_reason2 = "P";
					 else if (loaNewDesc1.trim().equalsIgnoreCase("5"))
						 loa_reason2 = "W";
					 else if (loaNewDesc1.trim().equalsIgnoreCase("6") && loaNewDesc5.trim().equalsIgnoreCase("1"))
						 loa_reason2 = "P";
					 else if (loaNewDesc1.trim().equalsIgnoreCase("6") && loaNewDesc5.trim().equalsIgnoreCase("2"))
						 loa_reason2 = "M";
					 else if (loaNewDesc1.trim().equalsIgnoreCase("6") && loaNewDesc5.trim().equalsIgnoreCase("3"))
						 loa_reason2 = "W";
					 else if (loaNewDesc1.trim().equalsIgnoreCase("7"))
						 loa_reason2 = "M";
				     */
					 
					 //
					 // Set military_leave
					 //
					 // Defect 170315
					 String military_leave = " ";
					 
                     if (loaNewDesc1.trim().equalsIgnoreCase("3") && loaNewDesc4.trim().equalsIgnoreCase("1"))
						 military_leave = "E";
					 else if (loaNewDesc1.trim().equalsIgnoreCase("3") && loaNewDesc4.trim().equalsIgnoreCase("2"))
						 military_leave = "R";
					 else if (loaNewDesc1.trim().equalsIgnoreCase("3") && loaNewDesc4.trim().equalsIgnoreCase("3"))
						 military_leave = "T";

					 //
					 // Set work_related
					 //	Defect 170504
                     String work_related = null;
					 if (loaNewDesc1.trim().equalsIgnoreCase("5"))
						 work_related = "Y";
					 else
						 work_related = "N";
					 //
					 // Set loa_sub_reason
					 //
					 // January 05, 2011   Field not used.  Setting default value.
					 String loa_sub_reason = " ";
                    

					 if (testCall)
						 	LOGGER.debug(new StringBuffer(logToken).append("loaType::")
						 			                               .append(loaType)
						 			                               .append("  loaExpectedLastDay::")
						 			                               .append(loaExpectedLastDay)
						 			                               .append(" loaReturnToWorkDay::")
						 			                               .append(loaReturnToWorkDay)
						 			                               .append(" loa_reason::")
						 			                               .append(loa_reason)
						 			                               .append(" loa_reason2::")
						 			                               .append(loa_reason2)
						 			                               .append(" loa_sub_reason::")
						 			                               .append(loa_sub_reason)
						 			                               .append(" military_leave::")
						 			                               .append(military_leave)
						 			                               .append(" work_related::")
						 			                               .append(work_related));
                    
			     if(!loaDAO.createLoa(employee, loaType, loaExpectedLastDay, loaReturnToWorkDay, loa_reason, loa_reason2, loa_sub_reason, military_leave, work_related, callid)){
				     LOGGER.error(new StringBuffer(logToken).append("Error creating LOA:: Check Application Logs"));
				     hRC = "E";
			     }
			   }else if (loaCmd != null && loaCmd.trim().equalsIgnoreCase("std")){
				     if(!loaDAO.isEligibleForSTD(employee, callid)){
						 if (testCall)
							 	LOGGER.debug(new StringBuffer(logToken).append("LOA handler (std)::DAO returned False caller not eligible for STD"));

					     //LOGGER.error(new StringBuffer(logToken).append("Error Checking for LOA STD:: Check Application Logs"));
					     hRC = "E";
				     }
				   
			   }else if (loaCmd != null && loaCmd.trim().equalsIgnoreCase("get")){
				     String loaExtendLastDay = (String) session.getAttribute("loaExtendLastDay");
				       					 
					 if (testCall)
					 	LOGGER.debug(new StringBuffer(logToken).append("loaExtendLastDay::")
					 			                               .append(loaExtendLastDay));

				     if(!loaDAO.getLoaByDate(employee, loaExtendLastDay, callid)){
						 if (testCall)
							 	LOGGER.debug(new StringBuffer(logToken).append("LOA handler (get)::DAO returned False. No LOA record found"));

					     //LOGGER.error(new StringBuffer(logToken).append("Error Checking for LOA STD:: Check Application Logs"));
					     hRC = "E";
				     }
				   
			   }else if (loaCmd != null && loaCmd.trim().equalsIgnoreCase("update")){
				     String loaExtendReturnDay = (String) session.getAttribute("loaExtendReturnDay");
				     String loaExtDesc1 = (String) session.getAttribute("loaExtDesc1");
				      					 
					 if (testCall)
					 	LOGGER.debug(new StringBuffer(logToken).append("loaExtendReturnDay::")
					 			                               .append(loaExtendReturnDay)
					 			                               .append("  loaExtDesc1::")
					 			                               .append(loaExtDesc1));
				     
					 // Set LOA Type
					 String loaType = " ";
					 if (loaExtDesc1.trim().equalsIgnoreCase("1"))
						 loaType = "C";
					 else if (loaExtDesc1.trim().equalsIgnoreCase("2"))
						 loaType = "I";
					 else if (loaExtDesc1.trim().equalsIgnoreCase("3"))
						 loaType = "R";

  					 
					 if (testCall)
					 	LOGGER.debug(new StringBuffer(logToken).append("loaType::")
					 			                               .append(loaType));

				     if(!loaDAO.updateLoa(employee, loaExtendReturnDay, loaType, callid)){
						 if (testCall)
							 	LOGGER.debug(new StringBuffer(logToken).append("LOA handler (update)::DAO returned False. No LOA record found"));

					     LOGGER.error(new StringBuffer(logToken).append("Error Updating LOA:: Check Application Logs"));
					     hRC = "E";
				     }
				   
			   }else if (loaCmd != null && loaCmd.trim().equalsIgnoreCase("Intermittent")){
				     Float LOAhourMinConverted = (Float) session.getAttribute("LOAhourMinConverted");  // Float
				     //String loaMinutes = (String) session.getAttribute("loaMinutes");
				     String intermittentResaon = (String) session.getAttribute("intermittentResaon");
				     String intermittentResaonDesc = (String) session.getAttribute("intermittentResaonDesc");
				     String loaIntermittentReturnDay = (String) session.getAttribute("loaIntermittentReturnDay");
  					 
					 if (testCall)
					 	LOGGER.debug(new StringBuffer(logToken).append("LOAhourMinConverted::")
					 			                               .append(LOAhourMinConverted)
					 			                               .append("  loaIntermittentReturnDay::")
					 			                               .append(loaIntermittentReturnDay)
					 			                               .append("  intermittentResaon::")
					 			                               .append(intermittentResaon)
					 			                               .append("  intermittentResaonDesc::")
					 			                               .append(intermittentResaonDesc));
				     
				     if(!loaDAO.reportIntermittentLOAHours(employee, intermittentResaon, loaIntermittentReturnDay, LOAhourMinConverted, callid)){
						 if (testCall)
							 	LOGGER.debug(new StringBuffer(logToken).append("LOA handler (get)::DAO returned False. No LOA record found"));

					     LOGGER.error(new StringBuffer(logToken).append("Error Checking for LOA STD:: Check Application Logs"));
					     hRC = "E";
				     }
				   
			   }else{
				     LOGGER.error(new StringBuffer(logToken).append("Invalid loaCmd::")
				    		                                 .append(loaCmd));
			         hRC = "E";				   
			   }
		   }catch (DAOException de){
		     LOGGER.error(new StringBuffer(logToken).append("Exception in LoaDAO::"+de.toString()));
		     if (de.getMessage() != null && de.getMessage().equalsIgnoreCase("Failed to connect to DB"))
		    	 hRC = "C";
		     else
	            hRC = "E";
		   }
		   
		   		   
		 // Store the handler processing result
		 session.setAttribute("hRC", hRC);
		 
		 if (testCall)
			 	LOGGER.debug(new StringBuffer(logToken).append("Leaving Handler: LOA::")
			 			                               .append("  hRC::")
			 			                               .append(session.getAttribute("hRC")));
	 return;
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request,response);
	}

}

