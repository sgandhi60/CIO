package com.ibm.ivr.cvs.handler;

import java.io.IOException;
import java.util.Calendar;
import java.util.Properties;
import java.util.TimeZone;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.ibm.ivr.cvs.dao.DAOException;
import com.ibm.ivr.cvs.dao.VacationDAO;
import com.ibm.ivr.cvs.data.Employee;
import com.ibm.ivr.framework.utilities.Common;

/**
 * Get vacation hours
 * Input: employee (from session) 
 * Output: 
 * 		  employee object vacation hours fields updated (into session) 
 *
 *Revision history:
 * <p>
 * 
 * 2010-10-12: initial version
 * <p>
 * 
 * @author Fang Wang
 * @version 2010-10-12
 *
 */
public class GetVacationHours extends HttpServlet implements Servlet{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3304978573825826054L;
	
	private static final String[] MONTHS = {"January", "February", "March", "April",
											"May", "June", "July", "August",
											"September", "October", "November", "December"};
	
	private static Logger LOGGER = Logger.getLogger(GetVacationHours.class);

	public void doGet(HttpServletRequest req, HttpServletResponse resp)
							throws ServletException, IOException {

	// get session from Servlet request, created if not existed yet
	HttpSession session = req.getSession(true);
	//Properties prop = (Properties)session.getServletContext().getAttribute("globalProp");

	String callid = (String) session.getAttribute("callid");

	boolean testCall = ((Boolean) session.getAttribute("testCall")).booleanValue();

	//create the log Token for later use, use StringBuffer to reduce number
	// of String objects
	String logToken = new StringBuffer("[").append(callid).append("] ").toString();
		 
	 if (testCall)
	 	LOGGER.debug(new StringBuffer(logToken).append("Entering Handler: GetVacationHours"));
	
	 //check if vacation hours should be queried or not
	Properties cvsProp = (Properties) session.getServletContext().getAttribute("cvsProp");
	Properties globalProp = (Properties) session.getServletContext().getAttribute("globalProp");
	
	try {
		
		String timeZone = globalProp.getProperty("timeZone");
		String month = cvsProp.getProperty("vacationNotAvailMonth");
	
		Calendar calNow = null;
		if (timeZone == null)
			calNow = Calendar.getInstance();
		else
			calNow = Calendar.getInstance(TimeZone.getTimeZone(timeZone));
		
		int monthNow = calNow.get(Calendar.MONTH);
		
		if (MONTHS[monthNow].equalsIgnoreCase(month)){
			session.setAttribute("vacationHrsAvailable", "FALSE");
			session.setAttribute("hRC", "S");
		}else{
			session.setAttribute("vacationHrsAvailable", "TRUE");
			
			int yearNow = calNow.get(Calendar.YEAR);
			session.setAttribute("vacationPlanYear", Common.EMPTYSTRING+yearNow);
			
		    // Get attributes from the session
			Employee employee = (Employee) session.getAttribute("employee");
			
			if (employee != null){
				//calling VacationDAO to search
				VacationDAO vDAO = (VacationDAO) session.getServletContext().getAttribute("vacationDAO");
				
				try {
					if (vDAO.getVacation(employee, callid)){
						//defect 170508: check if any of the values is null or negative
						if ((employee.getVacAllocatedHours() == null ||
								employee.getVacAllocatedHours().startsWith("-")) ||
							(employee.getVacEarnedHours() == null ||
								employee.getVacEarnedHours().startsWith("-")) ||
							(employee.getVacUsedHours() == null ||
								employee.getVacUsedHours().startsWith("-")))
							session.setAttribute("hRC", "E");
						else
							session.setAttribute("hRC", "S");
					}
					else
						session.setAttribute("hRC", "E");
					
					//employee.setVacAllocatedHours("40");
					//employee.setVacEarnedHours("20");
					//employee.setVacUsedHours("10.5");
					
				}catch(DAOException e){
					LOGGER.debug(new StringBuffer(logToken).append("failed to get vacation hours: ").append(e.getMessage()));
				     if (e.getMessage() != null && e.getMessage().equalsIgnoreCase("Failed to connect to DB"))
				    	 session.setAttribute("hRC", "C");
				     else
				    	 session.setAttribute("hRC", "E");			
				}
			}
			else {
				LOGGER.warn(new StringBuffer(logToken).append("no employee object in the session"));
				session.setAttribute("hRC", "E");
			}
		}
	}catch(Exception e){
		LOGGER.debug(new StringBuffer(logToken).append("failed to determine vacation hours: ").append(e.getMessage()));
	    session.setAttribute("hRC", "E");			
	}
   return;
  }
}
