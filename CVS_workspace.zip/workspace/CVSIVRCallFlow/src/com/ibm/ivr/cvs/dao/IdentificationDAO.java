/* History
 * 11/12/2010 FSW: Initial creation 
 * 12/03/2010 FSW: Modify message for DAOException for no DB connection
 * 01/10/2011 FSW: Defect 170295 Remove logging of personal data, defect
 * 				   Also remove any unused variables 
 * 01/24/2011 FSW: Add sessionid to logging.  Defect 170371
 * 01/25/2011 FSW: Add query timeout.  Defect 170321
 * 05/23/2011 FSW: Save 'location' column retrieved to Employee object (previously column was
 * 		retrieved, but never used).
*/

package com.ibm.ivr.cvs.dao;

	import com.ibm.ivr.cvs.dao.BaseDAO;
	import com.ibm.ivr.cvs.data.Employee;
	
//import java.io.PrintWriter;
//	import java.sql.CallableStatement;
	import java.sql.Connection;
//	import java.sql.Date;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;
	import java.sql.SQLException;
//	import java.sql.Types;
import org.apache.log4j.Logger;


		public class IdentificationDAO extends BaseDAO{
			
		private final static Logger LOGGER = Logger.getLogger(IdentificationDAO.class);

		//private Connection conn = null; Defect 170481, move to methods
		private String jndiName = null;
		
		private final static String SQL_QUERY_ID_STMT = "SELECT EMPLID FROM SYSADM.PS_C_SSN_SELECT_VW WHERE SSN = ?";
		
		//170553
		private final static String SQL_QUERY_EMP_STMT = 
			"SELECT substr(to_char(BIRTHDATE,'MMDDYYYY'),1,10)BIRTHDATE, JOBCODE_DESCR, COMP_FREQUENCY, SSN, " +
			" LOCATION, DEPTID, GL_PAY_TYPE, EMPL_STATUS, JOBCODE FROM SYSADM.PS_C_EA_1_VW WHERE EMPLID = ?";
		
		private final static String SQL_QUERY_STATE_STMT = 
			"SELECT elig_config2 FROM PS_JOB WHERE EMPLID = ?";
		
		private int sqlTimeout = 0;  //timeout for stmt execution in secs

		/********************************************************************************
		* Constructor
		/********************************************************************************/
		public IdentificationDAO(String jndiName, int timeout) {
			// initialization
			this.jndiName = jndiName;
			this.sqlTimeout = timeout;
			
		    LOGGER.debug("******** Created IdentificationDAO ********");
			LOGGER.debug(new StringBuffer("-- jndiName = ").append(jndiName));
		}
		
		/********************************************************************************
		* Get Employee ID based on SSN
		/********************************************************************************/
		public String lookupSSN(String ssn, String sessionid)throws DAOException {
			Connection conn = null;
			String employeeID = null;
			PreparedStatement stmt = null;
			ResultSet rs = null;
				
			String logToken = new StringBuffer("[").append(sessionid).append("] ").toString();
			LOGGER.debug(new StringBuffer(logToken).append("********Entering IdentificationDAO::lookupSSN********"));
			LOGGER.debug(new StringBuffer(logToken).append(" -- ssn = ").append(ssn.substring((ssn.length()-4),ssn.length())));
			 
			//Connect to the DB	
			try {
				conn = getConnection(jndiName,sessionid);
			} catch (SQLException e) {
				LOGGER.error(new StringBuffer(logToken).append("Exception getting a connection to the DB: ").append(e.getMessage()));
				throw new DAOException("Failed to connect to DB");
			}
			//get information
			try {			
				if (conn!=null){
						
					LOGGER.debug(new StringBuffer(logToken).append("function IdentificationDAO.lookupSSN"));
					LOGGER.debug(new StringBuffer(logToken).append("-- ssn: ").append(ssn.substring(ssn.length()-4,ssn.length())));
										
					stmt = conn.prepareStatement(SQL_QUERY_ID_STMT);
					stmt.setQueryTimeout(sqlTimeout);
					stmt.setString(1,ssn);
	                rs = stmt.executeQuery();
		             
		            if (rs.next()){
			        	 if (rs.getString(1)!=null) {
			            	 employeeID = rs.getString(1);
			            	 	            	             	 
			        	 } else { // empty record      	 
			        		 LOGGER.debug(new StringBuffer(logToken).append("Empty record found for SSN = ").append(ssn.substring(ssn.length()-4,ssn.length())));
			        	 }
			        } else{ //no result set found
			        	LOGGER.debug(new StringBuffer(logToken).append("No record found for SSN = ").append(ssn.substring(ssn.length()-4,ssn.length())));
			        }
		            
					} else {  //connection=null
						LOGGER.error(new StringBuffer(logToken).append("No connection made to DB"));
						throw new DAOException("Failed to connect to DB");
					}
				 }catch(Exception e){ //Problem encountered getting query results
					 LOGGER.error(new StringBuffer(logToken).append("Exception encountered in lookupSSN query").append(e.getMessage()));
					 throw new DAOException(e.getMessage());
					
				 }finally{
					 releaseResource(conn, stmt, rs, sessionid);		 
				 }

			return employeeID;
		
	}			

		/********************************************************************************
		* Get Employee info based on employee ID and create Employee object
		/********************************************************************************/		
		
		public Employee lookup(String employeeID, String sessionid) throws DAOException {
			
			Connection conn = null;
			PreparedStatement stmt = null;
			ResultSet rs = null;
			Employee employee = null; 
			
			String logToken = new StringBuffer("[").append(sessionid).append("] ").toString();
			LOGGER.debug(new StringBuffer(logToken).append("******Entered IndentificationDAO::lookup()"));
			LOGGER.debug(new StringBuffer(logToken).append("-- employeeId = ").append(employeeID.substring(employeeID.length()-3,employeeID.length())));

			//Connect to the DB	
			try {
				conn = getConnection(jndiName, sessionid);
			} catch (SQLException e) {
				LOGGER.error(new StringBuffer(logToken).append("Exception getting a connection to the CVSDB: ").append(e.getMessage()));
				throw new DAOException("Failed to connect to DB");
			}
			//get information
			try {			
				if (conn!=null){
					stmt = conn.prepareStatement(SQL_QUERY_EMP_STMT);
					stmt.setQueryTimeout(sqlTimeout);
					stmt.setString(1,employeeID); 
					
					// for reference:
					//"SELECT substr(to_char(BIRTHDATE,'MMDDYYYY'),1,10)BIRTHDATE, JOBCODE_DESCR, COMP_FREQUENCY, SSN, " +
					//" LOCATION, DEPTID, GL_PAY_TYPE, EMPL_STATUS, JOBCODE FROM SYSADM.PS_C_EA_1_VW WHERE EMPLID = ?";
					
	                rs = stmt.executeQuery();
	               
		            if (rs.next()){		  
		            	     employee = new Employee();   //create new Employee if we find data, otherwise leave null
			            	 employee.employeeID=employeeID;
			            	 employee.employeeDOB=rs.getString(1);
			            	 employee.jobDescription=rs.getString(2);
			            	 // rs.getString(3):comp_frequency
			            	 // rs.getString(4):ssn
			            	// 170553
			            	 employee.employeeLocation=rs.getString(5);
			            	 employee.departmentID = rs.getString(6);
			             	 // rs.getString(7):GL_PAY_TYPE
			            	 employee.employmentStatus= rs.getString(8);
			            	 // rs.getString(9):jobcode 
			            	 
			            	 
			         } else {//no result set found
			        		 LOGGER.debug(new StringBuffer(logToken).append("No match found for employeeID").append(employeeID.substring(employeeID.length()-3,employeeID.length())));		        	
		             }

					} else {  //connection=null
			        		 LOGGER.error(new StringBuffer(logToken).append("No connection created to DB"));
			        		 throw new DAOException("Failed to connect to DB");
			        	 }
			        	
				 }catch(Exception e){	//Problem encountered getting query results
					 LOGGER.error(new StringBuffer(logToken).append("Exception encountered getting employee info").append(e.getMessage()));
					 throw new DAOException (e.getLocalizedMessage());
					 
				 }finally{
					 releaseResource(conn, stmt, rs, sessionid);		 
				 }
			
		return employee;
		}

		/********************************************************************************
		* Get Employee state info based on employee ID and update Employee object
		/********************************************************************************/				
		public boolean getState(Employee employee, String sessionid) throws DAOException {
			Connection conn = null;
			String employeeID = employee.getEmployeeID();
			PreparedStatement stmt = null;
			ResultSet rs = null;
			boolean rcb = true;
			
			String logToken = new StringBuffer("[").append(sessionid).append("] ").toString();
			LOGGER.debug(new StringBuffer(logToken).append("*******Entered IndentificationDAO::()"));
			LOGGER.debug(new StringBuffer(logToken).append("-- employeeId = ").append(employeeID.substring(employeeID.length()-3,employeeID.length())));

			//Connect to the DB	
			try {
				conn = getConnection(jndiName, sessionid);
			} catch (SQLException e) {
				LOGGER.error(new StringBuffer(logToken).append("Exception getting a connection to the CVSDB: ").append(e.getMessage()));
				throw new DAOException("Failed to connect to DB");
			}
			//get information
			try {			
				if (conn!=null){
					// for reference:
					//SQL_QUERY_STATE_STMT = "SELECT elig_config2 FROM PS_JOB WHERE EMPLID = ?
					stmt = conn.prepareStatement(SQL_QUERY_STATE_STMT);
					stmt.setQueryTimeout(sqlTimeout);
					stmt.setString(1,employeeID); 			

					LOGGER.debug(new StringBuffer(logToken).append("Executing query: ").append(SQL_QUERY_STATE_STMT));
					
	                rs = stmt.executeQuery();
	               
		            if (rs.next()){		  
			            	 employee.setEmployeeState(rs.getString(1));
			            	 
			         } else {//no result set found
			        		 LOGGER.debug(new StringBuffer(logToken).append("No match found for employeeID").append(employeeID.substring(employeeID.length()-3,employeeID.length())));		
			        		 rcb = false;
		             }

					} else {  //connection=null
			        		 LOGGER.error(new StringBuffer(logToken).append("No connection created to DB"));
			        		 throw new DAOException("Failed to connect to DB");
			        	 }
			        	
				 }catch(Exception e){	//Problem encountered getting query results
					 LOGGER.error(new StringBuffer(logToken).append("Exception encountered in query: ").append(SQL_QUERY_STATE_STMT));
					 LOGGER.error(new StringBuffer(logToken).append(" - Exception:").append(e.getMessage()));
					 throw new DAOException (e.getMessage());
					 
				 }finally{
					 releaseResource(conn, stmt, rs, sessionid);		 
				 }
			
		return rcb;
		}					
}

