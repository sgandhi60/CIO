/* History
 * 11/6/2010 FSW: Initial creation 
 * 11/10/2010 FSW: Only one row will be returned for SQL_QUERY_VACATION_STMT
 * 		so remove processing multiple rows
 * 12/03/2010 FSW: Modify message for DAOException for no DB connection
 * 01/10/2011 FSW: Defect 170295 Remove logging of personal data, defect
 * 				   Also remove any unused variables
 * 
 * 01/24/2011 FSW: Add sessionid to logging.  Defect 170371
 * 01/25/2011 FSW: Add query timeout.  Defect 170321
 */ 
package com.ibm.ivr.cvs.dao;

import com.ibm.ivr.cvs.dao.BaseDAO;
import com.ibm.ivr.cvs.data.Employee;

//import java.io.PrintWriter;
//import java.sql.CallableStatement;
import java.sql.Connection;
//import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

//import java.sql.Types;
import org.apache.log4j.Logger;


	public class VacationDAO extends BaseDAO{
		
	private final static Logger LOGGER = Logger.getLogger(VacationDAO.class);
	

	//private Connection conn = null; Defect 170481, move to methods
	private String jndiName = null;
	
	private String currentYear = null;
	private String planBeginDate = null;
	private String planEndDate = null;
	private final static int MAX_ROWS = 5;
	
	private final static String SQL_QUERY_YEAR = "SELECT TO_CHAR(SYSDATE,'YYYY') FROM DUAL";
	
	private static String SQL_QUERY_VACATION_STMT = "SELECT CLA.HRS_TAKEN_YTD, CLA.C_ANN_ALLOC_HRS, " +
			"CLA.HRS_TAKEN_UNPROC, CLA.HRS_EARNED_YTD " +
			"FROM PS_C_LEAVE_ACCRUAL CLA " +
			"WHERE CLA.EMPLID = ? AND CLA.EMPL_RCD = 0 " +
			"AND CLA.PLAN_TYPE IN ('51','5Z') " +
			"AND CLA.ACCRUAL_PROC_DT = (SELECT MAX(CLA1.ACCRUAL_PROC_DT) " +
			"FROM PS_C_LEAVE_ACCRUAL CLA1 " +
			"WHERE CLA1.EMPLID = CLA.EMPLID " +
			"AND CLA1.EMPL_RCD = CLA.EMPL_RCD " +
			"AND CLA1.PLAN_TYPE IN ('51','5Z') " +
			"AND CLA1.ACCRUAL_PROC_DT >= TO_DATE('planBeginDate','MM/DD/YYYY') " +
			"AND CLA1.ACCRUAL_PROC_DT <= TO_DATE('planEndDate','MM/DD/YYYY'))";
	
	private final static String SQL_QUERY_UNPROC2 = "SELECT HRS_TAKEN_UNPROC " +
			"FROM PS_LEAVE_ACCRUAL " +
			"WHERE EMPLID = ? AND EMPL_RCD = 0 AND PLAN_TYPE IN('51','5Z') " +
			"AND ACCRUAL_PROC_DT IS NULL";  
	
	private int sqlTimeout = 0;  //timeout for stmt execution in secs

	/********************************************************************************
	* Constructor
	/********************************************************************************/	
	public VacationDAO (String jndiName, int timeout) {
		// initialization
		this.jndiName = jndiName;
		this.sqlTimeout= timeout;
		
		LOGGER.debug(new StringBuffer("********Created VaccationDAO ********"));
		LOGGER.debug(new StringBuffer("-- jndiName = ").append(jndiName));
	}

	/********************************************************************************
	* Get Employee Vacation
	/********************************************************************************/
	public boolean getVacation(Employee employeeData, String sessionid)throws DAOException {
		
		Connection conn = null;
		String employeeId = employeeData.employeeID;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String currentQuery = null;
		boolean rcb = true;
		Float takenHours = new Float(0.0);
		Float usedHours = new Float(0.0);
		Float allocatedHours = new Float(0.0);
		Float earnedHours = new Float(0.0) ;
		Float unprocHours = new Float(0.0);
		
		String logToken = new StringBuffer("[").append(sessionid).append("] ").toString();
		
		LOGGER.debug(new StringBuffer(logToken).append("********Entering VacationDAO::getVacation********"));
		LOGGER.debug(new StringBuffer(logToken).append(" -- emplid = ").append(employeeId.substring(employeeId.length()-3,employeeId.length())));
		 
		//Connect to the DB	
		try {
			conn = getConnection(jndiName, sessionid);
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer(logToken).append("Exception getting a connection to the DB: ").append(e.getMessage()));
			throw new DAOException("Failed to connect to DB");
		}
		//get information
		try {			
			if (conn!=null){				
				LOGGER.debug(new StringBuffer(logToken).append("connection successful, querying data"));
						
				// get current year
				currentQuery = SQL_QUERY_YEAR;
				stmt = conn.prepareStatement(currentQuery);
				stmt.setQueryTimeout(sqlTimeout);
				
				LOGGER.debug(new StringBuffer(logToken).append("Executing query: ").append(currentQuery));
				rs = stmt.executeQuery();
				
	            if (rs.next()){
		        	 if (rs.getString(1)!=null) {
		            	 currentYear = rs.getString(1);
		            	 planBeginDate = (new StringBuffer().append("01/01/").append(currentYear)).toString();
		            	 planEndDate =   (new StringBuffer().append("12/31/").append(currentYear)).toString();
		            	 	            	             	 
		        	 } else { // empty record
			        		 LOGGER.error(new StringBuffer(logToken).append("Error in getting current year - empty record"));
			         }
		         } else{//no result set found
		        	 LOGGER.error(new StringBuffer(logToken).append("Error in getting current year"));
	             }
				
				/*SQL_QUERY_VACATION_STMT = "SELECT CLA.HRS_TAKEN_YTD, CLA.C_ANN_ALLOC_HRS, " +
				"CLA.HRS_TAKEN_UNPROC, CLA.HRS_EARNED_YTD " +
				"FROM PS_C_LEAVE_ACCRUAL CLA " +
				"WHERE CLA.EMPLID = ? AND CLA.EMPL_RCD = 0 " +
				"AND CLA.PLAN_TYPE IN ('51','5Z') " +
				"AND CLA.ACCRUAL_PROC_DT = (SELECT MAX(CLA1.ACCRUAL_PROC_DT) " +
				"FROM PS_C_LEAVE_ACCRUAL CLA1 " +
				"WHERE CLA1.EMPLID = CLA.EMPLID " +
				"AND CLA1.EMPL_RCD = CLA.EMPL_RCD " +
				"AND CLA1.PLAN_TYPE IN ('51','5Z'') " +
				"AND CLA1.ACCRUAL_PROC_DT >= TO_DATE(planBeginDate,'MM/DD/YYYY') " +
				"AND CLA1.ACCRUAL_PROC_DT <= TO_DATE(planEndDate,'MM/DD/YYYY'));";
				*/
	            
	            String tempSQL = SQL_QUERY_VACATION_STMT.replace("planBeginDate", planBeginDate);
	            String finalSQL = tempSQL.replace("planEndDate", planEndDate);
	            
				stmt = conn.prepareStatement(finalSQL);	
				stmt.setQueryTimeout(sqlTimeout);
				stmt.setString(1,employeeId);
				
				currentQuery = finalSQL;
				stmt.setMaxRows(MAX_ROWS);
				LOGGER.debug(new StringBuffer(logToken).append("Executing query: ").append(currentQuery));
                rs = stmt.executeQuery();
	             
	            if (rs.next()){
	            	 // first row
		        	takenHours = rs.getFloat(1);
		        	allocatedHours = rs.getFloat(2);
		        	unprocHours = rs.getFloat(3);
		        	earnedHours = rs.getFloat(4);
		        		 
		        	// get additional unproc hours
		        	/*"SELECT HRS_TAKEN_UNPROC " +
					"FROM PS_LEAVE_ACCRUAL " +
					"WHERE EMPLID = ? AND EMPL_RCD = 0 AND PLAN_TYPE IN('51','5Z') " +
					"AND ACCRUAL_PROC_DT IS NULL";  
					*/
					currentQuery = SQL_QUERY_UNPROC2 ;
		 			stmt = conn.prepareStatement(currentQuery);	
		 			stmt.setQueryTimeout(sqlTimeout);
					stmt.setString(1,employeeId);					

					LOGGER.debug(new StringBuffer(logToken).append("Executing query: ").append(currentQuery));
					rs = stmt.executeQuery();
				       while (rs.next()) {
				       		unprocHours = unprocHours + rs.getFloat(1);
				       }
				       
		        	// total up hours taken 
				       usedHours = takenHours + unprocHours;
				       
				    // set employeeData
		        	employeeData.vacUsedHours = VacationDAO.trim(usedHours.toString());
		            employeeData.vacAllocatedHours = VacationDAO.trim(allocatedHours.toString());
		            employeeData.vacEarnedHours = VacationDAO.trim(earnedHours.toString());
		            	 	            	 	            	             	 
		         } else {//no result set found
		        	 LOGGER.error(new StringBuffer(logToken).append("No record found for employeeId = ").append(employeeId.substring(employeeId.length()-3,employeeId.length())));
		        	 rcb = false;
	             }

				} else {  //connection=null
		        	LOGGER.error(new StringBuffer(logToken).append("No connection made to DB"));
		        	throw new DAOException("Failed to connect to DB");
				}
			 }catch(Exception e){ //Problem encountered getting query results
				 LOGGER.error(new StringBuffer(logToken).append("Exception encountered in query: "));
				 LOGGER.debug(new StringBuffer(currentQuery));
				 LOGGER.error(new StringBuffer(logToken).append(" - Exception:").append(e.getMessage()));
				 throw new DAOException(e.getMessage());
				
			 }finally{
				 releaseResource(conn, stmt, rs, sessionid);		 
			 }

		return rcb;
	
	}
	
	private static String trim(String hours) {
		int i = 0;
		int j = 0;
		
		i = hours.indexOf(".");
		if (i != 0){
			j = hours.length() - 1;
			while(j > i) {
				if (hours.lastIndexOf("0") == (j)){
					hours = new String(hours.substring(0,j));
					j--;
				} else {
					break;
				}
			}
			if (j==i) { //remove decimal point
				hours = new String (hours.substring(0,j));
			}
		}
	return hours;
	}
}
