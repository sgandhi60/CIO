package com.ibm.ivr.cvs.handler;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;
import java.util.TimeZone;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.ibm.ivr.cvs.data.Employee;

public class LOASaveRecording extends HttpServlet implements Servlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1125851527276945450L;
	private static Logger LOGGER = Logger.getLogger(LOASaveRecording.class);
	private static String PATH_SEPARATOR = "//";
	/**
     * @see HttpServlet#HttpServlet()
     */
    public LOASaveRecording() {
        super();
        // TODO Auto-generated constructor stub
    }

	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		// get session from Servlet request, created if not existed yet
		HttpSession session = req.getSession(true);
		String callid = (String) session.getAttribute("callid");
		boolean testCall = ((Boolean) session.getAttribute("testCall")).booleanValue();

		//create the log Token for later use, use StringBuffer to reduce number
		// of String objects
		String logToken = new StringBuffer("[").append(callid).append("] ").toString();
			 
		 if (testCall)
		 	LOGGER.debug(new StringBuffer(logToken).append("Entering Handler: LOASaveRecording::"));
		 
		 String hRC = "S";
		 String partialEmpId = null;
		 Employee employee = (Employee) session.getAttribute("employee");
		 String loaRcdFlag  = (String) session.getAttribute("loaRcdFlag");
		 StringBuffer loaRecordingFilePathAndName = null;
		 StringBuffer loaRecordingFilePathAndNameForLogging = null;
		 byte[] recording = (byte[]) req.getAttribute("recording");
		 Properties globalProp = (Properties) session.getServletContext().getAttribute("globalProp");
		 Properties  cvsProp =  (Properties) session.getServletContext().getAttribute("cvsProp");
		 String loaExpectedLastDay = (String) session.getAttribute("loaExpectedLastDay");
		 String intrimEmailSolution = cvsProp.getProperty("intrimEmailSolution");

		 
		 // Save the recorded audio form the caller
	      try
	       {
	    	  //  Need to build the file name here
	    	  // 
	    	  //    Sample File Name     LOARecording_1234567_12152010-105259.wav 
	    	  //
	    	  
	  		Date todaysDate = new java.util.Date();
			SimpleDateFormat formatter = new SimpleDateFormat("MMddyyyy-HHmmss");
			
			String timeZone = ((Properties)session.getServletContext().getAttribute("globalProp")).getProperty("timeZone");
			TimeZone tz = TimeZone.getTimeZone(timeZone == null ? "" : timeZone);
			formatter.setTimeZone(tz);
			
			//get TODAY session var to represent today's date (this is set by the framework in EntryPointServlet)
			String dateDir = (String)session.getAttribute("TODAY");
			
			//set the directory to save the recording
			Calendar calNow = Calendar.getInstance(tz);
			int currentHour = calNow.get(Calendar.HOUR_OF_DAY);
			int timeDir = 1;
			if (currentHour >= 8)
				timeDir++;
			if (currentHour >= 13)
				timeDir++;
			
			StringBuffer path = new StringBuffer().append(PATH_SEPARATOR).append(dateDir).append(PATH_SEPARATOR).append(timeDir).append(PATH_SEPARATOR);
			
			try{
				String dir = new StringBuffer(cvsProp.getProperty("LOARecordingRoot").trim()).append(path).toString();
				File dirFile = new File(dir);
				if (!dirFile.isDirectory())
					dirFile.mkdirs();
					
			} catch (Exception e) {
				LOGGER.error(new StringBuffer(logToken).append("Unable to create dir (" + path + ") for audio recording files: " + e.getMessage()));
				hRC = "E";
	            return;
			}
		
		
			// Construct masked file name for debug logging to protect employee ID
			if (testCall){
				if (employee.getEmployeeID().length() >= 7){
					String maskedEmpId = "****"+employee.getEmployeeID().substring(4);
					// Construct the file name to hold the recording
					loaRecordingFilePathAndNameForLogging = (new StringBuffer(cvsProp.getProperty("LOARecordingRoot").trim())
																	  .append(path)
			    	                                                  .append(cvsProp.getProperty("LOAFixedPortion"))
		                                                              .append(maskedEmpId)
		                                                              .append("_")
		                                                              .append(formatter.format(todaysDate))
		                                                              .append(".wav"));

				}else{
					loaRecordingFilePathAndNameForLogging = (new StringBuffer(cvsProp.getProperty("LOARecordingRoot").trim())
					.append(path)
                    .append(cvsProp.getProperty("LOAFixedPortion"))
                    .append("*******")
                    .append("_")
                    .append(formatter.format(todaysDate))
                    .append(".wav"));
				}
			}
	    	  
			// Construct the file name to hold the recording
			if (intrimEmailSolution != null && intrimEmailSolution.equalsIgnoreCase("on"))
				loaRecordingFilePathAndName = (new StringBuffer(cvsProp.getProperty("LOARecordingRoot").trim())
				 	.append(path)
                	.append(cvsProp.getProperty("LOAFixedPortion"))
                	.append(employee.getEmployeeID())
                	.append("_")
                	.append(formatter.format(todaysDate))
                	.append("_")
                	.append("LOA"+loaRcdFlag+"$#"+employee.getEmployeeID())
                	.append("_")
                	.append(loaExpectedLastDay.substring(0, 2)+"#"+loaExpectedLastDay.substring(2, 4)+"#"+loaExpectedLastDay.substring(4))
                	.append(".wav"));
			else
				loaRecordingFilePathAndName = (new StringBuffer(cvsProp.getProperty("LOARecordingRoot").trim())
				 											  .append(path)
	    	                                                  .append(cvsProp.getProperty("LOAFixedPortion"))
                                                              .append(employee.getEmployeeID())
                                                              .append("_")
                                                              .append(formatter.format(todaysDate))
                                                              .append(".wav"));
	    	  
	    	 File f = new File(loaRecordingFilePathAndName.toString());
	           
	 		 FileOutputStream fos = new FileOutputStream(f);
			/*
			* To write byte array to a file, use
			* void write(byte[] bArray) method of Java FileOutputStream class.
			*
			* This method writes given byte array to a file.
			*/
	          fos.write(recording);
			/*
			* Close FileOutputStream using,
			* void close() method of Java FileOutputStream class.
			* 
			*/ 
	        fos.flush();
	        fos.close(); 
	        
	        // Logic to help verify the stored audio recording has a valid length of more than zero bytes
			File fchk = new File(loaRecordingFilePathAndName.toString());
			LOGGER.info(new StringBuffer(logToken).append("File Name:")
					                               .append(loaRecordingFilePathAndName.toString())
					                               .append("  Byte Array Size:")
					                               .append(recording.length)
					                               .append("  File Size on Disk:")
					                               .append(fchk.length()));


            //  03-08-2011  DEBUG Logic
			// Debugging logic to force the re-recording of the LOA message.  The following property should 
			// not exist in production.  Only in SB when testing the logic to force a re-prompt.
			// The only logic difference between the sections of code is the DEBUG section bases the decision
			// making on the test session variable LOARerecordDebugFlag.   The following section bases the 
			// logic decision first on if 0 bytes is detected.
			
			String LOAzeroLengthCheck = null;			
			String LOARerecordDebugFlag = cvsProp.getProperty("LOARerecordDebugFlag");
			
			if (LOARerecordDebugFlag != null && LOARerecordDebugFlag.trim().equals("XYZ123ABC")){
				LOAzeroLengthCheck = (String) session.getAttribute("LOAzeroLengthCheck");
				if (LOAzeroLengthCheck == null){
					//if (!fchk.delete()){
						//LOGGER.error(new StringBuffer(logToken).append("DEBUG:: LOA Failed (1) to remove file :")
	                            //.append(loaRecordingFilePathAndName.toString()));	
					//}
					session.setAttribute("LOAzeroLengthCheck", "true");
					hRC = "R";
					session.setAttribute("hRC", hRC);
					LOGGER.info(new StringBuffer(logToken).append("DEBUG:: LOA Prepare for re-prompt removed file :")
                            .append(loaRecordingFilePathAndName.toString())
                            .append("  hRC:")
                            .append(hRC));
					return;
				}else{
					//if (!fchk.delete()){
						//LOGGER.error(new StringBuffer(logToken).append("DEBUG:: LOA Failed (2) to remove file :")
	                            //.append(loaRecordingFilePathAndName.toString()));	
					//}
					
					LOGGER.info(new StringBuffer(logToken).append("DEBUG:: LOA Second recording attempt resulted in 0 bytes. Transfer Call"));					
					hRC = "E";
					session.setAttribute("hRC", hRC);
                    return;
				}
			}
			
             //  03-08-2011   Production Logic
 			 //  Adding in check for 0 bytes in the array or the files size.  If either are 0 then
			 //  remove the file and return to the XML  "R" for a re-prompt.   If this is the 
			 //  2nd time thru the logic and 0 is encountered then don't re-prompt.  Process the 
			 //  E-mail attaching the 0 byte file. 
			
			if (fchk.length() == 0 || recording.length == 0){
				LOAzeroLengthCheck = (String) session.getAttribute("LOAzeroLengthCheck");
				if (LOAzeroLengthCheck == null){
					//if (!fchk.delete()){
						//LOGGER.error(new StringBuffer(logToken).append("LOA Failed (1) to remove file :")
	                            //.append(loaRecordingFilePathAndName.toString()));	
					//}
					session.setAttribute("LOAzeroLengthCheck", "true");
					hRC = "R";
					session.setAttribute("hRC", hRC);
					LOGGER.info(new StringBuffer(logToken).append("LOA Prepare for re-prompt removed file :")
                            .append(loaRecordingFilePathAndName.toString())
                            .append("  hRC:")
                            .append(hRC));
					return;
				}else{
					//if (!fchk.delete()){
						//LOGGER.error(new StringBuffer(logToken).append("LOA Failed (2) to remove file :")
	                            //.append(loaRecordingFilePathAndName.toString()));	
					//}
					
					LOGGER.info(new StringBuffer(logToken).append("LOA Second recording attempt resulted in 0 bytes. Transfer Call"));					
					hRC = "E";
					session.setAttribute("hRC", hRC);
                    return;
				}
			}
			
			
	     }catch(FileNotFoundException ex){
	    	 LOGGER.error(new StringBuffer(logToken).append("LOASaveRecording Exception ex::")
	    			                                .append(ex));
	    	 hRC = "E";
	    	 return;
	     }catch(IOException ioe){
	    	 LOGGER.error(new StringBuffer(logToken).append("LOASaveRecording Exception ioe::")
                                                    .append(ioe));
	    	 hRC = "E";
	    	 return;
	     }
		 
	     boolean sendMailResult = false;
	     if (intrimEmailSolution == null || !intrimEmailSolution.equalsIgnoreCase("on")) {
	         // Send the notification E-mail regarding the recording
		     String loaFrom = cvsProp.getProperty("LOAFrom").trim();
		     String loaTo   = cvsProp.getProperty("LOATo").trim();
		     String loaMailHost   = globalProp.getProperty("SMTP").trim();
		     LOASaveRecording sendLoaMail = new LOASaveRecording();
		     
		     // Build Subject    Sample Subject     LOAPLR: 0751768
		     String loaSubject = "LOA"+loaRcdFlag+": "+employee.getEmployeeID();
		     // Build Start Date of LOA
		     String loaMailBodyDate = loaExpectedLastDay.substring(0, 2)+"/"+loaExpectedLastDay.substring(2, 4)+"/"+loaExpectedLastDay.substring(4)+"  ";
		     // Build mail body text
		     String mailBodyText = "START DATE: "+loaMailBodyDate;
	
			 if (testCall){
				 	LOGGER.debug(new StringBuffer(logToken).append("About to send LOA Mail::")
				 			                               .append(" From::")
				 			                               .append(loaFrom)
				 			                               .append("  loaTo::")
				 			                               .append(loaTo)
				 			                               .append("  loaSubject:")
				 			                               .append(loaSubject)
				 			                               .append("  mailBodyText::")
				 			                               .append(mailBodyText)
				 			                               .append("  loaMailHost::")
				 			                               .append(loaMailHost)
				 			                               .append("  loaRecordingFilePathAndNameForLogging::")
				 			                               .append(loaRecordingFilePathAndNameForLogging));
			 }
			 
		     // Build and send LOA reason mail
		     sendMailResult =   sendLoaMail.sendLOAEmail(loaFrom, loaTo, loaSubject, mailBodyText, loaMailHost, loaRecordingFilePathAndName, loaRecordingFilePathAndNameForLogging);
		     if (!sendMailResult){
		    	LOGGER.error(new StringBuffer(logToken).append("Error sending LOA mail::"));
	            hRC = "E";
	            return;
	         }
	     }
	     
		 if (testCall){
			 	LOGGER.debug(new StringBuffer(logToken).append("Exiting Handler: LOASaveRecording::")
			 			                               .append(loaRecordingFilePathAndNameForLogging)
			 			                               .append("  hRC::")
			 			                               .append(hRC)
			 			                               .append("  sendMailResult::")
			 			                               .append(sendMailResult));
		 }
 
      session.setAttribute("hRC", hRC);
		 
	  return;		 
	}
	

	/**
	 * Send email with body and/or attachment
	 * textFile will be used only if text is null
	 * 
	 * @param from		   the sender of the email
	 * @param to		   the receipient of the email
	 * @param subject	   the subject of the email
	 * @param text		   the text body of the email
	 * @param mailHost     the SNMP host target takrn from global properties
	 * @param attachFile   the file to be attached to the email
	 * @retun			   true if succeeded, false otherwise
	 */
	public boolean sendLOAEmail(String from, String to, String subject, String text, String mailHost, StringBuffer attachFile, StringBuffer attachFileLogging) {

	       String mailer = "msgsend";
	       boolean debug = false;

	       try {

	              Properties props = System.getProperties();
	              // XXX - could use Session.getTransport() and Transport.connect()
	              // XXX - assume we're using SMTP
                  props.put("mail.smtp.host", mailHost);

	              // Get a Session object
	              Session session = Session.getDefaultInstance(props, null);
	              if (debug)
	                     session.setDebug(true);

	              // construct the message
	              Message msg = new MimeMessage(session);
                  msg.setFrom(new InternetAddress(from));

	              msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to, false));

	              msg.setSubject(subject);

	              msg.setHeader("Content-Type", "multipart/mixed");
	              
	              Multipart multipart = new MimeMultipart(); 
	              
	              
	            // Set the test body portion of the E-mail
               	BodyPart messageBodyPart = new MimeBodyPart(); 
              	messageBodyPart.setText(text + "\n\t\t");
              	messageBodyPart.setHeader("Content-Type", "text/plain");
              	multipart.addBodyPart(messageBodyPart); 
              
              	// Attach the audio file that was captured
              	BodyPart messageBodyPart2 = new MimeBodyPart();
                DataSource source = new FileDataSource(attachFile.toString()); 
              	messageBodyPart2.setDataHandler(new DataHandler(source)); 
              	messageBodyPart2.setFileName(source.getName()); 
              	multipart.addBodyPart(messageBodyPart2); 
	              
	            msg.setContent(multipart); 
	            msg.setHeader("X-Mailer", mailer);
	            msg.setSentDate(new Date());

	            // send the thing off
	            Transport.send(msg);
	              
	            return true;

	       } catch (Exception e) {
	              LOGGER.error("Failed to send email::"+ attachFileLogging +"::" + e.getMessage(), e);
	              e.printStackTrace();
	              return false;
	       }
	}
	
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request,response);
	}
}

