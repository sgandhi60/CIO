package com.ibm.ivr.cvs.handler;

import java.io.IOException;
import java.util.Properties;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.ibm.ivr.cvs.dao.DAOException;
import com.ibm.ivr.cvs.dao.PaycheckDAO;
import com.ibm.ivr.cvs.data.Employee;
import com.ibm.ivr.framework.utilities.Common;

/**
 * Get current pay check information
 * Input: employee (from session) 
 * Output: 
 * 		  employee object paycheck fields updated (into session) 
 * 		  paycheckDatesMatched String object in the session
 * 		  corporateEmployee String object in the session
 * 		  paycheckCodeCount Integer object in the session
 * 		  paycheckCodeSubtotalCount Integer object in the session
 *
 *Revision history:
 * <p>
 * 
 * 2010-10-25: initial version
 * <p>
 * 
 * @author Fang Wang
 * @version 2010-10-25
 * 05/17/2011 FSW: Defect 170553, change check for corporate employee (if numeric not
 * 				corporate (previously checked if > 09999)
 * 05/22/2011 FSW: Change to defect 170553, Need to check 'location' not 'deptid'
 *
 */
public class GetCurrentPayCheck extends HttpServlet implements Servlet{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3850082831107829738L;
	
	private static Logger LOGGER = Logger.getLogger(GetCurrentPayCheck.class);

	public void doGet(HttpServletRequest req, HttpServletResponse resp)
							throws ServletException, IOException {

	// get session from Servlet request, created if not existed yet
	HttpSession session = req.getSession(true);
	//Properties prop = (Properties)session.getServletContext().getAttribute("globalProp");

	String callid = (String) session.getAttribute("callid");

	boolean testCall = ((Boolean) session.getAttribute("testCall")).booleanValue();

	//create the log Token for later use, use StringBuffer to reduce number
	// of String objects
	String logToken = new StringBuffer("[").append(callid).append("] ").toString();
		 
	 if (testCall)
	 	LOGGER.debug(new StringBuffer(logToken).append("Entering Handler: GetCurrentPayCheck"));
	
		
    // Get attributes from the session
	Employee employee = (Employee) session.getAttribute("employee");
	session.removeAttribute("payCheckDatesMatched");
	
	if (employee != null){
		//if deptid > 09999, corporate employee
		//170553 start
		/*if (!employee.getDepartmentID().startsWith("0"))
			session.setAttribute("corporateEmployee", Common.TRUE);
		else
			session.setAttribute("corporateEmployee", Common.FALSE);
		*/
		session.setAttribute("corporateEmployee", Common.FALSE);
		//following will throw exception if location is not numeric
		try {
		 Integer.parseInt(employee.getEmployeeLocation());
			
		} catch (NumberFormatException e) {
			session.setAttribute("corporateEmployee", Common.TRUE);
		}
		//170553 End
		
		session.setAttribute("previousCheckIndex", new Integer(0));
		
		//calling payCheckDAO to search
		PaycheckDAO pDAO = (PaycheckDAO) session.getServletContext().getAttribute("paycheckDAO");
		
		int maxRows = Integer.parseInt(((Properties)session.getServletContext().getAttribute("cvsProp")).getProperty("maxPaycheckRows"));
		try {
			if (pDAO.getCalendarPayEndDate(employee, callid) && pDAO.getPayEndDates(employee, maxRows, callid)){
				Object[] dates = employee.getEmpPayEndDates();
				if (dates != null) {
					if (employee.getCalendarPayEndDate().equalsIgnoreCase(dates[0].toString())){
						session.setAttribute("payCheckDatesMatched", Common.TRUE);
						if (pDAO.getChecks(employee, dates[0].toString(), callid)){
							if (employee.getEmpPayAmount() == null){//DB record found but with negative amount
								session.setAttribute("hRC", "E");
							}else{
								employee.setEmpPayEndDate(dates[0].toString());
								session.setAttribute("hRC", "S");
								session.setAttribute("paycheckCodeCount", new Integer(employee.getEmpPayAmount().length));
								session.setAttribute("paycheckCodeSubtotalCount", new Integer(employee.getEmpPayAmountByMsgId().length));

								//170553 Start   - Shailesh
								String[] hourFile = null;
								Object[] hours = employee.getEmpPayHours();
								if (hours != null) {
									hourFile = new String[hours.length];
									for (int i=0; i < hours.length; i++) {
										if (hours[i].toString().equals("1")) {
											hourFile[i] = "hour";
										} else {
											hourFile[i] = "hours";
										}																		
									}
								}
								session.setAttribute("hourFile", hourFile);
								//170553 End
							}
						}
						else
							session.setAttribute("hRC", "E");
					}else{
						session.setAttribute("payCheckDatesMatched", Common.FALSE);
						
						//temporary work around for lacking the data in UAT db
						//session.setAttribute("payCheckDatesMatched", Common.TRUE);
						//if (pDAO.getChecks(employee, dates[0].toString(), callid)){
						//	if (employee.getEmpPayAmount() == null){//DB record found but with negative amount
						//		session.setAttribute("hRC", "E");
						//	}else{
						//		employee.setEmpPayEndDate(dates[0].toString());
						//		session.setAttribute("hRC", "S");
						//		session.setAttribute("paycheckCodeCount", new Integer(employee.getEmpPayAmount().length));
						//		session.setAttribute("paycheckCodeSubtotalCount", new Integer(employee.getEmpPayAmountByMsgId().length));
						//	}
						//}
					}
				}else
					session.setAttribute("hRC", "E");
			}
			else
				session.setAttribute("hRC", "E");
			
			//employee.setEmpPayGroup("ABC");
			//ArrayList<String> amount = new ArrayList<String>();
			//ArrayList<String> msgid = new ArrayList<String>();
			//ArrayList<String> deptid = new ArrayList<String>();
			//amount.add("1000.0");
			//msgid.add("11111");
			//deptid.add("12345");
			//amount.add("2000.0");
			//msgid.add("22222");
			//deptid.add("12345");
			//employee.setEmpPayAmount(amount);
			//employee.setEmpPayCodeMsgId(msgid);
			//employee.setEmpDeptId(deptid);
			
			//session.setAttribute("paycheckCodeCount", new Integer(2));
			
			//ArrayList<String> amount1 = new ArrayList<String>();
			//ArrayList<String> msgid1 = new ArrayList<String>();
			//amount1.add("3000.0");
			//msgid1.add("11111");
			//employee.setEmpPayAmountByMsgId(amount1);
			//employee.setEmpPayCodeMsgIdUnique(msgid1);
			
			//session.setAttribute("paycheckCodeSubtotalCount", new Integer(1));
			
			//employee.setEmpNetPayAmount("2500.0");
						
		}catch(DAOException e){
			LOGGER.info(new StringBuffer(logToken).append("failed to get pay check: ").append(e.getMessage()));
		     if (e.getMessage() != null && e.getMessage().equalsIgnoreCase("Failed to connect to DB"))
		    	 session.setAttribute("hRC", "C");
		     else
		    	 session.setAttribute("hRC", "E");			
		}
	}
	else {
		LOGGER.warn(new StringBuffer(logToken).append("no employee object in the session"));
		session.setAttribute("hRC", "E");
	}
   return;
  }
}
