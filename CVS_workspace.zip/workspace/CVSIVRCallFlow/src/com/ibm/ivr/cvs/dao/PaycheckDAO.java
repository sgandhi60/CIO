/* History
 * 10/28/2010 FSW: Initial creation 
 * 11/05/2010 FSW: Made the following changes per email from Alanna 
 * Date:	11/05/2010 08:53 AM
 * Subject:	Re: Net payroll amount
 *    If there are multiple matches, no net pay is spoken. If only one record, 
 *    we will skip if it is positive value. If it is negative value, we will play 
 *    with minus sign stripped off. 
 *    
 *    ...negative MONETARY_AMOUNT in the C_PAY_TO_GL table means a positive pay 
 *    check to the employee.  A positive MONETARY_AMOUNT in the C_PAY_TO_GL table means 
 *    a negative pay check to the employee.
 *    ...
 *    So yes, the logic you were given above in blue, makes sense to me if you are using
 *    the C_PAY_TO_GL table to get your data.
 * --------------------------------------------------------------------------------
 * 11/05/2010 FSW: Made the following changes per email from
 * For regular pay (not NET) skip readback if any monetary_amount or oth_hrs is negative
 * From:	"Channell, Dewain" <Dewain.Channell@nuance.com>
 * Date:	11/03/2010 04:00 PM
 * Subject: RE: question on the payroll callflow
 * Exceptions as I see in appl: 
 *           No records found on DB queries 
 *           Negative Amounts  ( any one amount is negative? ) 
 * [DSC - ] I have to assume Yes, as this logic has been in place before I took over
 * -------------------------------------------------------------------------------
 * 11/08/2010 FSW: Made the following changes per emails Fang/
 * Channell, Dewain
 * Subject: RE: question on the payroll callflow
 * 
 * Frankie, 
 *
 * Can you add logic in the DAO that if any of the monetary amount or the OTH_HOURS is negative,
 * set the arraylist as null? My XML code will detect the null and skip the play of the paycheck. 
 * 
 * 12/03/2010 FSW: Modify message for DAOException for no DB connection
 * 01/10/2011 FSW: Defect 170295 Remove logging of personal data, defect
 * 				   Also remove any unused variables
 * 01/20/2011 FSW: Defect 170361.  Change converting otherHours/amount strings to Float
 * 
 * 01/24/2011 FSW: Add sessionid to logging.  Defect 170371
 * 01/24/2011 FSW: 170370 trim blanks from paygroup returned from DB.
 * 01/25/2011 FSW: Add query timeout.  Defect 170321
 * 02/01/2011 FW: added rollup logic on the paycheck amount. Defect 170399
 * 02/22/2011 FW: move connection definition from class to methods Defect 170481
 * 02/23/2011 FW: change logging from debug to info for neg am't or oth_hrs in getChecks. Defect 170482
 * 03/01/2011 FW: 170494: Prepend '0' to payroll amounts less than $1.00.  Return false if value is null
 * 05/17/2011 FSW: Defect 170553, put hours by store into Employee class for saying back to caller 
 *
 */

package com.ibm.ivr.cvs.dao;

import com.ibm.ivr.cvs.dao.BaseDAO;
import com.ibm.ivr.cvs.data.Employee;

import java.sql.Connection;
//import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
//import java.sql.Date;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Set;

//import java.sql.Types;
import org.apache.log4j.Logger;


	public class PaycheckDAO extends BaseDAO{
		
	private final static Logger LOGGER = Logger.getLogger(PaycheckDAO.class);
	

	//private Connection conn = null; Defect 170481, move to methods
	private String jndiName = null;
	
	private static String SQL_QUERY_PAYGROUP = "SELECT COMPANY, PAYGROUP " +
			"FROM SYSADM.PS_C_PAY_TO_GL " +
			"WHERE EMPLID = ? " +
			"ORDER BY PAY_END_DT DESC";

	private final static String SQL_QUERY_CALPAYEND = "SELECT PAY_END_DT," +
			"TO_CHAR(PAY_END_DT,'MMDDYYYY') " +
			"FROM SYSADM.PS_PAY_CALENDAR " +
			"WHERE PAY_CONFIRM_RUN = 'Y' AND " +
			"PAY_OFF_CYCLE_CAL = 'N' AND COMPANY = ? AND PAYGROUP = ? " +
			"ORDER BY PAY_END_DT DESC";
	
	private final static String SQL_QUERY_PAYENDDATE = "SELECT UNIQUE(PAY_END_DT), " +
			"TO_CHAR(PAY_END_DT,'MMDDYYYY') " +
			"FROM SYSADM.PS_C_PAY_TO_GL " +
			"WHERE EMPLID = ? " +
			"ORDER BY PAY_END_DT DESC";
	
	private final static String SQL_QUERY_GETCHECK1 = "SELECT C_PAY_CODE, C_DEPTID_CHRG, " +
			"OTH_HRS, MONETARY_AMOUNT " +
			"FROM SYSADM.PS_C_PAY_TO_GL " +
			"WHERE C_PAY_DESCR = 'E' AND EMPLID = ? " +
			"AND  to_char(PAY_END_DT, 'MMDDYYYY') = ? " +
			"ORDER BY OTH_HRS DESC";
	
	private final static String SQL_QUERY_GETCHECK2 = "SELECT EARN_CD, MSG_NBR " +
			"FROM IVR_O.EARN_CODE_IVR_MESSAGES " +
			"WHERE EARN_CD = ? " +
			"ORDER BY MSG_NBR";
	
	private final static String SQL_QUERY_GETCHECK3 = "SELECT MONETARY_AMOUNT " +
			"FROM SYSADM.PS_C_PAY_TO_GL " +
			"WHERE EMPLID = ? " +
			"AND to_char(PAY_END_DT, 'MMDDYYYY') = ? " +
			"AND C_PAY_DESCR = 'N' AND C_PAY_CODE = 'NET'";

	//Removed getting column STORE_NBR in query below, reformat date
	private final static String SQL_QUERY_CHECK_DELIVERY = "SELECT TO_CHAR(PAYCHK_DT_TME,'MMDDYYYY'), " +
			"UPS_TRACKING_CD, REDIRECT_TO_TXT " +
			"FROM IVR_O.STORE_PAYCHECK_DELIVERY " +
			"WHERE STORE_NBR = ?";
	
	private int sqlTimeout = 0;  //timeout for stmt execution in secs
	
	/********************************************************************************
	* Constructor
	/********************************************************************************/		
	public PaycheckDAO (String jndiName, int timeout) {
		// initialization";
		this.jndiName = jndiName;
		this.sqlTimeout = timeout;
	
		LOGGER.debug(new StringBuffer("******** Created PaycheckDAO ********"));
		LOGGER.debug(new StringBuffer("-- jndiName = ").append(jndiName));
	}

	/********************************************************************************
	* Get Calendar End Date
	/********************************************************************************/
	public boolean getCalendarPayEndDate(Employee employeeData, String sessionid)throws DAOException {
		
		Connection conn = null;
		String employeeId = employeeData.employeeID;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String currentQuery = null;
		String company = null;
		boolean rcb = true;
		
		String logToken = new StringBuffer("[").append(sessionid).append("] ").toString();
		LOGGER.debug(new StringBuffer(logToken).append("********Entering PaycheckDAO::getCalendarPayEndDate********"));
		LOGGER.debug(new StringBuffer(logToken).append(" -- emplid = ").append(employeeId.substring(employeeId.length()-3,employeeId.length())));;
		
		//clear out any previous data
		employeeData.setEmpPayGroup(null);
		employeeData.setCalendarPayEndDate(null);
		employeeData.setEmpPayEndDates(null);
		employeeData.setEmpPayCodeMsgIdUnique(null);
		employeeData.setEmpPayAmountByMsgId(null);
				
		//Connect to the DB	
		try {
			conn = getConnection(jndiName, sessionid);
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer(logToken).append("Exception getting a connection to the DB: ").append(e.getMessage()));
			throw new DAOException("Failed to connect to DB");
		}
		//get information
		try {			
			if (conn!=null){				
				LOGGER.debug(new StringBuffer(logToken).append("Connection successful, querying data"));
						
				// get paygroup
				//SELECT COMPANY, PAYGROUP FROM SYSADM.PS_C_PAY_TO_GL WHERE EMPLID = ? 
				//ORDER BY PAY_END_DT DESC
				currentQuery = SQL_QUERY_PAYGROUP;
				stmt = conn.prepareStatement(currentQuery);
				stmt.setQueryTimeout(sqlTimeout);
				stmt.setString(1,employeeId);
				
				LOGGER.debug(new StringBuffer(logToken).append("Executing query: ").append(currentQuery));
				LOGGER.debug(new StringBuffer(logToken).append(" -- EMPLID = ").append(employeeData.employeeID.substring(employeeData.employeeID.length()-3,employeeData.employeeID.length())));
				
				rs = stmt.executeQuery();
				
	            if (rs.next()){
	            	company = new String(rs.getString(1));
	            	//170370 trim blanks from paygroup
		            employeeData.setEmpPayGroup(rs.getString(2).trim());

		         } else{ //no result set found
		        	 LOGGER.error(new StringBuffer(logToken).append("Error in getting company/paygroup - no rows found"));
		        	 rcb = false;
	             }
				
	            if (rcb) {
	            	// get pay end date
	            	//SQL_QUERY_CALPAYEND = "SELECT PAY_END_DT, TO_CHAR(PAY_END_DT,'MMDDYYYY') 
		           	//FROM SYSADM.PS_PAY_CALENDAR 
					//WHERE PAY_CONFIRM_RUN = 'Y' AND 
	            	//PAY_OFF_CYCLE_CAL = 'N' AND COMPANY = ? AND PAYGROUP = ? 
					//ORDER BY PAY_END_DT DESC";
	            	currentQuery = SQL_QUERY_CALPAYEND;
	            	stmt = conn.prepareStatement(currentQuery);	
	            	stmt.setQueryTimeout(sqlTimeout);
	            	stmt.setString(1,company.toString());
	            	stmt.setString(2,employeeData.getEmpPayGroup());
	            	
	            	LOGGER.debug(new StringBuffer(logToken).append("Executing query: ").append(currentQuery));
	            	LOGGER.debug(new StringBuffer(logToken).append(" -- COMPANY = ").append(company));
	            	LOGGER.debug(new StringBuffer(logToken).append(" -- PAYGROUP = ").append(employeeData.getEmpPayGroup()));
	
	            	rs = stmt.executeQuery();
	            	
	            	//save data to employee
	            	if (rs.next()) {
	            		employeeData.setCalendarPayEndDate(rs.getString(2));
		            	 	            	 	            	             	 
	            	} else {//no result set found
	            		LOGGER.error(new StringBuffer(logToken).append("No record found").append(employeeId.substring(employeeId.length()-3,employeeId.length())));
	            		rcb = false;
	            	}
	            }  //no data returned in prereq query don't continue
	 
			} else {  //connection=null
		        	LOGGER.error(new StringBuffer(logToken).append("No connection made to DB"));
		        	throw new DAOException("Failed to connect to DB");
			}
		}catch(Exception e){ //Problem encountered getting query results
			LOGGER.error(new StringBuffer(logToken).append("Exception encountered in query: ").append(currentQuery));
			LOGGER.error(new StringBuffer(logToken).append(" - Exception:").append(e.getMessage()));
			throw new DAOException(e.getMessage());
				
		}finally{
			 releaseResource(conn, stmt, rs, sessionid);		 
		}

		return rcb;
	
	}		
	
	/********************************************************************************
	* Get Pay End Dates
	/********************************************************************************/
	public boolean getPayEndDates(Employee employeeData, int maxRows, String sessionid)throws DAOException {
		
		Connection conn = null;
		String employeeId = employeeData.employeeID;
		ArrayList<String> payDateArray = new ArrayList<String>(maxRows);
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String currentQuery = null;

		boolean rcb = true;
		
		String logToken = new StringBuffer("[").append(sessionid).append("] ").toString();
		
		LOGGER.debug(new StringBuffer(logToken).append("********Entering PaycheckDAO::getPayEndDates********"));
		LOGGER.debug(new StringBuffer(logToken).append(" -- emplid = ").append(employeeId.substring(employeeId.length()-3,employeeId.length())));
		LOGGER.debug(new StringBuffer(logToken).append(" -- maxRows = ").append(maxRows));
		 
		//Connect to the DB	
		try {
			conn = getConnection(jndiName, sessionid);
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer(logToken).append("Exception getting a connection to the DB: ").append(e.getMessage()));
			throw new DAOException("Failed to connect to DB");
		}
		//get information
		try {			
			if (conn!=null){				
				LOGGER.debug(new StringBuffer(logToken).append("connection successful, querying data"));
						
				//SQL_QUERY_PAYENDDATE = "SELECT UNIQUE(PAY_END_DT),TO_CHAR(PAY_END_DATE,'MMDDYYYY')
				//FROM SYSADM.PS_C_PAY_TO_GL 
				//WHERE EMPLID = ?
				//ORDER BY PAY_END_DT DESC;
				
				currentQuery = SQL_QUERY_PAYENDDATE;
				stmt = conn.prepareStatement(currentQuery);
				stmt.setQueryTimeout(sqlTimeout);
				stmt.setString(1,employeeId);
				stmt.setMaxRows(maxRows);
				
				LOGGER.debug(new StringBuffer(logToken).append("Executing query: ").append(currentQuery));
				LOGGER.debug(new StringBuffer(logToken).append(" -- EMPLID = ").append(employeeId.substring(employeeId.length()-3,employeeId.length())));
				LOGGER.debug(new StringBuffer(logToken).append(" -- maxRows = ").append(maxRows));
				
				rs = stmt.executeQuery();
				
				//first row
	            if (rs.next()){       
	            	payDateArray.add(rs.getString(2));
	            	
	            	//remaining rows
	            	while (rs.next()) {
	            		payDateArray.add(rs.getString(2));
	            		
	            	}
	            employeeData.setEmpPayEndDates(payDateArray);

		         } else{ //no result set found
		        	 LOGGER.error(new StringBuffer(logToken).append("Error in getting pay end dates - no rows found"));
		        	 rcb = false;
	             }
				

			} else {  //connection=null
		        	LOGGER.error(new StringBuffer(logToken).append("No connection made to DB"));
		        	throw new DAOException("Failed to connect to DB");
			}
		}catch(Exception e){ //Problem encountered getting query results
			LOGGER.error(new StringBuffer(logToken).append(" - Exception encountered in query: ").append(currentQuery));
			LOGGER.error(new StringBuffer(logToken).append(" - Exception:").append(e.getMessage()));
			throw new DAOException(e.getMessage());
				
		}finally{
			 releaseResource(conn, stmt, rs, sessionid);		 
		}

		return rcb;
	
	}			
	
	/********************************************************************************
	* Get Check Info
	/********************************************************************************/
	public boolean getChecks(Employee employeeData, String payEndDate, String sessionid)throws DAOException {
		
		Connection conn = null;
		String employeeId = employeeData.employeeID;
		ArrayList<String> payAmount = new ArrayList<String>();
		ArrayList<String> payHours =  new ArrayList<String>();
		ArrayList<String> payCodeMsg = new ArrayList<String>();
		ArrayList<String> deptID = new ArrayList<String>();
		ArrayList<String> totalAmtByMsgId = new ArrayList<String>();
		ArrayList<String> totalMsgId = new ArrayList<String>();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		ResultSet rs2 = null;
		Hashtable<String, String> htPayMsg = new Hashtable<String, String>();           // key=paycode, value=msgid,
		LinkedHashMap<String, String> lhmPayAmt = new LinkedHashMap<String, String>();  // key=paycode.deptid value=sum of am'ts, use linked map to maintain order
		LinkedHashMap<String, String> lhmTotMsgAmt = new LinkedHashMap<String, String>(); // key = paycode value=sum of am'ts
		LinkedHashMap<String, String> lhmPayAmtRollup = new LinkedHashMap<String, String>();  // key=msgid.deptid value=sum of am'ts, use linked map to maintain order
		LinkedHashMap<String, String> lhmTotMsgAmtRollup = new LinkedHashMap<String, String>(); // key = msgid value=sum of am'ts
		LinkedHashMap<String, String> lhmHours =  new LinkedHashMap<String, String>();  // key=paycode.deptid value=sum of hours
		LinkedHashMap<String, String> lhmHoursRollup = new LinkedHashMap<String, String>();  // key=msgid.deptid value=sum of other hours, use linked map to maintain order
		String currentQuery = null;
		String pay_code =  null;
		String amount = null;
		String otherHours = null;
		String deptChrg = null;
		String payMsg = null;
		String key1 = null;
		Float  netPay = null;
		boolean found = false;
		boolean negativeFound = false;
		boolean rcb = true;
		
		String logToken = new StringBuffer("[").append(sessionid).append("] ").toString();
		
		LOGGER.debug(new StringBuffer(logToken).append("********Entering PaycheckDAO::getChecks********"));
		LOGGER.debug(new StringBuffer(logToken).append(" -- emplid = ").append(employeeData.employeeID.substring(employeeData.employeeID.length()-3,employeeData.employeeID.length())));
		LOGGER.debug(new StringBuffer(logToken).append(" -- payEndDate = ").append(payEndDate));
		
		//initialize arrays in employee data, in case not first time here
		employeeData.setEmpPayAmount(null);
		employeeData.setEmpPayHours(null);
		employeeData.setEmpPayCodeMsgId(null);
		employeeData.setEmpDeptId(null);
		employeeData.setEmpPayCodeMsgIdUnique(null);
		employeeData.setEmpPayAmountByMsgId(null);
		 
		//Connect to the DB	
		try {
			conn = getConnection(jndiName, sessionid);
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer(logToken).append(" - Exception getting a connection to the DB: ").append(e.getMessage()));
			throw new DAOException("Failed to connect to DB");
		}
		//get information
		try {			
			if (conn!=null){				
				LOGGER.debug(new StringBuffer(logToken).append("connection successful, querying data"));
						
				//SQL_QUERY_GETCHECK1 = "SELECT C_PAY_CODE, C_DEPTID_CHRG, " +
				//"OTH_HRS, MONETARY_AMOUNT " +
				//"FROM SYSADM.PS_C_PAY_TO_GL " +
				//"WHERE C_PAY_DESCR = 'E' AND EMPLID = ? " +
				//"AND  to_char(PAY_END_DT, 'MMDDYYYY') = ? " +
				//"ORDER BY OTH_HRS DESC";
				
				//NOTE: C_DEPTID_CHRG = store number? answer: YES
				
				currentQuery = new String (SQL_QUERY_GETCHECK1);
				stmt = conn.prepareStatement(currentQuery);
				stmt.setQueryTimeout(sqlTimeout);
				stmt.setString(1,employeeId);
				stmt.setString(2,payEndDate);
				
				LOGGER.debug(new StringBuffer(logToken).append("Executing query: ").append(currentQuery));
				LOGGER.debug(new StringBuffer(logToken).append(" -- EMPLID = ").append(employeeId.substring(employeeId.length()-3,employeeId.length())));
				LOGGER.debug(new StringBuffer(logToken).append(" -- PAY_END_DT = ").append(payEndDate));
				
				rs = stmt.executeQuery();
				
				//for each row found above, save total per paycode & store
            	while (rs.next()) {
            		found = true;
            		pay_code = rs.getString(1);
            		deptChrg = rs.getString(2);
            		otherHours = rs.getString(3);
            		amount = rs.getString(4);
            		
            		//if either amount or hours is negative, don't return any values
            		float oh = Float.valueOf(otherHours.trim()).floatValue();
            		float amt = Float.valueOf(amount.trim()).floatValue();
            		if (((int)(amt) < 0) || ((int)(oh) < 0 )) {
            			
            			LOGGER.info(new StringBuffer(logToken).append("AMOUNT or OTH_HRS is negative"));
            			LOGGER.debug(new StringBuffer(logToken).append("AMOUNT = ").append(amount));
            			LOGGER.debug(new StringBuffer(logToken).append("OTH_HRS = ").append(otherHours));
            			
            			negativeFound = true;            			
            			break;			
            		}
            		
            		key1 = new String(pay_code + "." + deptChrg);
            		
            		if (!lhmPayAmt.containsKey(key1)){
            			lhmPayAmt.put(key1, amount);
            		} else {
            			// add new am't to existing amount
            			String savedAmt = lhmPayAmt.get(key1);
            			Float newAmtFloat = (Float.valueOf(savedAmt)) + Float.valueOf(amount);
            			String newAmtStr = newAmtFloat.toString();
            			
            			lhmPayAmt.put(key1,newAmtStr);
            			
            		}
            		//170553 start
               		if (!lhmHours.containsKey(key1)){
            			lhmHours.put(key1, otherHours);
            		} else {
            			// add new hours to existing hours
            			String savedHrs = lhmHours.get(key1);
            			Float newHoursFloat = (Float.valueOf(savedHrs)) + Float.valueOf(otherHours);
            			String newHoursStr = newHoursFloat.toString();
            			
            			lhmHours.put(key1,newHoursStr);
            			
            		}
               		//170553 end
            		
            		// save total per pay code
               		if (!lhmTotMsgAmt.containsKey(pay_code)){
            			lhmTotMsgAmt.put(pay_code, amount);
            			
            		} else {
            			// add new am't to existing amount
            			String savedAmt = lhmTotMsgAmt.get(pay_code);
            			Float newAmtFloat = (Float.valueOf(savedAmt)) + Float.valueOf(amount);
            			String newAmtStr = newAmtFloat.toString();
            			
            			lhmTotMsgAmt.put(pay_code,newAmtStr);
            			
            		}
               		
            		// if new paycode, lookup msg
            		if (!htPayMsg.containsKey(pay_code)) {
            		
            			//SQL_QUERY_GETCHECK2 = "SELECT EARN_CD, MSG_NBR " +
            			//"FROM IVR_O.EARN_CODE_IVR_MESSAGES " +
            			//"WHERE EARN_CD = ? " +
            			//"ORDER BY MSG_NBR";
	            	
            			currentQuery = new String (SQL_QUERY_GETCHECK2);
    					stmt = conn.prepareStatement(currentQuery);
    					stmt.setQueryTimeout(sqlTimeout);
    					stmt.setString(1,pay_code);
	            	
    					LOGGER.debug(new StringBuffer(logToken).append("Executing query: ").append(currentQuery));
    					LOGGER.debug(new StringBuffer(logToken).append(" -- EARN_CODE = ").append(pay_code));
    				
    					rs2 = stmt.executeQuery();
    					if (rs2.next()) {	
    						if (rs2.getString(2) != null) {
    							htPayMsg.put(pay_code, rs2.getString(2));
    						} else {
    							htPayMsg.put(pay_code, "");
    						}
    						
    					} else {
    						LOGGER.info(new StringBuffer(logToken).append("No record found for paycode = ").append(pay_code));
    						htPayMsg.put(pay_code, "");
    						//rcb = false // do we want to stop or just put "" in for msg value.  Decided put in ""
    					}	 
            		}	
            	}
            	
            	if ((found) && (!negativeFound)){
            		//roll up by msg id
                	Set<String> keyset1 = lhmPayAmt.keySet();
            		Iterator<String> it1 = keyset1.iterator();
            		while (it1.hasNext()) {
            			String info = it1.next();
            			int i = info.indexOf(".");
            			pay_code = info.substring(0,i);
            			deptChrg = info.substring(i+1,(info.length()));
            			payMsg = htPayMsg.get(pay_code);
            			amount = lhmPayAmt.get(info);   
            			
            			String key = new String(payMsg + "." + deptChrg);
            			if (!lhmPayAmtRollup.containsKey(key)){
                			lhmPayAmtRollup.put(key, amount);
                		} else {
                			// add new am't to existing amount
                			String savedAmt = lhmPayAmtRollup.get(key);
                			Float newAmtFloat = (Float.valueOf(savedAmt)) + Float.valueOf(amount);
                			String newAmtStr = newAmtFloat.toString();
                			
                			lhmPayAmtRollup.put(key,newAmtStr);
                		}
            		}	
            		//170553
            		//roll up hours by msg id
                	keyset1 = lhmHours.keySet();
                	it1 = keyset1.iterator();
            		while (it1.hasNext()) {
            			String info = it1.next();
            			int i = info.indexOf(".");
            			pay_code = info.substring(0,i);
            			deptChrg = info.substring(i+1,(info.length()));
            			payMsg = htPayMsg.get(pay_code);
            			otherHours = lhmHours.get(info);   
            			
            			String key = new String(payMsg + "." + deptChrg);
            			if (!lhmHoursRollup.containsKey(key)){
                			lhmHoursRollup.put(key, otherHours);
                		} else {
                			// add new hours to existing hours
                			String savedHrs = lhmHoursRollup.get(key);
                			Float newHrsFloat = (Float.valueOf(savedHrs)) + Float.valueOf(otherHours);
                			String newHrsStr = newHrsFloat.toString();
                			
                			lhmHoursRollup.put(key,newHrsStr);
                		}
            		}	
            		// 170553 end
            		
            		keyset1 = lhmTotMsgAmt.keySet();
            		it1 = keyset1.iterator();
            		while (it1.hasNext()) {
            			pay_code = it1.next();
            			payMsg = htPayMsg.get(pay_code);
            			amount = lhmTotMsgAmt.get(pay_code);   
            			
            			if (!lhmTotMsgAmtRollup.containsKey(payMsg)){
                			lhmTotMsgAmtRollup.put(payMsg, amount);
                		} else {
                			// add new am't to existing amount
                			String savedAmt = lhmTotMsgAmtRollup.get(payMsg);
                			Float newAmtFloat = (Float.valueOf(savedAmt)) + Float.valueOf(amount);
                			String newAmtStr = newAmtFloat.toString();
                			
                			lhmTotMsgAmtRollup.put(payMsg,newAmtStr);
                		}
            		}	
            	
                	// put totals in arrays
            		String info = null;
            		
            		int i = 0;
            		
            		Set<String> keyset = lhmPayAmtRollup.keySet();
            		Iterator<String> it = keyset.iterator();
            		while (it.hasNext()) {
            			info = it.next();
            			i = info.indexOf(".");
            			payMsg = info.substring(0,i);
            			deptChrg = info.substring(i+1,(info.length()));
            			amount = lhmPayAmtRollup.get(info); 
            			otherHours = lhmHoursRollup.get(info);
            			
            			//Defect 170494
            			if ((amount != null) && (amount != "")) {
            				if (amount.startsWith(".")) {
            					amount=amount.replaceFirst(".","0.");
            				}
            			} else {
            				LOGGER.error(new StringBuffer(logToken).append("Returning false because am't is null or blank"));
            				rcb = false;
            				//no reason to continue
            				return rcb;
            			}
            			//170553
            			if ((otherHours != null) && (otherHours != "")) {
            				if (otherHours.startsWith(".")) {
            					otherHours=otherHours.replaceFirst(".","0.");
            				}
            			} else {
            				LOGGER.error(new StringBuffer(logToken).append("Returning false because hours is null or blank"));
            				rcb = false;
            				//no reason to continue
            				return rcb;
            			}	
            			payAmount.add(amount);
            			payCodeMsg.add(payMsg); 
            			deptID.add(deptChrg);
            			//170553
            			payHours.add(otherHours);
            			
            			LOGGER.debug(new StringBuffer(logToken).append("Adding amount,payMsg,deptChrg,hours: ").append(amount).append(",").append(payMsg).append(",").append(deptChrg).append(",").append(otherHours));
            		}	
            		
            		//save in arrays in employee data
            		employeeData.setEmpPayAmount(payAmount);
            		employeeData.setEmpPayCodeMsgId(payCodeMsg);
            		employeeData.setEmpDeptId(deptID);
            		//170553
            		employeeData.setEmpPayHours(payHours);
            	
            		keyset = lhmTotMsgAmtRollup.keySet(); //iterate through paycodes
            		it = keyset.iterator();
            		while (it.hasNext()) { 
            			payMsg = it.next();
            			totalMsgId.add(payMsg);
            			String rollupAmt = lhmTotMsgAmtRollup.get(payMsg);
            			if (rollupAmt.startsWith(".")) {
        					rollupAmt=rollupAmt.replaceFirst(".","0.");
            			}
            			totalAmtByMsgId.add(rollupAmt);    			
            			
            		}	          		
               		//save in arrays in employee data
            		employeeData.setEmpPayCodeMsgIdUnique(totalMsgId);
            		employeeData.setEmpPayAmountByMsgId(totalAmtByMsgId);
            		       		            			
            	} else {  //not found or neg values
            		if (!found) {  //no result set found
            			LOGGER.error(new StringBuffer(logToken).append("Error in getting check info - no rows found"));
            			rcb = false;
            		} 	        	
            	}
				
            	// Get net pay amount, ignore if more than one result
            	//QL_QUERY_GETCHECK3 = "SELECT MONETARY_AMOUNT " +
    			//"FROM SYSADM.PS_C_PAY_TO_GL " +
    			//"WHERE EMPLID = ? " +
    			//"AND to_char(PAY_END_DT, 'MMDDYYYY') = ? " +
    			//"AND C_PAY_DESCR = 'N' AND C_PAY_CODE = 'NET'";
            	
				currentQuery = new String (SQL_QUERY_GETCHECK3);
				stmt = conn.prepareStatement(currentQuery);
				stmt.setQueryTimeout(sqlTimeout);
				stmt.setString(1,employeeId);
				stmt.setString(2,payEndDate);
				
				LOGGER.debug(new StringBuffer(logToken).append("Executing query: ").append(currentQuery));
				LOGGER.debug(new StringBuffer(logToken).append(" -- EMPLID =  ").append(employeeId.substring(employeeId.length()-3,employeeId.length())));
				LOGGER.debug(new StringBuffer(logToken).append(" -- PAY_END_DT =  ").append(payEndDate));
				
				rs = stmt.executeQuery();
				
				//put data into employee object
				
            	if (rs.next()) {  //first result
            		netPay = rs.getFloat(1);
            		
            		if (!rs.next() && netPay <= 0){ //if only one row and am't is 0 or negative
            			String tempNet = netPay.toString();
            			if (netPay != 0) {
            				tempNet = tempNet.substring(1);  // strip of '-'
            			}
               			if (tempNet.startsWith(".")) {
        					tempNet=tempNet.replaceFirst(".","0.");
            			}
            			employeeData.setEmpNetPayAmount(tempNet);
            		}
            		else  { //if more than one row or am't is positive 
            			employeeData.setEmpNetPayAmount(null);
            		}         		
            		
            	} else {   //no result found
            		employeeData.setEmpNetPayAmount(null);
            	}
            		
			} else {  //connection=null
		        	LOGGER.error(new StringBuffer(logToken).append("No connection made to DB"));
		        	throw new DAOException("Failed to connect to DB");
			}
		}catch(Exception e){ //Problem encountered getting query results
			LOGGER.error(new StringBuffer(logToken).append(" - Exception encountered in query: ").append(currentQuery));
			LOGGER.error(new StringBuffer(logToken).append(" - Exception:").append(e.getMessage()));
			throw new DAOException(e.getMessage());
				
		}finally{
			 releaseResource(conn, stmt, rs, sessionid);		 
		}

		return rcb;
	
	}	
	
	/********************************************************************************
	* Get Check Delivery Status
	/********************************************************************************/
	public	boolean getCheckDeliveryStatus(Employee employeeData, String storeNumber, String sessionid)throws DAOException {
		
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String currentQuery = null;
		
		boolean rcb = true;
		String logToken = new StringBuffer("[").append(sessionid).append("] ").toString();
		
		LOGGER.debug(new StringBuffer(logToken).append("********Entering PaycheckDAO::getCheckDeliveryStatus********"));
		LOGGER.debug(new StringBuffer(logToken).append("-- storeNumber = ").append(storeNumber));
		 
		//Connect to the DB	
		try {
			conn = getConnection(jndiName, sessionid);
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer(logToken).append(" - Exception getting a connection to the DB: ").append(e.getMessage()));
			throw new DAOException("Failed to connect to DB");
		}
		//get information
		try {			
			if (conn!=null){				
				LOGGER.debug(new StringBuffer(logToken).append("connection successful, querying data"));
						
				//SQL_QUERY_CHECK_DELIVERY = "SELECT TO_CHAR(PAYCHK_DT_TME,'MMDDYYYY')" +
				//"UPS_TRACKING_CD, REDIRECT_TO_TXT " +
				//"FROM IVR_O.STORE_PAYCHECK_DELIVERY " +
				//"WHERE STORE_NBR = ?";
				
				currentQuery = SQL_QUERY_CHECK_DELIVERY;
				stmt = conn.prepareStatement(currentQuery);
				stmt.setQueryTimeout(sqlTimeout);
				stmt.setString(1,storeNumber);
				
				LOGGER.debug(new StringBuffer(logToken).append("Executing query: ").append(currentQuery));
				LOGGER.debug(new StringBuffer(logToken).append(" -- STORE_NBR = ").append(storeNumber));
				rs = stmt.executeQuery();
				
	            if (rs.next()){
	            	employeeData.setDeliveryCheckDate(rs.getString(1));
	            	employeeData.setDeliveryTrackingNum(rs.getString(2)); //may be null
	            	employeeData.setDeliveryType(rs.getString(3));	 	  //may be null

		         } else{ //no result set found
		        	 LOGGER.error(new StringBuffer(logToken).append("Error in getting check delivery status - no rows found"));
		        	 rcb = false;
	             }
	       	 
			} else {  //connection=null
		        	LOGGER.error(new StringBuffer(logToken).append("No connection made to DB"));
		        	throw new DAOException("Failed to connect to DB");
			}
		}catch(Exception e){ //Problem encountered getting query results
			LOGGER.error(new StringBuffer(logToken).append(" - Exception encountered in query: ").append(currentQuery));
			LOGGER.error(new StringBuffer(logToken).append(" - Exception:").append(e.getMessage()));
			throw new DAOException(e.getMessage());
				
		}finally{
			 releaseResource(conn, stmt, rs, sessionid);		 
		}
		return rcb;	
	}			
}
