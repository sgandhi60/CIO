package com.ibm.ivr.cvs.plugin;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Enumeration;
import java.util.Properties;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;

import com.ibm.ivr.cvs.dao.PaycheckDAO;
import com.ibm.ivr.cvs.dao.CertificationDAO;
import com.ibm.ivr.cvs.dao.LoaDAO;
import com.ibm.ivr.cvs.dao.IdentificationDAO;
import com.ibm.ivr.cvs.dao.VacationDAO;
import com.ibm.ivr.framework.plugin.InitializationPlugin;
import com.ibm.ivr.framework.plugin.PluginException;

public class CvsProperty implements InitializationPlugin{

	private static Logger LOGGER = Logger.getLogger(CvsProperty.class);
	@SuppressWarnings("unused")
	private static String propertyFileRoot = null;

	
	@Override
	public void load(ServletContext context, Properties globalProp)
			throws PluginException {
		// TODO Auto-generated method stub
		
		// Get the root path to the CVS property files.
		propertyFileRoot = (String) context.getAttribute("propertyFilePath");
		
		// Load cvs.properties
		load_cvsProp(context);
		
		// Load certification.properties
		load_certificationProp(context);
		
        // Load the Shrink Reduction property file
		load_lpcert(context);	
	}

	@Override
	//
	//
	//
	//
 public void replace(ServletContext context, Properties globalProp,
			HttpServletRequest request) throws PluginException {
		// TODO Auto-generated method stub

		StringBuffer resultText = new StringBuffer();

		
		String app_properties = request.getParameter("app_properties");
		LOGGER.info("CvsProperty:: replace() command = "+app_properties);
		
		
		//
		// Act based on the app_properties collected through Reload.jsp
		//
		if (app_properties.trim().equalsIgnoreCase("all")){
			if (load_cvsProp(context) && load_lpcert(context) && load_certificationProp(context))
				resultText.append("ReloadServlet:: Reload of "+app_properties+" files completed Successfully");
			else
				resultText.append("ReloadServlet:: Reload of "+app_properties+" files failed.  See application logs for details");
		}else if (app_properties.trim().equalsIgnoreCase("lpcert.tt")){
			if (load_lpcert(context))
				resultText.append("ReloadServlet:: Reload of "+app_properties+" completed Successfully");
			else
				resultText.append("ReloadServlet:: Reload of "+app_properties+" failed.  See application logs for details");
		}else if (app_properties.trim().equalsIgnoreCase("cvs.properties")){
			if (load_cvsProp(context))
				resultText.append("ReloadServlet:: Reload of "+app_properties+" completed Successfully");
			else
				resultText.append("ReloadServlet:: Reload of "+app_properties+" failed.  See application logs for details");
		}else if (app_properties.trim().equalsIgnoreCase("certification.properties")){
			if (load_certificationProp(context))
				resultText.append("ReloadServlet:: Reload of "+app_properties+" completed Successfully");
			else
				resultText.append("ReloadServlet:: Reload of "+app_properties+" failed.  See application logs for details");
		}else{
			LOGGER.error("CvsProperty:: replace() command = "+app_properties+" invalid.");
			resultText.append("ReloadServlet:: Reload of "+app_properties+" failed.  Invalid parameter");
		}
		
		request.setAttribute("ReloadResult", resultText.toString());
		
	}
	
	//
	//
	//
	//
 @SuppressWarnings("unchecked")
private boolean load_lpcert(ServletContext context){
	// TODO Auto-generated method stub
	boolean rc = true;
	String propertyFileRoot = (String) context.getAttribute("propertyFilePath");
	Properties initProp = new Properties();
	Properties shrinkQuizProp = new Properties();

	
	LOGGER.info("CvsProperty:: Loading Shrink Reduction file:: "+propertyFileRoot+"lpcert.tt");
	  try{	
			URL url = new URL(propertyFileRoot+"lpcert.tt");
			InputStream is = url.openStream();
							
		// --------------------------------------------
		// load Shrink Reduction Quiz properties
		// --------------------------------------------							
		    initProp.load(is);
		
		    is.close();
	    } catch (IOException ioe) {
		    LOGGER.fatal("CvsProperty:: Failure loading lpcert.tt:: "+ioe.toString());
		    rc = false;
		    return false;											
	    }
		
	
		// --------------------------------------------------------------
		// Load Property Contents
	    // Cleanup contents if needed
		// --------------------------------------------------------------
	    
	    Enumeration em = initProp.keys();
	    String inKey = null;
	    String inVal = null;
	    String newKey = null;
	    String newVal = null;
	    
	    while( em.hasMoreElements() ){
	    	inKey = (String)em.nextElement();
	    	inVal = (String) initProp.get(inKey);
	    	
	    	// Clean up the entries before being put into the property object
	    	if (!inKey.startsWith(";")){
	    		if (inKey.startsWith("'")){
	    			newKey = inKey.substring(1, (inKey.length()-1));
	    		}
				if (inVal.startsWith("'"))
	    			   newVal = inVal.substring(1, (inVal.length()-1));
	    			else
	    				newVal = inVal;
	
	    		shrinkQuizProp.put(newKey, newVal);
	    	}    	
	    }
	
	    // Log contents for debugging purposes
	    em = shrinkQuizProp.keys();
	    String outKey = null;
	    String outVal = null;
	    LOGGER.debug("CvsProperty:: shrinkQuizProp Size = "+shrinkQuizProp.size());
	    
	    while( em.hasMoreElements() ){
	    	outKey = (String) em.nextElement();
	    	outVal = (String) shrinkQuizProp.get(outKey);
	    	LOGGER.debug("CvsProperty:: shrinkQuizProp Key:Value = "+outKey+":"+outVal);
	    }
	    
	// Place property information into context    
	context.setAttribute("shrinkQuizProp",shrinkQuizProp);
	
	LOGGER.info("CvsProperty:: Loading Shrink Reduction file complete:: "+propertyFileRoot+"lpcert.tt");
	return rc;
  }
 
 private boolean load_cvsProp(ServletContext context){
 	// TODO Auto-generated method stub
 	String propertyFileRoot = (String) context.getAttribute("propertyFilePath");
 	Properties initProp = new Properties();
 	 	
 	LOGGER.info("CvsProperty:: Loading properties file:: "+propertyFileRoot+"cvs.properties");
 	try{	
 			URL url = new URL(propertyFileRoot+"cvs.properties");
 			InputStream is = url.openStream();
 							
 		// --------------------------------------------
 		// load cvs.properties
 		// --------------------------------------------							
 		    initProp.load(is);
 		
 		    is.close();
 	} catch (IOException ioe) {
 		    LOGGER.fatal("CvsProperty:: Failure loading cvs.properties:: "+ioe.toString());
 		    return false;											
 	}
 	
 	context.setAttribute("cvsProp", initProp);
 	
 	int timeout = 10;
 	String timoutStr = initProp.getProperty("dbAccessTimeout");
 	if (timoutStr != null){
 		try {
 			timeout = Integer.parseInt(timoutStr);
 		}catch (NumberFormatException ex){
 		}
 	}
 	
 	//load the DAO instances
 	IdentificationDAO identificationDAO = new IdentificationDAO(initProp.getProperty("sysadmJndiName"), timeout);
 	context.setAttribute("identificationDAO", identificationDAO);
 	VacationDAO vacationDAO = new VacationDAO(initProp.getProperty("sysadmJndiName"), timeout);
 	context.setAttribute("vacationDAO", vacationDAO);
 	CertificationDAO certificationDAO = new CertificationDAO(initProp.getProperty("sysadmJndiName"), timeout);
 	context.setAttribute("certificationDAO", certificationDAO);
 	PaycheckDAO paycheckDAO = new PaycheckDAO(initProp.getProperty("sysadmJndiName"), timeout);
 	context.setAttribute("paycheckDAO", paycheckDAO);
 	// Mirt: Added 11-09-2010 LOA DAO 
 	LoaDAO loaDAO = new LoaDAO(initProp.getProperty("sysadmJndiName"), timeout);
 	context.setAttribute("loaDAO", loaDAO);

 	
 	LOGGER.info("CvsProperty:: Loading properties file complete:: "+propertyFileRoot+"cvs.properties");
 	
 	return true;
 }
 @SuppressWarnings("unchecked")
 private boolean load_certificationProp(ServletContext context){
 	// TODO Auto-generated method stub
 	String propertyFileRoot = (String) context.getAttribute("propertyFilePath");
 	Properties certificationProp = new Properties();
 	Properties cvsProps = (Properties)context.getAttribute("cvsProp");
 	 	
 	LOGGER.info("CvsProperty:: Loading properties file:: "+propertyFileRoot+"certification.properties");
 	try{	
 			URL url = new URL(propertyFileRoot+"certification.properties");
 			InputStream is = url.openStream();
 							
 		// --------------------------------------------
 		// load certification.properties
 		// --------------------------------------------							
 			certificationProp.load(is);
 		
 		    is.close();
 	} catch (IOException ioe) {
 		    LOGGER.fatal("CvsProperty:: Failure loading certification.properties:: "+ioe.toString());
 		    return false;											
 	}
 	
    // Log contents for debugging purposes
    Enumeration em = certificationProp.keys();

    String outKey = null;
    String outVal = null;
    LOGGER.debug("CvsProperty:: shrinkQuizProp Size = "+certificationProp.size());
    
    while( em.hasMoreElements() ){
    	outKey = (String) em.nextElement();
    	outVal = (String) certificationProp.get(outKey);
    	LOGGER.debug("CvsProperty:: certificationProp Key:Value = "+outKey+":"+outVal);
    }
	
 	context.setAttribute("certificationProp", certificationProp);
 	
 	int timeout = 10;
 	String timoutStr = cvsProps.getProperty("dbAccessTimeout");
 	if (timoutStr != null){
 		try {
 			timeout = Integer.parseInt(timoutStr);
 		}catch (NumberFormatException ex){
 		}
 	}
 	//load the DAO instances
 	CertificationDAO certificationDAO = new CertificationDAO(cvsProps.getProperty("sysadmJndiName"), timeout);
 	context.setAttribute("certificationDAO", certificationDAO);
 	
 	LOGGER.info("CvsProperty:: Loading properties file complete, and context based certificationDAO updated:: "+propertyFileRoot+"certification.properties");
 	
 	return true;
 } 	
}
