package com.ibm.ivr.cvs.dao;

public class DAOException extends Exception {

	private static final long serialVersionUID = 1L;
	private String error_msg;
	
	public DAOException() {
		super();
		error_msg = "unknown";
		// TODO Auto-generated constructor stub
	}

	public DAOException(String message) {
		super(message);
		error_msg = message;
		// TODO Auto-generated constructor stub
	}

	 public String getError()
	  {
	    return error_msg;
	  }
}

