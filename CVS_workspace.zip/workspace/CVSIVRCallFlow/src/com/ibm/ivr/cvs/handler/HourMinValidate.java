package com.ibm.ivr.cvs.handler;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

public class HourMinValidate extends HttpServlet implements Servlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2679776499353758670L;
	
	private static Logger LOGGER = Logger.getLogger(HourMinValidate.class);
	/**
     * @see HttpServlet#HttpServlet()
     */
    public HourMinValidate() {
        super();
        // TODO Auto-generated constructor stub
    }

	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		// get session from Servlet request, created if not existed yet
		HttpSession session = req.getSession(true);
		String callid = (String) session.getAttribute("callid");
		boolean testCall = ((Boolean) session.getAttribute("testCall")).booleanValue();

		//create the log Token for later use, use StringBuffer to reduce number
		// of String objects
		String logToken = new StringBuffer("[").append(callid).append("] ").toString();
				
		 if (testCall)
		 	LOGGER.debug(new StringBuffer(logToken).append("Entering Handler: HourMinValidate::"));
		 		 
		// Get  Session variable Hours & Minutes entered
		String LOAhourMinEntered = (String) session.getAttribute("LOAhourMinEntered");
		
		// Remove  Session variables for new Intermittent LOA playback
		session.removeAttribute("loaHours");
		session.removeAttribute("loaHourAudio");
		session.removeAttribute("loaMinutes");
		session.removeAttribute("loaMinuteAudio");
		session.removeAttribute("LOAhourMinConverted");

		 if (testCall)
			 	LOGGER.debug(new StringBuffer(logToken).append("Hours & Minutes entered::")
			 			                               .append(LOAhourMinEntered));

		// Result set if  hours & minutes are valid or not
		String LOAhourMinEnteredValid = "true";
	    String   loaHours = null;
	    String   loaHourAudio = null;
	    String   loaMinutes = null;
	    String   loaMinuteAudio = null;
	    Float  LOAhourMinConverted = new Float(0);
	    int    loaHoursMinTotalInt = 0;
	    int    loaMinValue = 0;
	    int    loaHourValue = 0;
		String m1 = null;
		String h1 = null;


	 // 1 DTMF
		if (LOAhourMinEntered.trim().length() == 1){
			loaMinutes = LOAhourMinEntered.trim();
			if (loaMinutes.equalsIgnoreCase("0")){
				loaMinutes = "0";
				loaMinuteAudio = "minutes";
			}
			else if (loaMinutes.equalsIgnoreCase("1"))
				loaMinuteAudio = "minute";
			else
				loaMinuteAudio = "minutes";
			
			// Convert and check minutes range
			loaHoursMinTotalInt = Integer.parseInt(loaMinutes);

			 if (testCall)
				 	LOGGER.debug(new StringBuffer(logToken).append("loaHoursMinTotalInt::")
				 			                               .append(loaHoursMinTotalInt));

			if (loaHoursMinTotalInt > 0 && loaHoursMinTotalInt <= 59)
			  LOAhourMinConverted = (float)loaHoursMinTotalInt / (float)60;
			else
			  LOAhourMinEnteredValid = "false";
		}

		// 2 DTMF 
        if (LOAhourMinEntered.trim().length() == 2){
			if (LOAhourMinEntered.trim().equalsIgnoreCase("00")){
				loaMinutes = "0";
				loaMinuteAudio = "minutes";
			} else {
			  if (LOAhourMinEntered.trim().startsWith("0"))
				loaMinutes = LOAhourMinEntered.trim().substring(1);
			  else
			  	loaMinutes = LOAhourMinEntered;
			  
			  if (loaMinutes.equalsIgnoreCase("1"))
				loaMinuteAudio = "minute";
			  else
				loaMinuteAudio = "minutes";
			}
			
			// Convert and check minutes range
			loaHoursMinTotalInt = Integer.parseInt(loaMinutes);

			 if (testCall)
				 	LOGGER.debug(new StringBuffer(logToken).append("loaHoursMinTotalInt::")
				 			                               .append(loaHoursMinTotalInt));


			if (loaHoursMinTotalInt > 0 && loaHoursMinTotalInt <= 59)
			  LOAhourMinConverted = (float)loaHoursMinTotalInt / (float)60;
			else
			  LOAhourMinEnteredValid = "false";
        }
			
		// 3 DTMF 			
		if (LOAhourMinEntered.trim().length() == 3){
			m1 = LOAhourMinEntered.trim().substring(1);
			h1 = LOAhourMinEntered.trim().substring(0,1);

			 if (testCall)
				 	LOGGER.debug(new StringBuffer(logToken).append("Minute Portion::")
				 			                               .append(m1)
				 			                               .append("Hour Portion::")
				 			                               .append(h1));
			
			// Figure out the minutes protion
			if (m1.equalsIgnoreCase("00")){
				loaMinutes = "0";
				loaMinuteAudio = "minutes";
			} else {
			  if (m1.startsWith("0"))
				loaMinutes = m1.substring(1);
			  else
			  	loaMinutes = m1;
			  
			  if (loaMinutes.equalsIgnoreCase("1"))
				loaMinuteAudio = "minute";
			  else
				loaMinuteAudio = "minutes";
			}
			
			// Figure out hour portion
			if (h1.equalsIgnoreCase("0")){
				loaHours = "0";
				loaHourAudio = "hours";
			} else {
			  loaHours = h1;
			  if (loaHours.equalsIgnoreCase("1"))
				loaHourAudio = "hour";
			  else
				loaHourAudio = "hours";
			}
		  
			// Convert and check minutes range
			loaMinValue = Integer.parseInt(loaMinutes);
			loaHourValue = Integer.parseInt(loaHours);
			
			if (loaHourValue < 0 || loaHourValue > 24){
				LOAhourMinEnteredValid = "false";
			}else{
				if (loaMinValue < 0 || loaMinValue > 59){
					LOAhourMinEnteredValid = "false";
				}else{
					if (loaHourValue == 24 && loaMinValue != 0){
						LOAhourMinEnteredValid = "false";
					}else{
						if (loaHourValue == 0 && loaMinValue == 0){
							LOAhourMinEnteredValid = "false";
						}
					}
				}
			}
			
			if (LOAhourMinEnteredValid.equals("true")){
				loaHoursMinTotalInt = ((loaHourValue*60)+loaMinValue);
	
				 if (testCall)
					 	LOGGER.debug(new StringBuffer(logToken).append("loaHoursMinTotalInt::")
					 			                               .append(loaHoursMinTotalInt));
	
	
				if (loaHoursMinTotalInt > 0 && loaHoursMinTotalInt <= 1440)
				  LOAhourMinConverted = (float)loaHoursMinTotalInt / (float)60;
				else
				  LOAhourMinEnteredValid = "false";
				}
 		}
		
		// 4 DTMF 
		if (LOAhourMinEntered.trim().length() == 4){
			m1 = LOAhourMinEntered.trim().substring(2);
			h1 = LOAhourMinEntered.trim().substring(0,2);

			 if (testCall)
				 	LOGGER.debug(new StringBuffer(logToken).append("Minute Portion::")
				 			                               .append(m1)
				 			                               .append("Hour Portion::")
				 			                               .append(h1));
			
			// Figure out the minutes protion
			if (m1.equalsIgnoreCase("00")){
				loaMinutes = "0";
				loaMinuteAudio = "minutes";
			} else {
			  if (m1.startsWith("0"))
				loaMinutes = m1.substring(1);
			  else
			  	loaMinutes = m1;
			  
			  if (loaMinutes.equalsIgnoreCase("1"))
				loaMinuteAudio = "minute";
			  else
				loaMinuteAudio = "minutes";
			}
			
			// Figure out hour portion
			if (h1.equalsIgnoreCase("00")){
				loaHours = "0";
				loaHourAudio = "hours";
			} else {
				if (h1.startsWith("0"))
				  loaHours = h1.substring(1);
				else
				  loaHours = h1;
				
				
			  if (loaHours.equalsIgnoreCase("1"))
				loaHourAudio = "hour";
			  else
				loaHourAudio = "hours";
			}
			  
			// Convert and check minutes range
			loaMinValue = Integer.parseInt(loaMinutes);
			loaHourValue = Integer.parseInt(loaHours);
			
			if (loaHourValue < 0 || loaHourValue > 24){
				LOAhourMinEnteredValid = "false";
			}else{
				if (loaMinValue < 0 || loaMinValue > 59){
					LOAhourMinEnteredValid = "false";
				}else{
					if (loaHourValue == 24 && loaMinValue != 0){
						LOAhourMinEnteredValid = "false";
					}else{
						if (loaHourValue == 0 && loaMinValue == 0){
							LOAhourMinEnteredValid = "false";
						}
					}
				}
			}
			
			if (LOAhourMinEnteredValid.equals("true")){
				loaHoursMinTotalInt = ((loaHourValue*60)+loaMinValue);
	
				 if (testCall)
					 	LOGGER.debug(new StringBuffer(logToken).append("loaHoursMinTotalInt::")
					 			                               .append(loaHoursMinTotalInt));
	
	
				if (loaHoursMinTotalInt > 0 && loaHoursMinTotalInt <= 1440)
				  LOAhourMinConverted = (float)loaHoursMinTotalInt / (float)60;
				else
				  LOAhourMinEnteredValid = "false";
			}
		}

		
		// Set session variable for reply
		session.setAttribute("LOAhourMinEnteredValid", LOAhourMinEnteredValid);
		session.setAttribute("loaHours", loaHours);
		session.setAttribute("loaHourAudio", loaHourAudio);
		session.setAttribute("loaMinutes", loaMinutes);
		session.setAttribute("loaMinuteAudio", loaMinuteAudio);
		session.setAttribute("LOAhourMinConverted", LOAhourMinConverted);


		 if (testCall){
			 	LOGGER.debug(new StringBuffer(logToken).append("LOAhourMinEnteredValid::")
			 			                               .append(LOAhourMinEnteredValid)
			 			                               .append(" loaHours:: ")
			 			                               .append(loaHours)
			 			                               .append("  loaHourAudio::")
			 			                               .append(loaHourAudio)
			 			                               .append("  loaMinutes::")
			 			                               .append(loaMinutes)
			 			                               .append("  loaMinuteAudio::")
			 			                               .append(loaMinuteAudio)
			 			                               .append("  LOAhourMinConverted::")
			 			                               .append(LOAhourMinConverted));
			 	
			 	
			 	LOGGER.debug(new StringBuffer(logToken).append("Exiting Handler: HourMinValidate::"));
		 }
		return;
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request,response);
	}

}


