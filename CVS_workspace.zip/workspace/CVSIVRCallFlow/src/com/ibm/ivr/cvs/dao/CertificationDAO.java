/* History
 * 11/10/2010 FSW: Initial creation 
 * 12/03/2010 FSW: Modify message for DAOException for no DB connection 
 * 01/10/2011 FSW: Defect 170295 Remove logging of personal data, defect
 * 				   Also remove any unused variables
 * 01/13/2011 FSW: Defect 170305, IVR_O schema tables do not have synonym defined so
 * 					need to specify
 * 01/13/2011 FSW: Defect 170306 get error trying to log last 4 digits of dependentSSN
 *                 when value is ' '.  Add length check first.
 * 01/24/2011 FSW: Add sessionid to logging.  Defect 170371
 * 01/25/2011 FSW: Add query timeout.  Defect 170321
 * 03/01/2011 FSW: Modify query to ivr_o.locationM1 and handle null values for area, district,region
 * 					Defect 170492
*/

package com.ibm.ivr.cvs.dao;

	import com.ibm.ivr.cvs.dao.BaseDAO;
	import com.ibm.ivr.cvs.data.Employee;
	import java.sql.Connection;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;
	import java.sql.SQLException;
import org.apache.log4j.Logger;


		public class CertificationDAO extends BaseDAO{
			
		private final static Logger LOGGER = Logger.getLogger(CertificationDAO.class);		
		//private Connection conn = null; Defect 170481, move to methods
		private String jndiName = null;
		
		private final static String SQL_QUERY_QUIZ_STATUS = 
				"SELECT CERT_IND, TRIES " +
				"FROM IVR_O.LP_SHRINK_CERT " +
				"WHERE STORE_NBR = ? AND EMPL_ID = ? AND QUIZ_ID = ?"; 
		
		private final static String SQL_QUERY_NAME = 
				"SELECT LAST_NAME, FIRST_NAME " +
				"FROM SYSADM.PS_C_PERS_DATA_VW " +
				"WHERE EMPLID = ?";	
		
		/* Defect 170492 modify following query
		private final static String SQL_QUERY_LOCATION = 
			"SELECT CVS_AREA, CVS_REGION, CVS_DISTRICT " +
			"FROM IVR_I.LOCATIONM1 " +
			"WHERE LOCATION_CODE = ?";
		*/
		private final static String SQL_QUERY_LOCATION = 
			"SELECT CVS_AREA, CVS_REGION, CVS_DISTRICT " +
			"FROM IVR_I.LOCATIONM1 " +
			"WHERE LOCATION_CODE = ?" +
			"ORDER BY SYSMODTIME DESC NULLS LAST";

		
		private final static String SQL_UPDATE_RECORD =
				"UPDATE IVR_O.LP_SHRINK_CERT " +
				"SET AREA = ? , REGION = ?, DISTRICT = ?, CERT_IND = ?, TRIES = ? , LAST_UPDT_TME = SYSDATE " +
				"WHERE STORE_NBR = ? AND EMPL_ID = ? AND QUIZ_ID = ?";

		private final static String SQL_INSERT_RECORD =	
				"INSERT INTO IVR_O.LP_SHRINK_CERT " +
				"(STORE_NBR, AREA, REGION, DISTRICT, EMPL_ID, QUIZ_ID, EMPL_FNAME, EMPL_LNAME, EMPL_TITLE, " +
				"EMPL_STATUS, CERT_IND, TRIES, LAST_UPDT_TME) " +
				"VALUES (?,?,?,?,?,?,?,?,?,?,?,?,SYSDATE)";


		private final static String SQL_QUERY_DEPSSN =	
				"SELECT EMPLID FROM sysadm.ps_c_ivr_depssn " +
				"WHERE EMPLID = ?  AND DEPENDENT_BENEF= ?";

		private final static String SQL_INSERT_DEPSSN =	
			"INSERT INTO sysadm.ps_c_ivr_depssn " +
			"(EMPLID, DEPENDENT_BENEF, NATIONAL_ID, TRANSACTION_DATE, PROCESSED_FLAG,SSN_OPTION ) " +
			" VALUES (?,?,?,SYSDATE,?,?)";

		private final static String SQL_UPDATE_DEPSSN =	
			"UPDATE sysadm.ps_c_ivr_depssn " +
			"SET NATIONAL_ID=?, TRANSACTION_DATE=SYSDATE, PROCESSED_FLAG=?, SSN_OPTION=? " +
			"WHERE EMPLID = ? AND DEPENDENT_BENEF = ?";
			
		private final static String SQL_QUERY_DEA_CERT =	
			"select DATE_CERTIFIED from sysadm.ps_c_ivr_dea_cert " +
			"WHERE EMPLID = ?";

		private final static String SQL_RECORD_DEA_CERT =	
			"INSERT INTO sysadm.ps_c_ivr_dea_cert " +
			"(EMPLID,DATE_CERTIFIED) VALUES (?, SYSDATE)";
		
		private int sqlTimeout = 0;  //timeout for stmt execution in secs
		
		/********************************************************************************
		* Constructor
		/********************************************************************************/
		public CertificationDAO(String jndiName, int timeout) {
			// initialization
			this.jndiName = jndiName;
			this.sqlTimeout = timeout;
			
			//logToken = new StringBuffer("[").append(callid).append("] ").toString();
			//logToken = new StringBuffer("[CertificationDAO]").toString();
			LOGGER.debug("******** Created CertificationDAO ********");
			LOGGER.debug(new StringBuffer("-- jndiName = ").append(jndiName));
		}
		
		/********************************************************************************
		* get quiz status for employee
		* "SELECT CERT_IND, TRIES " +
		*		"FROM LP_SHRINK_CERT " +
		*		"WHERE STORE_NBR = ? AND EMPL_ID = ? AND QUIZ_ID = ?"; 
		/********************************************************************************/
		public boolean  getQuizStatus(Employee employee, String quizNumber, String storeNumber, String sessionid) throws DAOException {
			
			Connection conn = null;
			String employeeId = employee.employeeID;
			PreparedStatement stmt = null;
			ResultSet rs = null;
			boolean rcb = false;
					
			String logToken = new StringBuffer("[").append(sessionid).append("] ").toString();
			LOGGER.debug(new StringBuffer(logToken).append("********Entering CertificationDAO.getQuizStatus********"));
			
			// reset employee data in case this is for second test, and we don't find or get exception
        	employee.setShrinkQuizCompleted(null);
        	employee.setNumberOfTries(0);
        	
			//Connect to the DB	
			try {
				conn = getConnection(jndiName,sessionid);
			} catch (SQLException e) {
				LOGGER.error(new StringBuffer(logToken).append("SQLException getting a connection to the DB: ").append(e.getMessage()));
				throw new DAOException("Failed to connect to DB");
			}
			//get information
			//SQL_QUERY_QUIZ_STATUS = 
			//	SELECT CERT_IND, TRIES 
			//	FROM LP_SHRINK_CERT 
			//	WHERE STORE_NBR = ? AND EMPL_ID = ? AND QUIZ_ID = ? 
			try {			
				if (conn!=null){				
					stmt = conn.prepareStatement(SQL_QUERY_QUIZ_STATUS);
					stmt.setQueryTimeout(sqlTimeout);
					
					stmt.setString(1,storeNumber);
					stmt.setString(2,employeeId);
					stmt.setString(3,quizNumber);
	                rs = stmt.executeQuery();
	                
		            if (rs.next()){		        	
			            employee.setShrinkQuizCompleted(rs.getString(1));
			            employee.setNumberOfTries(rs.getInt(2));
		                rcb = true;
			             
			         } else{  //no result set found return false, set quizCompleted = null
			        	LOGGER.debug(new StringBuffer(logToken).append(" - No match found for employeeID").append(employeeId.substring(employeeId.length()-3,employeeId.length())));
		             }

					} else {  //connection=null
			        	LOGGER.error(new StringBuffer(logToken).append(" - No connection made to DB for quiz status"));
			        	throw new DAOException("Failed to connect to DB"); 
			        }
				 }catch(Exception e){  //Problem encountered getting query results
					 LOGGER.error(new StringBuffer(logToken).append(" - Exception encountered getting quiz status: ").append(e.getMessage()));
					 LOGGER.error(new StringBuffer(logToken).append(" -- employee ID = ").append(employeeId.substring(employeeId.length()-3,employeeId.length())));
					 //LOGGER.error(new StringBuffer(logToken).append(" -- store Number = ").append(storeNumber));
					 LOGGER.error(new StringBuffer(logToken).append(" -- store Number = ***"));
					 LOGGER.error(new StringBuffer(logToken).append(" -- quiz Number = ").append(quizNumber));
					 throw new DAOException(e.getMessage());
					 
				 }finally{
					 releaseResource(conn, stmt, rs, sessionid);		 
				 }
			
			return rcb;
		
	}			

		/********************************************************************************
		* Update DB with new quiz status
		/********************************************************************************/		
		public boolean  updateQuizStatus(Employee employee, String quizNumber, String storeNumber, String status, String sessionid) throws DAOException {
		
		Connection conn = null;
		String employeeId = employee.employeeID;
		int numTries = employee.getNumberOfTries();
		String firstName = null;
		String lastName = null;
		String area = null;
		String district = null;
		String region = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		int numRows = 0;
		boolean rcb = true;	
		
			String logToken = new StringBuffer("[").append(sessionid).append("] ").toString();
			LOGGER.debug(new StringBuffer(logToken).append(" - *******Entered CertificationDAO::updateQuizStatus()"));	

			//Connect to the DB	
			try {
				conn = getConnection(jndiName,sessionid);
			} catch (SQLException e) {
				LOGGER.error(new StringBuffer(logToken).append("SQLException getting a connection to the DB: ").append(e.getMessage()));
				throw new DAOException("Failed to connect to DB");
			}
			
			//get req'd data
			// get name:
			// SQL_QUERY_NAME = SELECT LAST_NAME, FIRST_NAME FROM SYSADM.PS_C_PERS_DATA_VW WHERE EMPLID = ?
			// get location
			//SQL_QUERY_LOCATION = "SELECT LOCATION_CODE, CVS_AREA, CVS_REGION, CVS_DISTRICT 
			// FROM IVR_I.LOCATIONM1 WHERE LOCATION_CODE = ? ORDER BY SYSMODTIME DESC NULLS LAST";
			try {			
				if (conn!=null){				
					stmt = conn.prepareStatement(SQL_QUERY_NAME);	
					stmt.setQueryTimeout(sqlTimeout);
					stmt.setString(1,employeeId);

	                rs = stmt.executeQuery();
		             
		            if (rs.next()){		        	
			            lastName = (rs.getString(1));
			            firstName  = (rs.getString(2));
			        	
			         } else{  //no result set found return false
			        	 rcb = false;
			        	 LOGGER.info(new StringBuffer(logToken).append(" - No match found in pers_data for employeeId: ").append(employeeId.substring(employeeId.length()-3,employeeId.length())));
	    
		             }
		            
		            if (rcb) {
		            	stmt = conn.prepareStatement(SQL_QUERY_LOCATION);
		            	stmt.setQueryTimeout(sqlTimeout);
		            	stmt.setString(1,storeNumber);
					
		            	rs = stmt.executeQuery();
		             
		            	if (rs.next()){		        	
				            area	 = (rs.getString(1));
				            region	 = (rs.getString(2));
				            district = (rs.getString(3));
				            
				            // defect 170492
				            if (area == null)
				            	area = "00";
				            if (region == null)
				            	region = "00";
				            if (district == null)
				            	district = "00";
				           
			            
		            	} else{  //no result set found return false
		            		rcb = false;
		            		LOGGER.info(new StringBuffer(logToken).append(" - No match found in locationm1 for location: ").append(storeNumber));	        	 
		            	}
		            }
		            			            
				} else {  //connection=null
					rcb = false;
			        LOGGER.error(new StringBuffer(logToken).append(" - No connection made to DB for quiz update"));
			        throw new DAOException("Failed to connect to DB"); 
			    }
				
			}catch(Exception e){  //Problem encountered getting query results
					 rcb = false;
					 LOGGER.error(new StringBuffer(logToken).append(" - Exception encountered getting quiz status: ").append(e.getMessage()));
					 LOGGER.error(new StringBuffer(logToken).append(" -- employee ID = ").append(employeeId.substring(employeeId.length()-3,employeeId.length())));
					 //LOGGER.error(new StringBuffer(logToken).append(" -- store Number = ").append(storeNumber));
					 LOGGER.error(new StringBuffer(logToken).append(" -- store Number = ***"));
					 LOGGER.error(new StringBuffer(logToken).append(" -- quiz Number = ").append(quizNumber));
					 releaseResource(conn,stmt,rs,sessionid);
					 throw new DAOException (e.getMessage());					 
			}
			
			if (rcb) {
			
				try {		
					if (numTries > 0) {
						LOGGER.debug(new StringBuffer(logToken).append("numTries > 0, Updating record: "));
						LOGGER.debug(new StringBuffer(logToken).append(" -- empl_id = ").append(employeeId.substring(employeeId.length()-3,employeeId.length())));
						//LOGGER.debug(new StringBuffer(logToken).append(" -- store_nbr = ").append(storeNumber));
						LOGGER.debug(new StringBuffer(logToken).append(" -- store_nbr = ***"));
						LOGGER.debug(new StringBuffer(logToken).append(" -- quiz_id = ").append(quizNumber));
						LOGGER.debug(new StringBuffer(logToken).append(" -- area = ").append(area));
						LOGGER.debug(new StringBuffer(logToken).append(" -- region = ").append(region));
						LOGGER.debug(new StringBuffer(logToken).append(" -- district = ").append(district));
						LOGGER.debug(new StringBuffer(logToken).append(" -- cert_ind = ").append(status));
						LOGGER.debug(new StringBuffer(logToken).append(" -- numTries = ").append(numTries + 1));
						//update information
					    /*SQL_UPDATE_RECORD =
						"UPDATE LP_SHRINK_CERT" +
						"SET AREA = ? , REGION = ?, DISTRICT = ?, CERT_IND = ?, TRIES = ? , LAST_UPDT_TME = SYSDATE " +
						"WHERE STORE_NBR = ? AND EMPL_ID = ? AND QUIZ_ID = ?";
					    */			
					stmt = conn.prepareStatement(SQL_UPDATE_RECORD);	
					stmt.setQueryTimeout(sqlTimeout);
					stmt.setString(1,area);
					stmt.setString(2,region);
					stmt.setString(3,district);
					stmt.setString(4,status);
					stmt.setInt(5,numTries+1);
					stmt.setString(6,storeNumber);
					stmt.setString(7,employeeId);
					stmt.setString(8,quizNumber);				
			
				} else  { // numTries = 0
					LOGGER.debug(new StringBuffer(logToken).append("numTries = 0, Inserting record: "));
					LOGGER.debug(new StringBuffer(logToken).append(" -- employee ID = ").append(employeeId.substring(employeeId.length()-3,employeeId.length())));
					//LOGGER.debug(new StringBuffer(logToken).append(" -- store Number = ").append(storeNumber));
					LOGGER.debug(new StringBuffer(logToken).append(" -- store Number = ***"));
					LOGGER.debug(new StringBuffer(logToken).append(" -- quiz_id = ").append(quizNumber));
					LOGGER.debug(new StringBuffer(logToken).append(" -- area = ").append(area));
					LOGGER.debug(new StringBuffer(logToken).append(" -- region = ").append(region));
					LOGGER.debug(new StringBuffer(logToken).append(" -- district = ").append(district));			
					//LOGGER.debug(new StringBuffer(logToken).append(" -- empl_fname = ").append(firstName));
					LOGGER.debug(new StringBuffer(logToken).append(" -- empl_fname = ****"));
					//LOGGER.debug(new StringBuffer(logToken).append(" -- empl_lname = ").append(lastName));
					LOGGER.debug(new StringBuffer(logToken).append(" -- empl_lname = ****"));
					LOGGER.debug(new StringBuffer(logToken).append(" -- emp_title = ").append(employee.jobDescription));
					LOGGER.debug(new StringBuffer(logToken).append(" -- empl_status = ").append(employee.employmentStatus));
					LOGGER.debug(new StringBuffer(logToken).append(" -- cert_ind = ").append(status));
					LOGGER.debug(new StringBuffer(logToken).append(" -- numTries = 1"));
					//update information
					//create new record
				    /* SQL_INSERT_RECORD =	
				    "INSERT INTO LP_SHRINK_CERT " +
					"(STORE_NBR, AREA, REGION, DISTRICT, EMPL_ID, QUIZ_ID, EMPL_FNAME, EMPL_LNAME, EMPL_TITLE, " +
					"EMPL_STATUS, CERT_IND, TRIES, LAST_UPDT_TME) " +
					"VALUES (?,?,?,?,?,?,?,?,?,?,?,?,SYSDATE)";
				    */
					stmt = conn.prepareStatement(SQL_INSERT_RECORD);	
					stmt.setQueryTimeout(sqlTimeout);
					
					stmt.setString(1,storeNumber);
					stmt.setString(2,area);
					stmt.setString(3,region);
					stmt.setString(4,district);
					stmt.setString(5,employeeId);
					stmt.setString(6,quizNumber);
					stmt.setString(7,firstName);
					stmt.setString(8,lastName);				
					stmt.setString(9,employee.jobDescription);
					stmt.setString(10,employee.employmentStatus);
					stmt.setString(11,status);
					stmt.setInt(12,1);
				}
					
				numRows = stmt.executeUpdate();
				if (numRows <= 0) //insert or update not successful
					rcb = false;
				else { // update employee values to match DB
					employee.setNumberOfTries(numTries + 1);
					employee.setShrinkQuizCompleted(status);
				}
			  }catch(Exception e){  //Problem encountered getting query results
				LOGGER.error(new StringBuffer(logToken).append(" - Exception encountered on insert/update quiz status ").append(e.getMessage()));
				LOGGER.error(new StringBuffer(logToken).append(" -- employee ID = ").append(employeeId.substring(employeeId.length()-3,employeeId.length())));
				LOGGER.error(new StringBuffer(logToken).append(" -- store Number = ****"));
			    LOGGER.error(new StringBuffer(logToken).append(" -- quiz Number = ").append(quizNumber));
			    rcb = false;
				throw new DAOException(e.getMessage());
				
			  }finally{
				releaseResource(conn, stmt, rs, sessionid);		 
			  }
			  
			}  else { // rcb = false 
				releaseResource(conn, stmt, rs, sessionid);
			}
			
		return rcb;
		}

		/********************************************************************************
		* Update DB Dependent SSN
		/********************************************************************************/		
		public boolean  updateDependentSSN(Employee employee, String dependentID, String dependentSSN, String ssnOption, String sessionid) throws DAOException {
		//Note: dependentSSN may be ' ', but will never be NULL
		
		Connection conn = null;
		String employeeId = employee.employeeID;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String processedFlag="N"; // always set to N by ivr
		int numRows = 0;
		boolean exists = false;
		boolean rcb = true;
		
			String logToken = new StringBuffer("[").append(sessionid).append("] ").toString();
			LOGGER.debug(new StringBuffer(logToken).append(" - *******Entered CertificationDAO::updateDependentSSN()"));
			
			//Connect to the DB	
			try {
				conn = getConnection(jndiName,sessionid);
			} catch (SQLException e) {
				LOGGER.error(new StringBuffer(logToken).append("SQLException getting a connection to the DB: ").append(e.getMessage()));
				rcb = false;
				throw new DAOException("Failed to connect to DB");
			}
			
			//get req'd data
			// SQL_QUERY_DEPSSN =	
			//"SELECT EMPLID FROM sysadm.ps_c_ivr_depssn " +
			//"WHERE EMPLID = ?  AND DEPENDENT_BENEF= ?";
	
			try {			
				if (conn!=null){				
					stmt = conn.prepareStatement(SQL_QUERY_DEPSSN);	
					stmt.setQueryTimeout(sqlTimeout);
					
					stmt.setString(1,employeeId);
					stmt.setString(2,dependentID);
					
	                rs = stmt.executeQuery();
		            
	                LOGGER.debug(new StringBuffer(logToken).append("--emplid = ").append(employeeId.substring(employeeId.length()-3,employeeId.length())));
		            LOGGER.debug(new StringBuffer(logToken).append("--dependent_benef = ").append(dependentID));
		            
		            if (rs.next()){		        	
			            exists = true;	
			            
		             }          

		            if (exists) {  //update existing record
		            	LOGGER.debug(new StringBuffer(logToken).append("Record found"));
		            	LOGGER.debug(new StringBuffer(logToken).append("Updating record: "));
		            	
			            /*SQL_UPDATE_DEPSSN =	
		    			"UPDATE sysadm.ps_c_ivr_depssn " +
		    			"SET NATIONAL_ID=?, TRANSACTION_DATE=SYSDATE, PROCESSED_FLAG=?, SSN_OPTION=? " +
		    			"WHERE EMPLID = ? AND DEPENDENT_BENEF = ?";
			             */
		            	stmt = conn.prepareStatement(SQL_UPDATE_DEPSSN);
		            	stmt.setQueryTimeout(sqlTimeout);
		            	
		            	stmt.setString(1,dependentSSN);
		            	stmt.setString(2,processedFlag);
		            	stmt.setString(3,ssnOption);
		            	stmt.setString(4,employeeId);
		            	stmt.setString(5,dependentID);			
			            
		            } else {  //no record found, insert new record
		            	LOGGER.debug(new StringBuffer(logToken).append("No record found"));
		            	LOGGER.debug(new StringBuffer(logToken).append("Inserting new record: "));
		            	
		            	/*SQL_INSERT_DEPSSN =	
		        			"INSERT INTO sysadm.ps_c_ivr_depssn " +
		        			"(EMPLID, DEPENDENT_BENEF, NATIONAL_ID, TRANSACTION_DATE, PROCESSED_FLAG,SSN_OPTION ) " +
		        			" VALUES (?,?,?,SYSDATE,?,?)";		
		        		*/
		            	stmt = conn.prepareStatement(SQL_INSERT_DEPSSN);
		            	stmt.setQueryTimeout(sqlTimeout);

		            	stmt.setString(1,employeeId);
		            	stmt.setString(2,dependentID);	
		            	stmt.setString(3,dependentSSN);
		            	stmt.setString(4,processedFlag);
		            	stmt.setString(5,ssnOption);
		            }	
					LOGGER.debug(new StringBuffer(logToken).append(" -- emplid = ").append(employeeId.substring(employeeId.length()-3,employeeId.length())));
					LOGGER.debug(new StringBuffer(logToken).append(" -- dependent_benef = ").append(dependentID));
					if (dependentSSN.length() >=4 )
						LOGGER.debug(new StringBuffer(logToken).append(" -- national_id = ").append(dependentSSN.substring(dependentSSN.length()-4,dependentSSN.length())));
					else
						LOGGER.debug(new StringBuffer(logToken).append(" -- national_id = ").append(dependentSSN));
					LOGGER.debug(new StringBuffer(logToken).append(" -- processed_flag = ").append(processedFlag));
					LOGGER.debug(new StringBuffer(logToken).append(" -- ssn_option = ").append(ssnOption));
					
	            	numRows = stmt.executeUpdate();
					if (numRows <= 0) { //insert or update not successful
						LOGGER.error(new StringBuffer(logToken).append("Update/Insert failed"));
						rcb = false;
					} else {
						LOGGER.debug(new StringBuffer(logToken).append("Update/Insert successful"));
					}
					
				} else {  //connection=null
					rcb = false; 
			        	LOGGER.error(new StringBuffer(logToken).append(" - No connection made to DB for dependent SSN update"));
			        	throw new DAOException("Failed to connect to DB");
			    }
				
				
			}catch(Exception e){  //Problem encountered getting query results
					 rcb = false;
					 LOGGER.error(new StringBuffer(logToken).append(" - Exception occurred during insert/update SSN: ").append(e.getMessage()));
					 LOGGER.error(new StringBuffer(logToken).append(" -- employee ID = ").append(employeeId.substring(employeeId.length()-3,employeeId.length())));
					 LOGGER.error(new StringBuffer(logToken).append(" -- dependentSSN = ").append(dependentSSN.substring(dependentSSN.length()-4, dependentSSN.length())));
					 LOGGER.error(new StringBuffer(logToken).append(" -- dependentID  = ").append(dependentID));
					 LOGGER.error(new StringBuffer(logToken).append(" -- ssnOption = ").append(ssnOption));
					 
					 throw new DAOException(e.getMessage());
			}finally{
					 releaseResource(conn, stmt, rs, sessionid);		 
			}	
		
		return rcb;
		}

		/********************************************************************************
		* Get DEA Certification status
		/********************************************************************************/
		public boolean  getDEACertStatus(Employee employee, String sessionid) throws DAOException {
			
			Connection conn = null;
			String employeeId = employee.employeeID;
			PreparedStatement stmt = null;
			ResultSet rs = null;
			boolean rcb = false;
			
			String logToken = new StringBuffer("[").append(sessionid).append("] ").toString();
			LOGGER.debug(new StringBuffer(logToken).append("********Entering CertificationDAO.getDEACertStatus********"));
        	
			//Connect to the DB	
			try {
				conn = getConnection(jndiName,sessionid);
			} catch (SQLException e) {
				LOGGER.error(new StringBuffer(logToken).append("SQLException getting a connection to the DB: ").append(e.getMessage()));
				throw new DAOException("Failed to connect to DB");
			}
			//get information
			//SQL_QUERY_DEA_CERT =	
			//	"select DATE_CERTIFIED from sysadm.ps_c_ivr_dea_cert " +
			//	"WHERE EMPLID = ?";
			
			try {			
				if (conn!=null){				
					stmt = conn.prepareStatement(SQL_QUERY_DEA_CERT);	
					stmt.setQueryTimeout(sqlTimeout);
					stmt.setString(1,employeeId);

					LOGGER.debug(new StringBuffer(logToken).append("Executing query: ").append(stmt));
					LOGGER.debug(new StringBuffer(logToken).append(" -- EMPLID = ").append(employeeId.substring(employeeId.length()-3,employeeId.length())));
					
	                rs = stmt.executeQuery();
	                
	                // if row returned and date is not NULL return true otherwise
	                //    return default value of false
		            if (rs.next()){		        	
			            if (rs.getDate(1) != null)
			            	rcb = true;
			             
			         } else{  //no result set found return false
			        	LOGGER.debug(new StringBuffer(logToken).append(" - No match found for employeeID").append(employeeId.substring(employeeId.length()-3,employeeId.length())));
		             }

				  } else {  //connection=null
			        LOGGER.debug(new StringBuffer(logToken).append(" - No connection made to DB for DEA cert"));
			        throw new DAOException("Failed to connect to DB"); 
			      }
				 }catch(Exception e){  //Problem encountered getting query results
					 LOGGER.error(new StringBuffer(logToken).append(" - Exception encountered getting DEA cert: ").append(e.getMessage()));
					 LOGGER.error(new StringBuffer(logToken).append(" -- employee ID = ").append(employeeId.substring(employeeId.length()-3,employeeId.length())));
					 throw new DAOException(e.getMessage());
					 
				 }finally{
					 releaseResource(conn, stmt, rs, sessionid);		 
				 }
			
			return rcb;
		
	}			

		/********************************************************************************
		* Insert DEA Certification record
		/********************************************************************************/
		public boolean  recordDEACertification(Employee employee, String sessionid) throws DAOException {
			
			Connection conn = null;
			String employeeId = employee.employeeID;
			PreparedStatement stmt = null;
			ResultSet rs = null;
			boolean rcb = true;
			int numRows = 0;
			
			String logToken = new StringBuffer("[").append(sessionid).append("] ").toString();
			LOGGER.debug(new StringBuffer(logToken).append("********Entering CertificationDAO.recordDEACertification********"));
        	
			//Connect to the DB	
			try {
				conn = getConnection(jndiName,sessionid);
			} catch (SQLException e) {
				LOGGER.error(new StringBuffer(logToken).append("SQLException getting a connection to the DB: ").append(e.getMessage()));
				throw new DAOException("Failed to connect to DB");
			}
			//insert record
			//SQL_RECORD_DEA_CERT =	
			//	"INSERT INTO sysadm.ps_c_ivr_dea_cert " +
			//	"(EMPLID,DATE_CERTIFIED) VALUES (?, SYSDATE)";
			
			try {			
				if (conn!=null){				
					stmt = conn.prepareStatement(SQL_RECORD_DEA_CERT);	
					stmt.setQueryTimeout(sqlTimeout);
					stmt.setString(1,employeeId);

					LOGGER.debug(new StringBuffer(logToken).append("Executing insert: ").append(stmt));
					LOGGER.debug(new StringBuffer(logToken).append(" -- EMPLID = ").append(employeeId.substring(employeeId.length()-3,employeeId.length())));
					
	                // if insert is successful, return true
	                numRows = stmt.executeUpdate();
		            if (numRows <= 0) {
		            	rcb = false; 
			        	LOGGER.debug(new StringBuffer(logToken).append("Insert of DEA Cert record failed for employee:").append(employeeId.substring(employeeId.length()-3,employeeId.length())));
		             }

				  } else {  //connection=null
			        LOGGER.debug(new StringBuffer(logToken).append(" - No connection made to DB for DEA cert"));
			        throw new DAOException("Failed to connect to DB"); 
			      }
				
				 }catch(Exception e){  //Problem encountered getting query results
					 LOGGER.error(new StringBuffer(logToken).append(" - Exception encountered inserting DEA cert: ").append(e.getMessage()));
					 LOGGER.error(new StringBuffer(logToken).append(" -- employee ID = ").append(employeeId.substring(employeeId.length()-3,employeeId.length())));
					 throw new DAOException(e.getMessage());
					 
				 }finally{
					 releaseResource(conn, stmt, rs, sessionid);		 
				 }
			
			return rcb;
		
	}			
}

