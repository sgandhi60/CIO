/* History
 * 2010 Initial creation
 * 05/17/2011 FSW: Defect 170553, Add EmpHoursByMsgId to be used for paycheck
 * 05/22/2011 FSW: Change to defect 170553, Need to check 'location' not 'deptid', so
 * 		need to add new 'location' field to employee 
*/
package com.ibm.ivr.cvs.data;

import java.util.ArrayList;
import java.sql.Date;

public class Employee {
	       //
	       // Authentication
	       //
	public String employeeID = null;                 // Employee ID
	public String employeeSSN = null;  
	public String employeeDOB = null;                // MMddyyy
	public String employmentStatus = null;           // A = Active
	                                                 // L = Leave
	                                                 // P = Leave Without Pay
	                                                 // S = Suspended
    public String isAuthenticated = "false";         // Has the caller been authenticated
	public String departmentID = null; 
	public String jobDescription = null;
	public String employeeState = null;              //  Need state in the event we xfer from GAB
	// public String storenumber = null;             //  Removed 9-16-2010 departmentID will be used in its place
	//170553
	public String employeeLocation = null;           // Used to determine if corporate employee or distribution

	//
	    // Vacation
	    //
    public String vacAllocatedHours = null;    
    public String vacUsedHours = null;    
    public String vacEarnedHours = null;   
    
        //
        // Paycheck
        //
	public String calendarPayEndDate = null;           // MMddyyyy 
	public ArrayList<String>  empPayEndDates = null;   // MMddyyyy
	public String empPayEndDate = null;                // MMddyyyy   Used to play from XML
	public ArrayList<String> empPayAmount = null;  
	public ArrayList<String> empPayCodeMsgId = null;  
	public ArrayList<String> empDeptId = null;   
	public ArrayList<String> empPayCodeMsgIdUnique = null;  
	public ArrayList<String> empPayAmountByMsgId = null;
	public ArrayList<String> empPayHours = null;  
	public String empNetPayAmount = null;  
	public String empPayGroup = null;
	
	    //
	    //LOA 
	    //
	        // CURRENT  
	public String curLoaLastDateAtWork = null;      //MMddyyyy 
	public String curLoaReturnDateToWork = null;    //MMddyyyy  
	
	        // NEW
	public String newLoaType = null; 
	//public String newLoaLastDateAtWork = null;      //MMddyyyy
	public String newLoaReturnDateToWork = null;    //MMddyyyy
	public String newLoaReason = null;  
	public String newLoaReason2 = null;   
	public String newLoaSubReason = null;  
	public String newLoaMilitaryLeave = null;   
	public String newLoaWorkRelatedLeave = null;   
	// public String newLoaEmailAddr = null;  
	// public Byte[] newLoaRecording = null;   
	       // INTERMITTENT
	public String intermittentLoaDate = null;		  // MMddyyyy
	public String intermittentLoaReason = null;  
	public String intermittentLoaHoursMinutes = null;
	
	       // LOA Insert  (Data Saved for later use.. not used by XML
	public int rowNum = 0;               // Current latest row of the database
	public String address1 = null;
	public String city = null;
	public String loaState = null;       //save here and don't override employeeState
	public String loaStatus = null;	     //save here and don't override employmentStatus
	public String postal = null;
	public String fullTimeDate = null;   // MMddyyyy  Date employee became full time
	public Float  stdHours = null;
	public String reason = null;
	public String reason2 = null;
	public String type = null;
	public String military = null;
	public String workRelated = null;
	public String subReason = null;
	public String fullName = null;
	//public String intermittentLoaMinutes = null;
	
	    //
	    // Manager Status
	    //
	 public String deliveryCheckDate = null;           // MMddyyyy
	 public String deliveryType = null;        
	 public String deliveryTrackingNum = null;  
	
	    // 
	    // Shrink Certification
	    //
	//public String shrinkCurPercent = null;
    //public String shrinkGoalPercent = null;
    public String shrinkQuizCompleted = null;
    public int    numberOfTries = 0;

	public String getEmployeeID() {
		return employeeID;
	}

	public void setEmployeeID(String employeeID) {
		this.employeeID = employeeID;
	}

	public String getEmployeeSSN() {
		return employeeSSN;
	}

	public void setEmployeeSSN(String employeeSSN) {
		this.employeeSSN = employeeSSN;
	}

	public String getEmployeeDOB() {
		return employeeDOB;
	}

	public void setEmployeeDOB(String employeeDOB) {
		this.employeeDOB = employeeDOB;
	}

	public String getEmploymentStatus() {
		return employmentStatus;
	}

	public void setEmploymentStatus(String employmentStatus) {
		this.employmentStatus = employmentStatus;
	}

    public String getEmployeeState() {
		return employeeState;
	}

	public void setEmployeeState(String employeeState) {
		this.employeeState = employeeState;
	}
	
	public String getIsAuthenticated() {
		return isAuthenticated;
	}

	public void setIsAuthenticated(String isAuthenticated) {
		this.isAuthenticated = isAuthenticated;
	}

	public String getDepartmentID() {
		return departmentID;
	}

	public void setDepartmentID(String departmentID) {
		this.departmentID = departmentID;
	}

	public String getJobDescription() {
		return jobDescription;
	}

	public void setJobDescription(String jobDescription) {
		this.jobDescription = jobDescription;
	}

	public String getVacAllocatedHours() {
		return vacAllocatedHours;
	}

	public void setVacAllocatedHours(String vacAllocatedHours) {
		this.vacAllocatedHours = vacAllocatedHours;
	}

	public String getVacUsedHours() {
		return vacUsedHours;
	}

	public void setVacUsedHours(String vacUsedHours) {
		this.vacUsedHours = vacUsedHours;
	}

	public String getVacEarnedHours() {
		return vacEarnedHours;
	}

	public void setVacEarnedHours(String vacEarnedHours) {
		this.vacEarnedHours = vacEarnedHours;
	}

	public String getCalendarPayEndDate() {
		return calendarPayEndDate;
	}

	public void setCalendarPayEndDate(String calendarPayEndDate) {
		this.calendarPayEndDate = calendarPayEndDate;
	}

	public Object[] getEmpPayEndDates() {
		if (empPayEndDates == null)
			return null;
		else
			return (Object[])empPayEndDates.toArray();
	}

	public void setEmpPayEndDates(ArrayList<String> empPayEndDates) {
		this.empPayEndDates = empPayEndDates;
	}

	public String getEmpPayEndDate() {
		return empPayEndDate;
	}

	public void setEmpPayEndDate(String empPayEndDate) {
		this.empPayEndDate = empPayEndDate;
	}

	public Object[] getEmpPayAmount() {
		if (empPayAmount == null)
			return null;
		else
			return (Object[])empPayAmount.toArray();
	}

	public void setEmpPayAmount(ArrayList<String> empPayAmount) {
		this.empPayAmount = empPayAmount;
	}

	public Object[] getEmpPayCodeMsgId() {
		if (empPayCodeMsgId == null)
			return null;
		else
			return (Object[])empPayCodeMsgId.toArray();
	}

	public void setEmpPayCodeMsgId(ArrayList<String> empPayCodeMsgId) {
		this.empPayCodeMsgId = empPayCodeMsgId;
	}

	public Object[] getEmpDeptId() {
		if (empDeptId == null)
			return null;
		else
			return (Object[])empDeptId.toArray();
	}

	public void setEmpDeptId(ArrayList<String> empDeptId) {
		this.empDeptId = empDeptId;
	}

	public Object[] getEmpPayCodeMsgIdUnique() {
		if (empPayCodeMsgIdUnique == null)
			return null;
		else
			return (Object[])empPayCodeMsgIdUnique.toArray();
	}

	public void setEmpPayCodeMsgIdUnique(ArrayList<String> empPayCodeMsgIdUnique) {
		this.empPayCodeMsgIdUnique = empPayCodeMsgIdUnique;
	}

	public Object[] getEmpPayAmountByMsgId() {
		if (empPayAmountByMsgId == null)
			return null;
		else
			return (Object[])empPayAmountByMsgId.toArray();
	}

	public void setEmpPayAmountByMsgId(ArrayList<String> empPayAmountByMsgId) {
		this.empPayAmountByMsgId = empPayAmountByMsgId;
	}

	public String getEmpNetPayAmount() {
		return empNetPayAmount;
	}

	public void setEmpNetPayAmount(String empNetPayAmount) {
		this.empNetPayAmount = empNetPayAmount;
	}

	public String getEmpPayGroup() {
		return empPayGroup;
	}

	public void setEmpPayGroup(String empPayGroup) {
		this.empPayGroup = empPayGroup;
	}

	public Object[] getEmpPayHours() {
		if (empPayHours == null)
			return null;
		else
			return (Object[])empPayHours.toArray();
	}

	public void setEmpPayHours(ArrayList<String> empPayHours) {
		this.empPayHours = empPayHours;
	}
	
	public String getCurLoaLastDateAtWork() {
		return curLoaLastDateAtWork;
	}

	public void setCurLoaLastDateAtWork(String curLoaLastDateAtWork) {
		this.curLoaLastDateAtWork = curLoaLastDateAtWork;
	}

	public String getCurLoaReturnDateToWork() {
		return curLoaReturnDateToWork;
	}

	public void setCurLoaReturnDateToWork(String curLoaReturnDateToWork) {
		this.curLoaReturnDateToWork = curLoaReturnDateToWork;
	}

	public String getNewLoaType() {
		return newLoaType;
	}

	public void setNewLoaType(String newLoaType) {
		this.newLoaType = newLoaType;
	}

	public String getNewLoaReturnDateToWork() {
		return newLoaReturnDateToWork;
	}

	public void setNewLoaReturnDateToWork(String newLoaReturnDateToWork) {
		this.newLoaReturnDateToWork = newLoaReturnDateToWork;
	}

	public String getNewLoaReason() {
		return newLoaReason;
	}

	public void setNewLoaReason(String newLoaReason) {
		this.newLoaReason = newLoaReason;
	}

	public String getNewLoaReason2() {
		return newLoaReason2;
	}

	public void setNewLoaReason2(String newLoaReason2) {
		this.newLoaReason2 = newLoaReason2;
	}

	public String getNewLoaSubReason() {
		return newLoaSubReason;
	}

	public void setNewLoaSubReason(String newLoaSubReason) {
		this.newLoaSubReason = newLoaSubReason;
	}

	public String getNewLoaMilitaryLeave() {
		return newLoaMilitaryLeave;
	}

	public void setNewLoaMilitaryLeave(String newLoaMilitaryLeave) {
		this.newLoaMilitaryLeave = newLoaMilitaryLeave;
	}

	public String getNewLoaWorkRelatedLeave() {
		return newLoaWorkRelatedLeave;
	}

	public void setNewLoaWorkRelatedLeave(String newLoaWorkRelatedLeave) {
		this.newLoaWorkRelatedLeave = newLoaWorkRelatedLeave;
	}

	public String getIntermittentLoaDate() {
		return intermittentLoaDate;
	}

	public void setIntermittentLoaDate(String intermittentLoaDate) {
		this.intermittentLoaDate = intermittentLoaDate;
	}

	public String getIntermittentLoaReason() {
		return intermittentLoaReason;
	}

	public void setIntermittentLoaReason(String intermittentLoaReason) {
		this.intermittentLoaReason = intermittentLoaReason;
	}

	public String getIntermittentLoaHoursMinutes() {
		return intermittentLoaHoursMinutes;
	}

	public void setIntermittentLoaHoursMinutes(String intermittentLoaHoursMinutes) {
		this.intermittentLoaHoursMinutes = intermittentLoaHoursMinutes;
	}

	public String getDeliveryType() {
		return deliveryType;
	}

	public void setDeliveryType(String deliveryType) {
		this.deliveryType = deliveryType;
	}

	public String getDeliveryTrackingNum() {
		return deliveryTrackingNum;
	}

	public void setDeliveryTrackingNum(String deliveryTrackingNum) {
		this.deliveryTrackingNum = deliveryTrackingNum;
	}

	public String getShrinkQuizCompleted() {
		return shrinkQuizCompleted;
	}

	public void setShrinkQuizCompleted(String shrinkQuizCompleted) {
		this.shrinkQuizCompleted = shrinkQuizCompleted;
	}

	public int getNumberOfTries() {
		return numberOfTries;
	}

	public void setNumberOfTries(int numberOfTries) {
		this.numberOfTries = numberOfTries;
	}

	public String getDeliveryCheckDate() {
		return deliveryCheckDate;
	}

	public void setDeliveryCheckDate(String deliveryCheckDate) {
		this.deliveryCheckDate = deliveryCheckDate;
	}

	public int getRowNum() {
		return rowNum;
	}

	public void setRowNum(int rowNum) {
		this.rowNum = rowNum;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getPostal() {
		return postal;
	}

	public void setPostal(String postal) {
		this.postal = postal;
	}

	public String getFullTimeDate() {
		return fullTimeDate;
	}

	public void setFullTimeDate(String fullTimeDate) {
		this.fullTimeDate = fullTimeDate;
	}

	public Float getStdHours() {
		return stdHours;
	}

	public void setStdHours(Float stdHours) {
		this.stdHours = stdHours;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getReason2() {
		return reason2;
	}

	public void setReason2(String reason2) {
		this.reason2 = reason2;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getMilitary() {
		return military;
	}

	public void setMilitary(String military) {
		this.military = military;
	}

	public String getWorkRelated() {
		return workRelated;
	}

	public void setWorkRelated(String workRelated) {
		this.workRelated = workRelated;
	}

	public String getSubReason() {
		return subReason;
	}

	public void setSubReason(String subReason) {
		this.subReason = subReason;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}	
	
	public String getLoaState() {
		return loaState;
	}

	public void setLoaState(String loaState) {
		this.loaState = loaState;
	}

	public String getLoaStatus() {
		return loaStatus;
	}

	public void setLoaStatus(String loaStatus) {
		this.loaStatus = loaStatus;
	}

	public String getEmployeeLocation() {
		return employeeLocation;
	}

	public void setEmployeeLocation(String employeeLocation) {
		this.employeeLocation = employeeLocation;
	}

}
