package com.ibm.ivr.cvs.handler;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

public class DateValidation extends HttpServlet implements Servlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1628090771143421698L;
	private static Logger LOGGER = Logger.getLogger(DateValidation.class);
	/**
     * @see HttpServlet#HttpServlet()
     */
    public DateValidation() {
        super();
        // TODO Auto-generated constructor stub
    }

	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		// get session from Servlet request, created if not existed yet
		HttpSession session = req.getSession(true);
		String callid = (String) session.getAttribute("callid");
		boolean testCall = ((Boolean) session.getAttribute("testCall")).booleanValue();

		//create the log Token for later use, use StringBuffer to reduce number
		// of String objects
		String logToken = new StringBuffer("[").append(callid).append("] ").toString();
			 
		 if (testCall)
		 	LOGGER.debug(new StringBuffer(logToken).append("Entering Handler: DateValidation::"));
		 		 
		// Get  Session variable holding date entered
		String dateEntered = (String) session.getAttribute("LOAdateEntered");

		 if (testCall)
			 	LOGGER.debug(new StringBuffer(logToken).append("Date to validate::")
			 			                               .append(dateEntered));

		// Result of date is valid format and greater than todays date..
		String dateEnteredValid = "false";

		SimpleDateFormat formatter = new SimpleDateFormat("MMddyyyy");
		formatter.setLenient(false);

		try{
			// Format the date entered.  If the format is invalid an exception should be thrown
			// Checking the range of the date an other associated business rules will be done in
			// the XML.  
			Date dateFormatted = formatter.parse(dateEntered);

			// If this date is formatted correctly then set session var to true
			dateEnteredValid = "true";
		}
		catch(Exception ex){
			if (testCall)
			  LOGGER.debug(new StringBuffer(logToken).append(ex.getMessage()));
		}

		// Set session variable for reply
		session.setAttribute("dateEnteredValid", dateEnteredValid);


		 if (testCall){
			 	LOGGER.debug(new StringBuffer(logToken).append("Date::")
			 			                               .append(dateEntered)
			 			                               .append(" is ")
			 			                               .append(dateEnteredValid));
			 	LOGGER.debug(new StringBuffer(logToken).append("Exiting Handler: DateValidation::"));
		 }

		return;
	}
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request,response);
	}

}

