package com.ibm.ivr.cvs.handler;

import java.io.IOException;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.ibm.ivr.cvs.dao.DAOException;
import com.ibm.ivr.cvs.dao.IdentificationDAO;
import com.ibm.ivr.cvs.data.Employee;

/**
 * Searching employeeID in database
 * Input: ssnNumber (from session) 
 * Output: 
 * 		  employee object (into session) if found
 *
 *Revision history:
 * <p>
 * 
 * 2010-09-30: initial version
 * <p>
 * 
 * @author Fang Wang
 * @version 2010-09-30
 *
 */
public class SearchEmployeeSSN extends HttpServlet implements Servlet{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -223884747672211827L;
	
	private static Logger LOGGER = Logger.getLogger(SearchEmployeeSSN.class);

	public void doGet(HttpServletRequest req, HttpServletResponse resp)
							throws ServletException, IOException {

	// get session from Servlet request, created if not existed yet
	HttpSession session = req.getSession(true);
	//Properties prop = (Properties)session.getServletContext().getAttribute("globalProp");

	String callid = (String) session.getAttribute("callid");

	boolean testCall = ((Boolean) session.getAttribute("testCall")).booleanValue();

	//create the log Token for later use, use StringBuffer to reduce number
	// of String objects
	String logToken = new StringBuffer("[").append(callid).append("] ").toString();
		 
	 if (testCall)
	 	LOGGER.debug(new StringBuffer(logToken).append("Entering Handler: SearchEmployeeSSN"));
	
		
    // Get attributes from the session
	String ssn = (String) session.getAttribute("ssnNumber");
	
	if (ssn != null && ssn.trim().length() > 0){
		//calling IdentificationDAO to search SSN and then use the id to search 
		IdentificationDAO iDAO = (IdentificationDAO) session.getServletContext().getAttribute("identificationDAO");
		
		try {
			String id = iDAO.lookupSSN(ssn, callid);
			LOGGER.debug(new StringBuffer(logToken).append("id from ssn: ").append(id));
			if (id != null) {
				Employee employee = iDAO.lookup(id, callid);
				if (employee != null){
					if (testCall){
						String maskedEmpId = null;
						if (employee.getEmployeeID().length() >= 7){
							maskedEmpId = "****"+employee.getEmployeeID().substring(4);
						}else{
							maskedEmpId = "*******";
						}

						LOGGER.debug(new StringBuffer(logToken).append("employee record found for id: ").append(maskedEmpId));
					
					}
					session.setAttribute("employee", employee);
				}
				else
					session.removeAttribute("employee");
			}else{
				session.removeAttribute("employee");
			}
		}catch(DAOException e){
			LOGGER.debug(new StringBuffer(logToken).append("failed SSN search: ").append(e.getMessage()));
		     if (e.getMessage() != null && e.getMessage().equalsIgnoreCase("Failed to connect to DB"))
		    	 session.setAttribute("hRC", "C");
		     else
		    	 session.setAttribute("hRC", "E");			

			session.removeAttribute("employee");
		}
	}
	else {
		LOGGER.warn(new StringBuffer(logToken).append("no ssn is provided to be searched"));
		session.removeAttribute("employee");
	}
   return;
  }
}
