package com.ibm.ivr.cvs.handler;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.util.ArrayList;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.ibm.ivr.cvs.dao.CertificationDAO;
import com.ibm.ivr.cvs.dao.DAOException;
import com.ibm.ivr.cvs.data.Employee;

/**
 * Servlet implementation class GetShrinkQuizStatus
 */
public class GetShrinkQuizStatus extends HttpServlet {
       
    /**
	 * 
	 */
	private static final long serialVersionUID = 215296534903181421L;
	private static Logger LOGGER = Logger.getLogger(GetShrinkQuizStatus.class);

	/**
     * @see HttpServlet#HttpServlet()
     */
    public GetShrinkQuizStatus() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	@SuppressWarnings("unchecked")
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		// get session from Servlet request, created if not existed yet
		HttpSession session = request.getSession(true);
		String callid = (String) session.getAttribute("callid");
		boolean testCall = ((Boolean) session.getAttribute("testCall")).booleanValue();

		//create the log Token for later use, use StringBuffer to reduce number
		// of String objects
		String logToken = new StringBuffer("[").append(callid).append("] ").toString();
			 
		 if (testCall)
		 	LOGGER.debug(new StringBuffer(logToken).append("Entering Handler: GetShrinkQuizStatus with command::")
		 			                               .append(session.getAttribute("certCmd")));
		 
		 boolean statusResult = false;
		 String hRC = "S";
		 
		 // certCmd  ( getStatus  updateStatus getQuestions  checkAnswer)
		 String certCmd = (String) session.getAttribute("certCmd");
		 
		 Employee employee = (Employee) session.getAttribute("employee");
		 String storeNumberEntered = (String) session.getAttribute("storeNumberEntered");
		 
		 //stripping off leading zeros
		 if (storeNumberEntered.startsWith("0") && storeNumberEntered.length() > 1){
			 boolean nf = false;
			 for(int i = 1; i <= storeNumberEntered.length() -1 ; i++){
				 if (storeNumberEntered.charAt(i) != '0'){
					 nf = true;
					 storeNumberEntered = storeNumberEntered.substring(i);
					 session.setAttribute("storeNumberEntered", storeNumberEntered);
					 break;
				 }
			 }
			 if (!nf) {
				 storeNumberEntered = "0";
				 session.setAttribute("storeNumberEntered", storeNumberEntered);
			 }
		 }
		 
		 String quizNumberEntered = (String) session.getAttribute("quizNumberEntered");
		 //CertificationDAO certDAO = new CertificationDAO(prop.getProperty("jndiName"));
		 CertificationDAO certDAO = (CertificationDAO)session.getServletContext().getAttribute("certificationDAO");

		 if (testCall){
			 String maskedEmpId = null;
			if (employee.getEmployeeID().length() >= 7){
				maskedEmpId = "****"+employee.getEmployeeID().substring(4);
			}else{
				maskedEmpId = "*******";
			}

		 	LOGGER.debug(new StringBuffer(logToken).append("storeNumberEntered::")
                    .append(storeNumberEntered)
                    .append("  quizNumberEntered::")
                    .append(quizNumberEntered)
                    .append("  employee.employeeID::")
                    .append(maskedEmpId)
                    .append("  Quiz Result for update::")
                    .append(session.getAttribute("quizResult")));
	     }	 
		 
		 if (certCmd.trim().equalsIgnoreCase("getStatus")){		 
		   try{
			   // No reason to check statusResult.  If not true the only reason false is returned
			   // is because no record was found for ID+STORE+QUIZ   XML checks the employee class
			   // to see if the quiz has been previously passed.
			   statusResult = certDAO.getQuizStatus(employee, quizNumberEntered, storeNumberEntered, callid);

		   }catch (DAOException de){
		     LOGGER.error(new StringBuffer(logToken).append("Exception getting quiz status::"+de.toString()));
		     if (de.getMessage() != null && de.getMessage().equalsIgnoreCase("Failed to connect to DB"))
		    	 hRC = "C";
		     else
	            hRC = "E";
		   }
		 }else if (certCmd.trim().equalsIgnoreCase("updateStatus")){
			 String quizStatus = (String) session.getAttribute("quizResult");			 
			   try{
				   if(!certDAO.updateQuizStatus(employee, quizNumberEntered, storeNumberEntered, quizStatus, callid)){
					   LOGGER.error(new StringBuffer(logToken).append("Error updating Quiz Status:: Check Application Logs"));					   
					   hRC = "E";
				   }
			   }catch (DAOException de){
			     LOGGER.error(new StringBuffer(logToken).append("Exception updating quiz status::"+de.toString()));
			     if (de.getMessage() != null && de.getMessage().equalsIgnoreCase("Failed to connect to DB"))
			    	 hRC = "C";
			     else
		            hRC = "E";
			   }			 
		 }else if (certCmd.trim().equalsIgnoreCase("getQuestions")){
			 Properties certificationProp = (Properties)session.getServletContext().getAttribute("certificationProp");
			 Properties shrinkQuizProp = (Properties)session.getServletContext().getAttribute("shrinkQuizProp");
			 
			 try{
				 int maxAnswers = Integer.parseInt(certificationProp.getProperty("maxPossibleShrinkAnswersPerQ"));
				 ArrayList<String> answers = new ArrayList<String>();
				 
				 // Adjust Question asked to match the subscript of the answer
				 answers.add(0,"Position-Not-Used");
				 
				 int i = 1;
				 String qExists = null;
				 
				 // Collect the answer for the first quiz question
				 qExists = shrinkQuizProp.getProperty("Q"+String.valueOf(i)+"_"+quizNumberEntered.trim());
				 while (qExists != null){        
					 
					// Example Answer format::  Q1_104
					// Logging
					 if (testCall)
						 	LOGGER.debug(new StringBuffer(logToken).append("Question::")
						 			                               .append("Q"+String.valueOf(i)+"_"+quizNumberEntered.trim())
						 			                               .append("  Answer::")					
						 			                               .append(qExists));
					 // Save the answer in the corresponding Array position
					 answers.add(i,qExists.trim());
					 i++;
					 // Get next quiz answer (If it exists)
					 qExists = shrinkQuizProp.getProperty("Q"+String.valueOf(i)+"_"+quizNumberEntered.trim());
				 }
				 
				 // Set max answer choices allowed. This is used by the XML to determine if a choice should be created.
				 session.setAttribute("maxAnswers", Integer.valueOf(maxAnswers));
				 // Save the correct answers in the session to compare the callers responses against.
				 session.setAttribute("answers", answers);
				 if (answers.size() <= 1){
					 // No answer entries were found for the quiz number provided.
					 session.setAttribute("askQ", "E");					 
				 }else{
					 // At least one quize answer was found so the quiz can begin.
					 session.setAttribute("askQ", "S");
				}
				 
				 // Logging
				 if (testCall){
					 	LOGGER.debug(new StringBuffer(logToken).append("totalShrinkQuestions::")
					 			                               .append(answers.size())
					 			                               .append("  askQ::")
					 			                               .append(session.getAttribute("askQ")));
					 	if (answers.size() > 1){
					 		for (int x = 1; x <  answers.size(); x++){
					 		LOGGER.debug(new StringBuffer(logToken).append("Question #")
					 				                               .append(x)
					 				                               .append("::")
					 				                               .append(answers.get(x)));
					 		}
					 	}
				 }
			 }catch(NumberFormatException ex){
				     // ParseInt exception
				     LOGGER.error(new StringBuffer(logToken).append("Exception getQuestions::"+ex.toString()));
			         hRC = "E";				 
			 }
		 }else if (certCmd.trim().equalsIgnoreCase("checkAnswer")){
			 int questionNumberToAnnounce = Integer.parseInt((String)session.getAttribute("questionNumberToAnnounce"));
			 int answerSupplied = Integer.parseInt((String)session.getAttribute("answerSupplied"));
			 ArrayList<String> answers = (ArrayList<String>)session.getAttribute("answers");

			 try{
				 // Get the correct answer from the Array based on the quiz question asked.
				 int correctAnswer = Integer.valueOf((String)answers.get(questionNumberToAnnounce));
	
				 // See if the answer is correct.  quizResult is set to P (passed) in XML as the default.
				 if (answerSupplied != correctAnswer)
					 session.setAttribute("quizResult", "N");  // Missed a question so they fail the quiz
				                                               // but the remaining answers will be collected
				                                               // and checked.  The caller will be informed of the 
				                                               // failure at the end of the test.
	
				 // Logging
				 if (testCall)
					 	LOGGER.debug(new StringBuffer(logToken).append("Question Announced::")
					 			                               .append(questionNumberToAnnounce)
					 			                               .append("  answerSupplied::")
					 			                               .append(answerSupplied)
   					 			                               .append("  correctAnswer::")
					 			                               .append(correctAnswer)
					 			                               .append("  quizResult::")
					 			                               .append(session.getAttribute("quizResult")));
					 
				 // Determine if there is another question to offer the caller
				 // Need to adjust the answers.size() value since slot 0 is a dummy position.
				 questionNumberToAnnounce++;
				 if (questionNumberToAnnounce > (answers.size()-1)){
					 // All answers have been collected.  Set to D marking that that all quiz Q's answers have been collected
					 session.setAttribute("askQ", "D"); 
				 }else{
					 // Set to S marking that there is another answer to collect.
					 session.setAttribute("askQ", "S");
					 // Set the question number into the session to be played by the XML to the caller.
					 session.setAttribute("questionNumberToAnnounce", String.valueOf(questionNumberToAnnounce));
				 }
	
				 // Logging
				 if (testCall)
					 	LOGGER.debug(new StringBuffer(logToken).append("Next Question (if there is one) to Announce::")
					 			                               .append(questionNumberToAnnounce)
					 			                               .append("  askQ::")
					 			                               .append(session.getAttribute("askQ")));
		 
			 }catch(NumberFormatException ex){
				 // Parse Int exception
			     LOGGER.error(new StringBuffer(logToken).append("Exception checkAnswer::"+ex.toString()));
		         hRC = "E";				 
		 } 			 
		 }else{
			 // Invalid certCmd sipplied by the XML
			 hRC = "E";
			 LOGGER.error(new StringBuffer(logToken).append("Invalid certifiaction command::"+certCmd));
		 }
		 
		 // Store the handler processing result
		 session.setAttribute("hRC", hRC);
		 
		 if (testCall)
			 	LOGGER.debug(new StringBuffer(logToken).append("Leaving Handler: GetShrinkQuizStatus::")
			 			                               .append("  hRC::")
			 			                               .append(session.getAttribute(hRC)));	
	 return;
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request,response);
	}

}
