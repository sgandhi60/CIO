package com.ibm.ivr.cvs.handler;

import java.io.IOException;
import java.util.Calendar;
import java.util.Properties;
import java.util.TimeZone;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.ibm.ivr.framework.utilities.Common;

/**
 * Check cvs.properties to see if EZPayroll menu available
 * Input: cvsProp from servlet context
 * Output: 
 * 		 ezPayrollAvailable String object in the session
 *
 *Revision history:
 * <p>
 * 
 * 2010-10-26: initial version
 * <p>
 * 
 * @author Fang Wang
 * @version 2010-10-26
 *
 */
public class CheckEZPayrollAvailability extends HttpServlet implements Servlet{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4068695126007870070L;
	
	private static Logger LOGGER = Logger.getLogger(CheckEZPayrollAvailability.class);
	
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
							throws ServletException, IOException {

	// get session from Servlet request, created if not existed yet
	HttpSession session = req.getSession(true);
	//Properties prop = (Properties)session.getServletContext().getAttribute("globalProp");

	String callid = (String) session.getAttribute("callid");

	boolean testCall = ((Boolean) session.getAttribute("testCall")).booleanValue();

	//create the log Token for later use, use StringBuffer to reduce number
	// of String objects
	String logToken = new StringBuffer("[").append(callid).append("] ").toString();
		 
	 if (testCall)
	 	LOGGER.debug(new StringBuffer(logToken).append("Entering Handler: CheckEZPayrollAvailability"));
	
	Properties cvsProp = (Properties) session.getServletContext().getAttribute("cvsProp");
	Properties globalProp = (Properties) session.getServletContext().getAttribute("globalProp");
	
	try {
		
		String timeZone = globalProp.getProperty("timeZone");
		String start = cvsProp.getProperty("HRProcStartDayHour");
		String end = cvsProp.getProperty("HRProcEndDayHour");
	
		Calendar calNow = null;
		if (timeZone == null)
			calNow = Calendar.getInstance();
		else
			calNow = Calendar.getInstance(TimeZone.getTimeZone(timeZone));

		int hourNow = calNow.get(Calendar.HOUR_OF_DAY);
		int minNow = calNow.get(Calendar.MINUTE);
		int timeToday = (hourNow * 60) + minNow;
		
		int dayOfWeek = calNow.get(Calendar.DAY_OF_WEEK);
		
		String startDay = start.substring(0,3);
		String endDay = end.substring(0,3);
		String startHour = start.substring(4,6);
		String endHour = end.substring(4,6);
		String startMinute = start.substring(6);
		String endMinute = end.substring(6);

		int startTime = (Integer.valueOf(startHour).intValue() * 60) + Integer.valueOf(startMinute).intValue();
		int endTime = (Integer.valueOf(endHour).intValue() * 60) + Integer.valueOf(endMinute).intValue();
		
		boolean afterStart = false;
		if (compare(startDay, dayOfWeek) == 0) {
			if (timeToday >= startTime)
				afterStart = true;
			else
				afterStart = false;
		}else if (compare(startDay, dayOfWeek) < 0) {
			afterStart = true;
		}else{
			afterStart = false;
		}
			
		boolean beforeEnd = false;
		if (compare(endDay, dayOfWeek) == 0) {
			if (timeToday <= endTime)
				beforeEnd = true;
			else
				beforeEnd = false;
		}else if (compare(endDay, dayOfWeek) > 0) {
			beforeEnd = true;
		}else{
			beforeEnd = false;
		}			
		
		if (afterStart && beforeEnd)//if within the time range the HR process is running
			session.setAttribute("ezPayrollAvailable", Common.FALSE);
		else
			session.setAttribute("ezPayrollAvailable", Common.TRUE);
		
	}catch(Exception e){
		LOGGER.debug(new StringBuffer(logToken).append("failed to parse the start/end time in cvs.properties: ").append(e.getMessage()));
		session.setAttribute("ezPayrollAvailable", Common.FALSE);
	}

   return;
  }
	
/**
 * compare day1 and day2, 
 * @param day1
 * @param day2
 * @return 0 if on the same day of week, 
 * 		   1 if day2 is before day1 in the week
 * 		  -1 if day2 is after day1 in the week
 */
  private int compare(String day1, int day2){
	  int value = 0;
	  if (day1.equalsIgnoreCase("MON")){
		  if (day2 == 2) value = 0;
		  else if (day2 > 2) value = -1;
		  else value = 1;
	  }else if (day1.equalsIgnoreCase("TUE")){
		  if (day2 == 3) value = 0;
		  else if (day2 > 3) value = -1;
		  else value = 1;
	  }else if (day1.equalsIgnoreCase("WED")){
		  if (day2 == 4) value = 0;
		  else if (day2 > 4) value = -1;
		  else value = 1;
	  }else if (day1.equalsIgnoreCase("THU")){
		  if (day2 == 5) value = 0;
		  else if (day2 > 5) value = -1;
		  else value = 1;
	  }else if (day1.equalsIgnoreCase("FRI")){
		  if (day2 == 6) value = 0;
		  else if (day2 > 6) value = -1;
		  else value = 1;
	  }else if (day1.equalsIgnoreCase("SAT")){
		  if (day2 == 7) value = 0;
		  else if (day2 > 7) value = -1;
		  else value = 1;
	  }else if (day1.equalsIgnoreCase("SUN")){
		  if (day2 == 1) value = 0;
		  else if (day2 > 1) value = -1;
		  else value = 1;
	  }
	  return value;
  }
}
