/* History
 * 11/12/2010 FSW: Initial creation 
 * 11/12/2010 FSW: Save data returned from getLOAByDate to use in updateLOA.
 *                 Avoids additional query.
 * 12/03/2010 FSW: Modify message for DAOException for no DB connection 
 * 01/10/2011 FSW: Defect 170295 Remove logging of personal data, defect
 * 				   Also remove any unused variables
 * 01/24/2011 FSW: Add sessionid to logging.  Defect 170371
 * 01/25/2011 FSW: Add query timeout.  Defect 170321
 * 02/26/2011 FSW: UpdateLoa(), change logging statement for currentQuery, change query when
 * 					c_full_time_dt is null.  Defect 170487
 * 03/03/2011 FSW: Defect 170502 CreateLOA(), on exception, check to see if it is "unique constraint'
 * 					exception and handle differently.  Also correct logging of row_num for Exception
 */

package com.ibm.ivr.cvs.dao;

import com.ibm.ivr.cvs.dao.BaseDAO;
import com.ibm.ivr.cvs.data.Employee;

//import java.io.PrintWriter;
//import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

//import java.sql.Types;
import org.apache.log4j.Logger;


	public class LoaDAO extends BaseDAO{
		
	private final static Logger LOGGER = Logger.getLogger(LoaDAO.class);
	
	//private Connection conn = null; Defect 170481, move to methods
	private String jndiName = null;
	
	private final static String SQL_QUERY_LOA_BY_DATE = "SELECT LAST_DATE_WORKED, " +
			"TO_CHAR(EXPECTED_RETURN_DT,'MMDDYYYY'), " +	
			"ROW_NUM, NAME, ADDRESS1, CITY, STATE, POSTAL, TO_CHAR(C_FULL_TIME_DT,'MMDDYYYY'), STD_HOURS, " +
			"C_LOA_REASON, C_MILITARY_LEAVE, " +
			"C_WORK_RELATED, C_LOA_REASON2, C_LOA_SUB_REASON " +
			"FROM PS_C_LOA_IVR_TBL " +
			"WHERE EMPLID =  ? " +
			"AND to_char(LAST_DATE_WORKED,'MMDDYYYY') = ? " +
			"ORDER BY ROW_NUM DESC";

	
	private final static String SQL_QUERY_ELIG_STD1 = "SELECT A.EMPLID, A.ELIG_CONFIG2 " +
			"FROM SYSADM.PS_JOB A " +
			"WHERE A.EMPLID = ? " +
			"AND A.ELIG_CONFIG2 IN ('HI','NY') " +
			"AND A.EFFDT = (SELECT MAX(A_ED.EFFDT) " +
			"FROM SYSADM.PS_JOB A_ED " +
			"WHERE A.EMPLID = A_ED.EMPLID  " +
			"AND A.EMPL_RCD = A_ED.EMPL_RCD  " +
			"AND A_ED.EFFDT  <= SYSDATE) " +
			"AND A.EFFSEQ = (SELECT MAX(A_ES.EFFSEQ) " +
			"FROM SYSADM.PS_JOB A_ES " +
			"WHERE A.EMPLID = A_ES.EMPLID " +
			"AND A.EMPL_RCD = A_ES.EMPL_RCD " +
			"AND A.EFFDT = A_ES.EFFDT)";

	private final static String SQL_QUERY_ELIG_STD2 = "SELECT A.EMPLID, A.PAYGROUP, " +
			"A.C_FULL_TIME_DT " +
			"FROM IVR_O.PS_C_EA_1_VW A " +
			"WHERE A.EMPLID = ? " +
			"AND A.PAYGROUP = ? " +
			"AND A.C_FULL_TIME_DT <= (SYSDATE - 90)";

	private final static String SQL_QUERY_ELIG_STD3 = "SELECT DIS.EMPLID, " +
			"DIS.COVERAGE_BEGIN_DT, DIS.COVERAGE_ELECT, DIS.PLAN_TYPE " +
			"FROM SYSADM.PS_DISABILITY_BEN DIS " +
			"WHERE DIS.EMPLID = ? " +
			"AND DIS.PLAN_TYPE IN ('30','3Z') " +
			"AND DIS.COVERAGE_ELECT = 'E' " +
			"AND DIS.COVERAGE_BEGIN_DT = (SELECT MAX(DIS_ED.COVERAGE_BEGIN_DT) " +
			"FROM SYSADM.PS_DISABILITY_BEN DIS_ED " +
			"WHERE DIS_ED.EMPLID = DIS.EMPLID " +
			"AND DIS_ED.EMPL_RCD = DIS.EMPL_RCD " +
			"AND DIS_ED.PLAN_TYPE = DIS.PLAN_TYPE " +
			"AND  DIS_ED.COVERAGE_BEGIN_DT <= SYSDATE)";

	//following no longer used 
	/*private final static String SQL_QUERY_UPDATE_LOA = "SELECT ROW_NUM, NAME, " +
			"ADDRESS1, CITY, STATE, POSTAL, C_FULL_TIME_DT, STD_HOURS," +
			"LAST_DATE_WORKED, EXPECTED_RETURN_DT, C_LOA_REASON, C_MILITARY_LEAVE, " +
			"C_WORK_RELATED, C_LEAVE_TYPE, C_LOA_REASON2, C_LOA_SUB_REASON " +
			"FROM PS_C_LOA_IVR_TBL " +
			"WHERE EMPLID = ? " +
			"AND to_char(LAST_DATE_WORKED,'MMDDYYYY') = ? " +
			"ORDER BY ROW_NUM DESC";
	*/
	
	private final static String SQL_UPDATE_LOA = "INSERT INTO SYSADM.PS_C_LOA_IVR_TBL " +
	"(EMPLID, ROW_NUM, NAME, ADDRESS1, CITY, STATE, POSTAL, " +
	"EMPL_STATUS, C_FULL_TIME_DT, STD_HOURS, LAST_DATE_WORKED, EXPECTED_RETURN_DT," +
	"C_NEW_EXP_RET_DT, C_LEAVE_TYPE, C_LOA_REASON, C_MILITARY_LEAVE, C_WORK_RELATED," +
	"C_LOA_REASON2, C_LOA_SUB_REASON, C_EXTRACTED) " +
	"VALUES (?,?,?,?,?,?,?,?," +
	"TO_DATE('fullTimeDate','MMDDYYYY'), " +
	"?," +
	"TO_DATE('lastDateWorked','MMDDYYYY')," +
	"TO_DATE('expectedReturnDate','MMDDYYYY'), " +
	"TO_DATE('newReturnDate','MMDDYYYY')," +
	"?,?,?,?,?,?,?)"; 	
	
	private final static String SQL_INSERT_NEW_LOA = "INSERT INTO SYSADM.PS_C_LOA_IVR_TBL " +
		"(EMPLID, ROW_NUM, NAME, ADDRESS1, CITY, STATE, POSTAL, " +
		"EMPL_STATUS, C_FULL_TIME_DT, STD_HOURS, LAST_DATE_WORKED, EXPECTED_RETURN_DT, " +
		"C_LEAVE_TYPE, C_LOA_REASON, C_MILITARY_LEAVE, C_WORK_RELATED," +
		"C_LOA_REASON2, C_LOA_SUB_REASON, C_EXTRACTED) " +
		"VALUES (?,?,?,?,?,?,?,?,?,?," +
    	"TO_DATE('lastDateWorked','MMDDYYYY')," +
    	"TO_DATE('returnWorkDate','MMDDYYYY')," +
    	"?,?,?,?,?,?,?)";
	
	private final static String SQL_QUERY_CREATE_LOA = "SELECT NAME, ADDRESS1, CITY, " +
			"STATE, POSTAL, C_FULL_TIME_DT, STD_HOURS " +
			"FROM SYSADM.PS_C_EA_1_VW " +
			"WHERE EMPLID = ?";

	private final static String SQL_INSERT_INTRMT_LOA = "INSERT INTO sysadm.ps_c_intr_ivr_tbl " +
			"(EMPLID, C_INTR_IVR_DT, C_INTR_IVR_HRS, C_INTR_IVR_REASON, C_DATE_CALLED, C_EXTRACTED ) " +
			"VALUES (?, TO_DATE('intrDate','MMDDYYYY'), ? , ?, SYSDATE, ?)"; 
	
	private int sqlTimeout = 0;  //timeout for stmt execution in secs

	/********************************************************************************
	* Constructor
	/********************************************************************************/	
	public LoaDAO (String jndiName, int timeout) {
		// initialization
		this.jndiName = jndiName;
		this.sqlTimeout = timeout;
	
		LOGGER.debug("******** Created LoaDAO ********");
		LOGGER.debug(new StringBuffer("-- jndiName = ").append(jndiName));
	}

	/********************************************************************************
	* Get Leave of Absence Dates
	/********************************************************************************/
	public boolean getLoaByDate(Employee employeeData, String lastWorkDate, String sessionid)throws DAOException {
		
		Connection conn = null;
		String employeeId = employeeData.employeeID;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String currentQuery = null;
		boolean rcb = true;
		
		String logToken = new StringBuffer("[").append(sessionid).append("] ").toString();	
		LOGGER.debug(new StringBuffer(logToken).append("********Entering LoaDAO::getLOAByDate********"));
		LOGGER.debug(new StringBuffer(logToken).append(" -- emplid = ").append(employeeId.substring(employeeId.length()-3,employeeId.length())));
		LOGGER.debug(new StringBuffer(logToken).append(" -- lastWorkDate = ").append(lastWorkDate));
		 
		//Connect to the DB	
		try {
			conn = getConnection(jndiName,sessionid);
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer(logToken).append("Exception getting a connection to the DB: ").append(e.getMessage()));
			throw new DAOException("Failed to connect to DB");
		}
		//get information
		try {			
			if (conn!=null){				
						
				// get dates and personal info 11/12/2010
				//SQL_QUERY_LOA_BY_DATE = "SELECT LAST_DATE_WORKED, " +
				//"TO_CHAR(EXPECTED_RETURN_DT,'MMDDYYYY'), " +	
				//"ROW_NUM, NAME, ADDRESS1, CITY, STATE, POSTAL, TO_CHAR(C_FULL_TIME_DT, 'MMDDYYYY'),STD_HOURS " +
				//"FROM PS_C_LOA_IVR_TBL " +
				//"WHERE EMPLID =  ? " +
				//"AND to_char(LAST_DATE_WORKED,'MMDDYYYY') = ? " +
				//"ORDER BY ROW_NUM DESC";
				
				currentQuery = SQL_QUERY_LOA_BY_DATE;				 
				stmt = conn.prepareStatement(currentQuery);
				stmt.setQueryTimeout(sqlTimeout);
				stmt.setString(1,employeeId);
				stmt.setString(2,lastWorkDate);
				
	            LOGGER.debug(new StringBuffer(logToken).append("Executing query: ").append(currentQuery));
	             LOGGER.debug(new StringBuffer(logToken).append(" -- EMPLID = ").append(employeeId.substring(employeeId.length()-3,employeeId.length())));
				 LOGGER.debug(new StringBuffer(logToken).append(" -- LAST_DATE_WORKED = ").append(lastWorkDate));
				 
				rs = stmt.executeQuery();
				
	            if (rs.next()){		        	 
	            	employeeData.setCurLoaLastDateAtWork(lastWorkDate);
	            	employeeData.setCurLoaReturnDateToWork(rs.getString(2)); 	 
	            	//save following data for update
	            	employeeData.setRowNum(rs.getInt(3));
	            	employeeData.setFullName(rs.getString(4));
	            	employeeData.setAddress1(rs.getString(5));
	            	employeeData.setCity(rs.getString(6));
	            	employeeData.setLoaState(rs.getString(7));
	            	employeeData.setPostal(rs.getString(8));
	            	employeeData.setFullTimeDate(rs.getString(9));
	            	employeeData.setStdHours(rs.getFloat(10));    
	            	employeeData.setReason(rs.getString(11));
	            	employeeData.setMilitary(rs.getString(12));
	            	employeeData.setWorkRelated(rs.getString(13));
	            	employeeData.setReason2(rs.getString(14));
	            	employeeData.setSubReason(rs.getString(15));
	            	         	
	            	LOGGER.debug(new StringBuffer(logToken).append("Record found"));
	            	LOGGER.debug(new StringBuffer(logToken).append("Saving following data in Employee object"));
	            	LOGGER.debug(new StringBuffer(logToken).append(" -- LAST DATE WORKED = ").append(lastWorkDate));
	            	LOGGER.debug(new StringBuffer(logToken).append(" -- EXPECTED_RETURN_DT = ").append(employeeData.getCurLoaReturnDateToWork()));
					LOGGER.debug(new StringBuffer(logToken).append(" -- ROW_NUM = ").append(employeeData.getRowNum()));
					//LOGGER.debug(new StringBuffer(logToken).append(" -- NAME  = ").append(employeeData.getFullName()));
					LOGGER.debug(new StringBuffer(logToken).append(" -- NAME  = ****"));
					//LOGGER.debug(new StringBuffer(logToken).append(" -- ADDRESS1 = ").append(employeeData.getAddress1()));
					LOGGER.debug(new StringBuffer(logToken).append(" -- ADDRESS1 = ****"));
					//LOGGER.debug(new StringBuffer(logToken).append(" -- CITY = ").append(employeeData.getCity()));
					LOGGER.debug(new StringBuffer(logToken).append(" -- CITY = ****"));
					//LOGGER.debug(new StringBuffer(logToken).append(" -- STATE = ").append(employeeData.getLoaState()));
					LOGGER.debug(new StringBuffer(logToken).append(" -- STATE = ****"));
					//LOGGER.debug(new StringBuffer(logToken).append(" -- POSTAL = ").append(employeeData.getPostal()));
					LOGGER.debug(new StringBuffer(logToken).append(" -- POSTAL = ****"));
					//LOGGER.debug(new StringBuffer(logToken).append(" -- C_FULL_TIME_DT  = ").append(employeeData.getFullTimeDate()));
					LOGGER.debug(new StringBuffer(logToken).append(" -- C_FULL_TIME_DT  = ****"));
					LOGGER.debug(new StringBuffer(logToken).append(" -- STD_HOURS = ").append(employeeData.getStdHours().toString()));				 
					LOGGER.debug(new StringBuffer(logToken).append(" -- C_LOA_REASON = ").append(employeeData.getReason()));
					LOGGER.debug(new StringBuffer(logToken).append(" -- C_MILITARY_LEAVE = ").append(employeeData.getMilitary()));
					LOGGER.debug(new StringBuffer(logToken).append(" -- C_WORK_RELATED = ").append(employeeData.getWorkRelated()));
					LOGGER.debug(new StringBuffer(logToken).append(" -- C_LOA_REASON2  = ").append(employeeData.getReason2()));
					LOGGER.debug(new StringBuffer(logToken).append(" -- C_LOA_SUB_REASON = ").append(employeeData.getSubReason()));
	            	
		         } else{//no result set found
		        	 LOGGER.debug(new StringBuffer(logToken).append("No match for last date worked"));
		        	 rcb = false;
	             }

			 } else {  //connection=null
		        	LOGGER.error(new StringBuffer(logToken).append("No connection made to DB"));
		        	throw new DAOException("Failed to connect to DB");
				}
		}catch(Exception e){ //Problem encountered getting query results
			LOGGER.error(new StringBuffer(logToken).append(" - Exception encountered in query: "));
			LOGGER.error(new StringBuffer(currentQuery));
			LOGGER.error(new StringBuffer(logToken).append(" - Exception:").append(e.getMessage()));
			throw new DAOException(e.getMessage());
				
		}finally{
			 releaseResource(conn, stmt, rs,sessionid);		 
		}

		return rcb;
	
	}

	/********************************************************************************
	* Update Leave of Absence
	/********************************************************************************/		
	public boolean  updateLoa(Employee employeeData, String newReturnDate, String loaType, String sessionid) throws DAOException {
	
	Connection conn = null;
	String employeeId = employeeData.employeeID;
	String emplStatus = employeeData.getEmploymentStatus();
	PreparedStatement stmt = null;
	String currentQuery = null;
	ResultSet rs = null;
	int numRows = 0;
	boolean rcb = true;
	
	//values from query
	//now get from Employee object
	int rowNum = employeeData.getRowNum();
	String name = employeeData.getFullName();
	String address1 = employeeData.getAddress1();
	String city = employeeData.getCity();
	String state = employeeData.getLoaState();
	String postal = employeeData.getPostal();
	String s_fullTimeDate = employeeData.getFullTimeDate();
	Float  stdHours = employeeData.getStdHours();

	String s_lastDateWorked = employeeData.getCurLoaLastDateAtWork();
	String s_expectedReturnDate = employeeData.getCurLoaReturnDateToWork();
	String loaReason = employeeData.getReason();
	String militaryLeave = employeeData.getMilitary();
	String workRelated = employeeData.getWorkRelated();
    String loaReason2 = employeeData.getReason2();
    String loaSubReason = employeeData.getSubReason();
	String extracted = "N";  //ivr always sets to 'N'

	String logToken = new StringBuffer("[").append(sessionid).append("] ").toString();
	
		LOGGER.debug(new StringBuffer(logToken).append("*******Entered LoaDAO::updateLoa()"));
		
		//Connect to the DB	
		try {
			conn = getConnection(jndiName,sessionid);
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer(logToken).append("Exception getting a connection to the DB: ").append(e.getMessage()));
			rcb = false;
			throw new DAOException("Failed to connect to DB");
		}
		
		//get req'd data
		//Moved to getLoaByDate
		
		// Update record using input parms and saved data
		try {			
			if (conn!=null){	
					
	            	LOGGER.debug(new StringBuffer(logToken).append("Updating record: "));
	            	
	            	//SQL_UPDATE_LOA = "INSERT INTO SYSADM.PS_C_LOA_IVR_TBL " +
	            	//"(EMPLID, ROW_NUM, NAME, ADDRESS1, CITY, STATE, POSTAL, " +
	            	//"EMPL_STATUS, C_FULL_TIME_DT, STD_HOURS, LAST_DATE_WORKED, EXPECTED_RETURN_DT," +
	            	//"C_NEW_EXP_RET_DT, C_LEAVE_TYPE, C_LOA_REASON, C_MILITARY_LEAVE, C_WORK_RELATED," +
	            	//"C_LOA_REASON2, C_LOA_SUB_REASON, C_EXTRACTED) " +
	            	//"VALUES (?,?,?,?,?,?,?,?," +
	            	//"TO_DATE('fullTimeDate','MMDDYYYY')," +
	            	//"?," +
	            	//"TO_DATE('lastDateWorked','MMDDYYYY')," +
	            	//"TO_DATE('expectedReturnDate','MMDDYYYY'), " +
	            	//"TO_DATE('newReturnDate','MMDDYYYY')," +
	            	//"?,?,?,?,?,?,?)"; 	
	            	
	            	String tempQuery = SQL_UPDATE_LOA;
	            	if (s_fullTimeDate != null)
	            		tempQuery = new String(tempQuery.replace("fullTimeDate",s_fullTimeDate));
	            	else
	            		tempQuery = new String(tempQuery.replace("TO_DATE('fullTimeDate','MMDDYYYY')","NULL"));
	            	tempQuery = new String(tempQuery.replace("lastDateWorked",s_lastDateWorked));
	            	tempQuery = new String(tempQuery.replace("expectedReturnDate",s_expectedReturnDate));
	            	currentQuery = new String(tempQuery.replace("newReturnDate",newReturnDate));    
					
					stmt = conn.prepareStatement(currentQuery);	
					stmt.setQueryTimeout(sqlTimeout);
	            	stmt.setString(1,employeeId);
	            	stmt.setInt(2,rowNum+1);
	            	stmt.setString(3,name);
	            	stmt.setString(4,address1);
	            	stmt.setString(5,city);	
	            	stmt.setString(6,state);
	            	stmt.setString(7,postal);
	            	stmt.setString(8,emplStatus);
	            	stmt.setFloat(9,stdHours);	
	            	stmt.setString(10,loaType);
	            	stmt.setString(11,loaReason);
	            	stmt.setString(12,militaryLeave);	
	            	stmt.setString(13,workRelated);
	            	stmt.setString(14,loaReason2);
	            	stmt.setString(15,loaSubReason);
	            	stmt.setString(16,extracted);
	            	
		            LOGGER.debug(new StringBuffer(logToken).append("Executing query: ").append(currentQuery));
		             LOGGER.debug(new StringBuffer(logToken).append(" -- EMPLID = ").append(employeeId.substring(employeeId.length()-3,employeeId.length())));
					 LOGGER.debug(new StringBuffer(logToken).append(" -- ROW_NUM = ").append(String.valueOf(rowNum + 1)));
					 //LOGGER.debug(new StringBuffer(logToken).append(" -- NAME  = ").append(name));
					 LOGGER.debug(new StringBuffer(logToken).append(" -- NAME  = ****"));
					 //LOGGER.debug(new StringBuffer(logToken).append(" -- ADDRESS1 = ").append(address1));
					 LOGGER.debug(new StringBuffer(logToken).append(" -- ADDRESS1 = ****"));
					 //LOGGER.debug(new StringBuffer(logToken).append(" -- CITY = ").append(city));
					 LOGGER.debug(new StringBuffer(logToken).append(" -- CITY = ****"));
					 //LOGGER.debug(new StringBuffer(logToken).append(" -- STATE = ").append(state));
					 LOGGER.debug(new StringBuffer(logToken).append(" -- STATE = **"));
					 //LOGGER.debug(new StringBuffer(logToken).append(" -- POSTAL = ").append(postal));
					 LOGGER.debug(new StringBuffer(logToken).append(" -- POSTAL = *****"));
					 LOGGER.debug(new StringBuffer(logToken).append(" -- EMPL_STATUS = ").append(emplStatus));
					 //LOGGER.debug(new StringBuffer(logToken).append(" -- C_FULL_TIME_DT  = ").append(s_fullTimeDate));
					 LOGGER.debug(new StringBuffer(logToken).append(" -- C_FULL_TIME_DT  = ****"));
					 LOGGER.debug(new StringBuffer(logToken).append(" -- STD_HOURS = ").append(stdHours.toString()));
					 LOGGER.debug(new StringBuffer(logToken).append(" -- LAST_DATE_WORKED = ").append(s_lastDateWorked));
					 LOGGER.debug(new StringBuffer(logToken).append(" -- EXPECTED_RETURN_DATE = ").append(s_expectedReturnDate));
					 LOGGER.debug(new StringBuffer(logToken).append(" -- C_NEW_EXP_RET_DT = ").append(newReturnDate));
					 LOGGER.debug(new StringBuffer(logToken).append(" -- C_LEAVE_TYPE = ").append(loaType));
					 LOGGER.debug(new StringBuffer(logToken).append(" -- C_LOA_REASON  = ").append(loaReason));
					 LOGGER.debug(new StringBuffer(logToken).append(" -- C_MILITARY_LEAVE = ").append(militaryLeave));
					 LOGGER.debug(new StringBuffer(logToken).append(" -- C_WORK_RELATED = ").append(workRelated));
					 LOGGER.debug(new StringBuffer(logToken).append(" -- C_LOA_REASON2 = ").append(loaReason2));
					 LOGGER.debug(new StringBuffer(logToken).append(" -- C_LOA_SUB_REASON  = ").append(loaSubReason));
					 LOGGER.debug(new StringBuffer(logToken).append(" -- C_EXTRACTED = ").append(extracted));
					 
	            	numRows = stmt.executeUpdate();
	            	
					if (numRows <= 0) { //insert not successful
						LOGGER.error(new StringBuffer(logToken).append("Insert failed"));
						rcb = false;
						
					} else {
						LOGGER.debug(new StringBuffer(logToken).append("Insert successful"));
					}
				
			} else {  //connection=null
				rcb = false; 
		        	LOGGER.error(new StringBuffer(logToken).append("No connection made to DB for LOA update"));
		        	throw new DAOException("Failed to connect to DB");
		    }
			
			
		}catch(Exception e){  //Problem encountered getting query results/ or inserting new record
				 rcb = false;
				 LOGGER.error(new StringBuffer(logToken).append("Exception encountered in query: ").append(currentQuery));
				 LOGGER.error(new StringBuffer(logToken).append(" - Exception:").append(e.getMessage()));
				 LOGGER.error(new StringBuffer(logToken).append(" -- EMPLID = ").append(employeeId.substring(employeeId.length()-3,employeeId.length())));
				 LOGGER.error(new StringBuffer(logToken).append(" -- ROW_NUM = ").append(String.valueOf(rowNum + 1)));
				 //LOGGER.error(new StringBuffer(logToken).append(" -- NAME  = ").append(name));
				 LOGGER.error(new StringBuffer(logToken).append(" -- NAME  = ****"));
				 //LOGGER.error(new StringBuffer(logToken).append(" -- ADDRESS1 = ").append(address1));
				 LOGGER.error(new StringBuffer(logToken).append(" -- ADDRESS1 = ****"));
				 //LOGGER.error(new StringBuffer(logToken).append(" -- CITY = ").append(city));
				 LOGGER.error(new StringBuffer(logToken).append(" -- CITY = ****"));
				 //LOGGER.error(new StringBuffer(logToken).append(" -- STATE = ").append(state));
				 LOGGER.error(new StringBuffer(logToken).append(" -- STATE = **"));
				 //LOGGER.error(new StringBuffer(logToken).append(" -- POSTAL = ").append(postal));
				 LOGGER.error(new StringBuffer(logToken).append(" -- POSTAL = *****"));
				 LOGGER.error(new StringBuffer(logToken).append(" -- EMPL_STATUS = ").append(emplStatus));
				 //LOGGER.error(new StringBuffer(logToken).append(" -- C_FULL_TIME_DT  = ").append(s_fullTimeDate));
				 LOGGER.error(new StringBuffer(logToken).append(" -- C_FULL_TIME_DT  = ****"));
				 LOGGER.error(new StringBuffer(logToken).append(" -- STD_HOURS = ").append(stdHours));
				 LOGGER.error(new StringBuffer(logToken).append(" -- LAST_DATE_WORKED = ").append(s_lastDateWorked));
				 LOGGER.error(new StringBuffer(logToken).append(" -- EXPECTED_RETURN_DATE = ").append(s_expectedReturnDate));
				 LOGGER.error(new StringBuffer(logToken).append(" -- C_NEW_EXP_RET_DT = ").append(newReturnDate));
				 LOGGER.error(new StringBuffer(logToken).append(" -- C_LEAVE_TYPE = ").append(loaType));
				 LOGGER.error(new StringBuffer(logToken).append(" -- C_LOA_REASON  = ").append(loaReason));
				 LOGGER.error(new StringBuffer(logToken).append(" -- C_MILITARY_LEAVE = ").append(militaryLeave));
				 LOGGER.error(new StringBuffer(logToken).append(" -- C_WORK_RELATED = ").append(workRelated));
				 LOGGER.error(new StringBuffer(logToken).append(" -- C_LOA_REASON2 = ").append(loaReason2));
				 LOGGER.error(new StringBuffer(logToken).append(" -- C_LOA_SUB_REASON  = ").append(loaSubReason));
				 LOGGER.error(new StringBuffer(logToken).append(" -- C_EXTRACTED = ").append(extracted));
				 
				 throw new DAOException(e.getMessage());
		}finally{
				 releaseResource(conn, stmt, rs, sessionid);		 
		}	
	
	return rcb;
	}
	
	/********************************************************************************
	* Determine if employee is eligible for STD
	/********************************************************************************/
	public boolean isEligibleForSTD(Employee employeeData, String sessionid)throws DAOException {
		
		Connection conn = null;
		String employeeId = employeeData.employeeID;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String currentQuery = null;
		String paygroup = "MTS";
		boolean rcb = false;
		
		String logToken = new StringBuffer("[").append(sessionid).append("] ").toString();
		LOGGER.debug(new StringBuffer(logToken).append("********Entering LoaDAO::isEligibleForSTD********"));
		LOGGER.debug(new StringBuffer(logToken).append(" -- emplid = ").append(employeeId.substring(employeeId.length()-3,employeeId.length())));
		 
		//Connect to the DB	
		try {
			conn = getConnection(jndiName, sessionid);
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer(logToken).append("Exception getting a connection to the DB: ").append(e.getMessage()));
			throw new DAOException("Failed to connect to DB");
		}
		//get information
		try {			
			if (conn!=null){				
				LOGGER.debug(new StringBuffer(logToken).append("connection successful, querying data"));
						
				// check for employee in NY or HI
				//SQL_QUERY_ELIG_STD1 = "SELECT A.EMPLID, A.ELIG_CONFIG2 " +
				//"FROM SYSADM.PS_JOB A " +
				//"WHERE A.EMPLID = ? " +
				//"AND A.ELIG_CONFIG2 IN ('HI','NY') " +
				//"AND A.EFFDT = (SELECT MAX(A_ED.EFFDT) " +
				//"FROM SYSADM.PS_JOB A_ED " +
				//"WHERE A.EMPLID = A_ED.EMPLID  " +
				//"AND A.EMPL_RCD = A_ED.EMPL_RCD  " +
				//"AND A_ED.EFFDT  <= SYSDATE) " +
				//"AND A.EFFSEQ = (SELECT MAX(A_ES.EFFSEQ) " +
				//"FROM SYSADM.PS_JOB A_ES " +
				//"WHERE A.EMPLID = A_ES.EMPLID " +
				//"AND A.EMPL_RCD = A_ES.EMPL_RCD " +
				//"AND A.EFFDT = A_ES.EFFDT)";
				
				currentQuery = SQL_QUERY_ELIG_STD1;
				stmt = conn.prepareStatement(currentQuery);
				stmt.setQueryTimeout(sqlTimeout);
				stmt.setString(1,employeeId);
				
				LOGGER.debug(new StringBuffer(logToken).append("Executing query: ").append(currentQuery));
				LOGGER.debug(new StringBuffer(logToken).append(" -- EMPLID = ").append(employeeId.substring(employeeId.length()-3,employeeId.length())));
				
				rs = stmt.executeQuery();
				
	            if (rs.next()){
	            	rcb = true;

		         } else{  //no result set found
		        	 LOGGER.debug(new StringBuffer(logToken).append("No result returned from this query"));
	             }

	            if (!rcb) {
	            	// check for full time > 90 days
	            	//SQL_QUERY_ELIG_STD2 = "SELECT A.EMPLID, A.PAYGROUP, " +
	    			//"A.C_FULL_TIME_DT " +
	    			//"FROM IVR_O.PS_C_EA_1_VW A " +
	    			//"WHERE A.EMPLID = ? " +
	    			//"AND A.PAYGROUP = ? " +
	    			//"AND A.C_FULL_TIME_DT <= (SYSDATE - 90)";	
	            
					currentQuery = SQL_QUERY_ELIG_STD2;
					stmt = conn.prepareStatement(currentQuery);
					stmt.setQueryTimeout(sqlTimeout);
					stmt.setString(1,employeeId);
					stmt.setString(2,paygroup);
					
					LOGGER.debug(new StringBuffer(logToken).append("Executing query: ").append(currentQuery));
					LOGGER.debug(new StringBuffer(logToken).append(" -- EMPLID = ").append(employeeId.substring(employeeId.length()-3,employeeId.length())));
					LOGGER.debug(new StringBuffer(logToken).append(" -- PAYGROUP = ").append(paygroup));
					
					rs = stmt.executeQuery();
					
		            if (rs.next()){
		            	rcb = true;

			         } else{  //no result set found
			        	 LOGGER.debug(new StringBuffer(logToken).append("No result returned from this query"));
		             }         	
	            }
				
	            if (!rcb) {
	            	// check enrolled in STD plan
	            	//SQL_QUERY_ELIG_STD3 = "SELECT DIS.EMPLID, " +
	    			//"DIS.COVERAGE_BEGIN_DT, DIS.COVERAGE_ELECT, DIS.PLAN_TYPE " +
	    			//"FROM SYSADM.PS_DISABILITY_BEN DIS " +
	    			//"WHERE DIS.EMPLID = ? " +
	            	//"AND DIS.PLAN_TYPE IN ('30','3Z') " +
	    			//"AND DIS.COVERAGE_ELECT = 'E' " +
	    			//"AND DIS.COVERAGE_BEGIN_DT = (SELECT MAX(DIS_ED.COVERAGE_BEGIN_DT) " +
	    			//"FROM SYSADM.PS_DISABILITY_BEN DIS_ED " +
	    			//"WHERE DIS_ED.EMPLID = DIS.EMPLID " +
	    			//"AND DIS_ED.EMPL_RCD = DIS.EMPL_RCD " +
	    			//"AND DIS_ED.PLAN_TYPE = DIS.PLAN_TYPE " +
	    			//"AND  DIS_ED.COVERAGE_BEGIN_DT <= SYSDATE)";
	            
					currentQuery = SQL_QUERY_ELIG_STD3;
					stmt = conn.prepareStatement(currentQuery);
					stmt.setQueryTimeout(sqlTimeout);
					stmt.setString(1,employeeId);
					
					LOGGER.debug(new StringBuffer(logToken).append("Executing query: ").append(currentQuery));
					LOGGER.debug(new StringBuffer(logToken).append(" -- EMPLID = ").append(employeeId.substring(employeeId.length()-3,employeeId.length())));
					
					rs = stmt.executeQuery();
					
		            if (rs.next()){
		            	rcb = true;

			         } else{  //no result set found
			        	 LOGGER.debug(new StringBuffer(logToken).append("No result returned from this query"));
		             }         	
	            }


				} else {  //connection=null
		        	LOGGER.error(new StringBuffer(logToken).append("No connection made to DB"));
		        	throw new DAOException("Error getting a connection to the DB");
				}
			 }catch(Exception e){ //Problem encountered getting query results
				 LOGGER.error(new StringBuffer(logToken).append("Exception encountered in query: "));
				 LOGGER.error(new StringBuffer(currentQuery));
				 LOGGER.error(new StringBuffer(logToken).append(" - Exception:").append(e.getMessage()));
				 throw new DAOException(e.getMessage());
				
			 }finally{
				 releaseResource(conn, stmt, rs, sessionid);		 
			 }

		return rcb;
	}
	
	/********************************************************************************
	* Create Leave of Absence
	/********************************************************************************/		
	public boolean  createLoa(Employee employeeData, String  leaveType,   String  lastDateWorked, 
            String  returnWorkDate, String loa_reason,String loa_reason2,String loa_sub_reason,
            String military_leave,String work_related, String sessionid) throws DAOException {

	Connection conn = null;
	String employeeId = employeeData.employeeID;
	String emplStatus = employeeData.getEmploymentStatus();
	PreparedStatement stmt = null;
	String currentQuery = null;
	ResultSet rs = null;
	int numRows = 0;
	boolean exists = false;
	boolean rcb = true;
	
	// set row number for 1st insert
	int rowNum = 1;
	
	//values from query
	String name = null;
	String address1 = null;
	String city = null;
	String state = null;
	String postal = null;
	Date   fullTimeDate = null;
	String stdHours = null;
	String extracted = "N";  //ivr always sets to 'N'
	
	String logToken = new StringBuffer("[").append(sessionid).append("] ").toString();
	
		LOGGER.debug(new StringBuffer(logToken).append("*******Entered LoaDAO::createLoa()"));
		
		//Connect to the DB	
		try {
			conn = getConnection(jndiName, sessionid);
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer(logToken).append("Exception getting a connection to the DB: ").append(e.getMessage()));
			rcb = false;
			throw new DAOException("Failed to connect to DB");
		}
		
		//get req'd data
		//SQL_QUERY_CREATE_LOA = "SELECT NAME, ADDRESS1, CITY, " +
		//"STATE, POSTAL, C_FULL_TIME_DT, STD_HOURS " +
		//"FROM SYSADM.PS_C_EA_1_VW " +
		//"WHERE EMPLID = ?";
		
		try {					
			if (conn!=null){				
				currentQuery = SQL_QUERY_CREATE_LOA;
				stmt = conn.prepareStatement(currentQuery);	
				stmt.setQueryTimeout(sqlTimeout);
				stmt.setString(1,employeeId);
				
	            LOGGER.debug(new StringBuffer(logToken).append("Executing query: ").append(currentQuery));
	            LOGGER.debug(new StringBuffer(logToken).append("--emplid = ").append(employeeId.substring(employeeId.length()-3,employeeId.length())));
				
                rs = stmt.executeQuery();
                
	            if (rs.next()){		        	
		            exists = true;
		            name = rs.getString(1);
		            address1 = rs.getString(2);
		            city = rs.getString(3);
		            state = rs.getString(4);
		            postal = rs.getString(5);
		            fullTimeDate = rs.getDate(6);
		            stdHours = rs.getString(7);
	            }          

	            if (exists) {  //add new record to LOA table
	            	LOGGER.debug(new StringBuffer(logToken).append("Empl record found"));
	            	LOGGER.debug(new StringBuffer(logToken).append("Inserting new record: "));
	            	
	            	//SQL_INSERT_NEW_LOA = "INSERT INTO SYSADM.PS_C_LOA_IVR_TBL " +
	    			//"(EMPLID, ROW_NUM, NAME, ADDRESS1, CITY, STATE, POSTAL, " +
	    			//"EMPL_STATUS, C_FULL_TIME_DT, STD_HOURS, LAST_DATE_WORKED, EXPECTED_RETURN_DT " +
	    			//"C_NEW_EXP_RET_DT, C_LEAVE_TYPE, C_LOA_REASON, C_MILITARY_LEAVE, C_WORK_RELATED," +
	    			//"C_LOA_REASON2, C_LOA_SUB_REASON, C_EXTRACTED) " +
	    			//"VALUES (?,?,?,?,?,?,?,
	            	//         ?,?,?,
	            	//         TO_DATE('lastDateWorked','MMDDYYYY'),
	            	//         TO_DATE('returnWorkDate','MMDDYYYY'),
	            	//         null,
	            	//         ?,?,?,?,
	    			//		   ?,?,?)";   
	            	
	            	String tempQuery = SQL_INSERT_NEW_LOA;
	            	String tempQuery2 = new String(tempQuery.replace("lastDateWorked",lastDateWorked));
	            	currentQuery = new String(tempQuery2.replace("returnWorkDate",returnWorkDate));
	            	
					//currentQuery = SQL_UPDATE_LOA;
					stmt = conn.prepareStatement(currentQuery);	
					stmt.setQueryTimeout(sqlTimeout);
					
	            	stmt.setString(1,employeeId);
	            	stmt.setInt(2,rowNum);
	            	stmt.setString(3,name);
	            	stmt.setString(4,address1);
	            	stmt.setString(5,city);	
	            	stmt.setString(6,state);
	            	stmt.setString(7,postal);
	            	stmt.setString(8,emplStatus);
	            	stmt.setDate(9,fullTimeDate);
	            	stmt.setString(10,stdHours);	
	            	stmt.setString(11,leaveType);
	            	stmt.setString(12,loa_reason);
	            	stmt.setString(13,military_leave);	
	            	stmt.setString(14,work_related);
	            	stmt.setString(15,loa_reason2);
	            	stmt.setString(16,loa_sub_reason);
	            	stmt.setString(17,extracted);
	            	
		            LOGGER.debug(new StringBuffer(logToken).append("Executing query: ").append(currentQuery));
					 LOGGER.debug(new StringBuffer(logToken).append(" -- EMPLID = ").append(employeeId.substring(employeeId.length()-3,employeeId.length())));
					 LOGGER.debug(new StringBuffer(logToken).append(" -- ROW_NUM = ").append(String.valueOf(rowNum)));
					 //LOGGER.debug(new StringBuffer(logToken).append(" -- NAME  = ").append(name));
					 LOGGER.debug(new StringBuffer(logToken).append(" -- NAME  = ****"));
					 //LOGGER.debug(new StringBuffer(logToken).append(" -- ADDRESS1 = ").append(address1));
					 LOGGER.debug(new StringBuffer(logToken).append(" -- ADDRESS1 = ****"));
					 //LOGGER.debug(new StringBuffer(logToken).append(" -- CITY = ").append(city));
					 LOGGER.debug(new StringBuffer(logToken).append(" -- CITY = ****"));
					 //LOGGER.debug(new StringBuffer(logToken).append(" -- STATE = ").append(state));
					 LOGGER.debug(new StringBuffer(logToken).append(" -- STATE = **"));
					 //LOGGER.debug(new StringBuffer(logToken).append(" -- POSTAL = ").append(postal));
					 LOGGER.debug(new StringBuffer(logToken).append(" -- POSTAL = *****"));
					 LOGGER.debug(new StringBuffer(logToken).append(" -- EMPL_STATUS = ").append(emplStatus));
					 //LOGGER.debug(new StringBuffer(logToken).append(" -- C_FULL_TIME_DT  = ").append(s_fullTimeDate));
					 LOGGER.debug(new StringBuffer(logToken).append(" -- C_FULL_TIME_DT  = ****"));
					 LOGGER.debug(new StringBuffer(logToken).append(" -- STD_HOURS = ").append(stdHours));
					 LOGGER.debug(new StringBuffer(logToken).append(" -- LAST_DATE_WORKED = ").append(lastDateWorked));
					 LOGGER.debug(new StringBuffer(logToken).append(" -- EXPECTED_RETURN_DT = ").append(returnWorkDate));
					 LOGGER.debug(new StringBuffer(logToken).append(" -- C_LEAVE_TYPE = ").append(leaveType));
					 LOGGER.debug(new StringBuffer(logToken).append(" -- C_LOA_REASON  = ").append(loa_reason));
					 LOGGER.debug(new StringBuffer(logToken).append(" -- C_MILITARY_LEAVE = ").append(military_leave));
					 LOGGER.debug(new StringBuffer(logToken).append(" -- C_WORK_RELATED = ").append(work_related));
					 LOGGER.debug(new StringBuffer(logToken).append(" -- C_LOA_REASON2 = ").append(loa_reason2));
					 LOGGER.debug(new StringBuffer(logToken).append(" -- C_LOA_SUB_REASON  = ").append(loa_sub_reason));
					 LOGGER.debug(new StringBuffer(logToken).append(" -- C_EXTRACTED = ").append(extracted));
		            
	            	numRows = stmt.executeUpdate();
	            	
					if (numRows <= 0) { //insert not successful
						LOGGER.error(new StringBuffer(logToken).append("Insert failed"));
						rcb = false;
						
					} else {
						LOGGER.debug(new StringBuffer(logToken).append("Insert successful"));
					}
		            
	            } else {  //no record found, return false
	            	LOGGER.debug(new StringBuffer(logToken).append("No empl record found in ps_c_ea_1_vw"));
	            	rcb = false;
	            }
				
			} else {  //connection=null
				rcb = false; 
		        	LOGGER.error(new StringBuffer(logToken).append(" - No connection made to DB for LOA insert"));
		        	throw new DAOException("Failed to connect to DB");
		    }
			
			
		}catch(Exception e){  //Problem encountered getting query results
			 rcb = false;
			//Defect 170502 If duplicate row, return false, and log in debug only
			String emsg = e.getMessage();
			if ((emsg != null) && (emsg.contains("ORA-00001"))){
				 LOGGER.debug(new StringBuffer(logToken).append(" - Exception:").append(emsg));
				 LOGGER.debug(new StringBuffer(logToken).append(" -- EMPLID = ").append(employeeId.substring(employeeId.length()-3,employeeId.length())));
				 LOGGER.debug(new StringBuffer(logToken).append(" -- LAST_DATE_WORKED = ").append(lastDateWorked));
			} else {
				 LOGGER.error(new StringBuffer(logToken).append(" - Exception encountered in query: "));
				 LOGGER.error(new StringBuffer(currentQuery));
				 LOGGER.error(new StringBuffer(logToken).append(" - Exception:").append(emsg));
				 LOGGER.error(new StringBuffer(logToken).append(" -- EMPLID = ").append(employeeId.substring(employeeId.length()-3,employeeId.length())));
				 LOGGER.error(new StringBuffer(logToken).append(" -- ROW_NUM = ").append(String.valueOf(rowNum)));
				 //LOGGER.error(new StringBuffer(logToken).append(" -- NAME  = ").append(name));
				 LOGGER.error(new StringBuffer(logToken).append(" -- NAME  = ****"));
				 //LOGGER.error(new StringBuffer(logToken).append(" -- ADDRESS1 = ").append(address1));
				 LOGGER.error(new StringBuffer(logToken).append(" -- ADDRESS1 = ****"));
				 //LOGGER.error(new StringBuffer(logToken).append(" -- CITY = ").append(city));
				 LOGGER.error(new StringBuffer(logToken).append(" -- CITY = ****"));
				 //LOGGER.error(new StringBuffer(logToken).append(" -- STATE = ").append(state));
				 LOGGER.error(new StringBuffer(logToken).append(" -- STATE = **"));
				 //LOGGER.error(new StringBuffer(logToken).append(" -- POSTAL = ").append(postal));
				 LOGGER.error(new StringBuffer(logToken).append(" -- POSTAL = *****"));
				 LOGGER.error(new StringBuffer(logToken).append(" -- EMPL_STATUS = ").append(emplStatus));
				 //LOGGER.error(new StringBuffer(logToken).append(" -- C_FULL_TIME_DT  = ").append(s_fullTimeDate));
				 LOGGER.error(new StringBuffer(logToken).append(" -- C_FULL_TIME_DT  = ****"));
				 LOGGER.error(new StringBuffer(logToken).append(" -- STD_HOURS = ").append(stdHours));
				 LOGGER.error(new StringBuffer(logToken).append(" -- LAST_DATE_WORKED = ").append(lastDateWorked));
				 LOGGER.error(new StringBuffer(logToken).append(" -- EXPECTED_RETURN_DT = ").append(returnWorkDate));
				 LOGGER.error(new StringBuffer(logToken).append(" -- C_LEAVE_TYPE = ").append(leaveType));
				 LOGGER.error(new StringBuffer(logToken).append(" -- C_LOA_REASON  = ").append(loa_reason));
				 LOGGER.error(new StringBuffer(logToken).append(" -- C_MILITARY_LEAVE = ").append(military_leave));
				 LOGGER.error(new StringBuffer(logToken).append(" -- C_WORK_RELATED = ").append(work_related));
				 LOGGER.error(new StringBuffer(logToken).append(" -- C_LOA_REASON2 = ").append(loa_reason2));
				 LOGGER.error(new StringBuffer(logToken).append(" -- C_LOA_SUB_REASON  = ").append(loa_sub_reason));
				 LOGGER.error(new StringBuffer(logToken).append(" -- C_EXTRACTED = ").append(extracted));
				 
				 throw new DAOException(e.getMessage());			
			}	
		}finally{
				 releaseResource(conn, stmt, rs, sessionid);		 
		}	
	
	return rcb;
	}
	
	/********************************************************************************
	* Report Intermittent LOA Hours
	/********************************************************************************/		
	public boolean  reportIntermittentLOAHours(Employee employeeData, String loaReason, 
            String intrDate, Float hoursminutes, String sessionid)  throws DAOException {

	Connection conn = null;
	String employeeId = employeeData.employeeID;
	PreparedStatement stmt = null;
	String currentQuery = null;
	ResultSet rs = null;
	int numRows = 0;
	boolean rcb = true;
	String extracted = "N";  //ivr always sets to 'N'

	String logToken = new StringBuffer("[").append(sessionid).append("] ").toString();
	
		LOGGER.debug(new StringBuffer(logToken).append("*******Entered LoaDAO::reportIntermittentLOAHours()"));
		
		//Connect to the DB	
		try {
			conn = getConnection(jndiName, sessionid);
		} catch (SQLException e) {
			LOGGER.error(new StringBuffer(logToken).append("Exception getting a connection to the DB: ").append(e.getMessage()));
			rcb = false;
			throw new DAOException("Failed to connect to DB");
		}
		
		
		try {					
			if (conn!=null){				
	            	
				//SQL_INSERT_INTRMT_LOA = "INSERT INTO sysadm.ps_c_intr_ivr_tbl " +
				//"(EMPLID, C_INTR_IVR_DT, C_INTR_IVR_HRS, C_INTR_IVR_REASON, C_DATE_CALLED, C_EXTRACTED ) " +
				//"VALUES (?, TO_DATE('intrDate','MMDDYYYY'), ? , ?, SYSDATE, ?";
				
	            	String tempQuery = SQL_INSERT_INTRMT_LOA;
	            	currentQuery = new String(tempQuery.replace("intrDate",intrDate));
	            	
					//currentQuery = SQL_UPDATE_LOA;
					stmt = conn.prepareStatement(currentQuery);	
					stmt.setQueryTimeout(sqlTimeout);
	            	stmt.setString(1,employeeId);
	            	stmt.setFloat(2,hoursminutes);
	            	stmt.setString(3,loaReason);
	            	stmt.setString(4,extracted);
          	
		            LOGGER.debug(new StringBuffer(logToken).append("Executing query: ").append(currentQuery));
					 LOGGER.debug(new StringBuffer(logToken).append(" -- EMPLID = ").append(employeeId.substring(employeeId.length()-3,employeeId.length())));
					 LOGGER.debug(new StringBuffer(logToken).append(" -- C_INTR_IVR_HRS = ").append(hoursminutes.toString()));
					 LOGGER.debug(new StringBuffer(logToken).append(" -- C_INTR_IVR_REASON = ").append(loaReason));
					 LOGGER.debug(new StringBuffer(logToken).append(" -- C_EXTRACTED = ").append(extracted));
		            
	            	numRows = stmt.executeUpdate();
	            	
					if (numRows <= 0) { //insert not successful
						LOGGER.error(new StringBuffer(logToken).append("Insert failed"));
						rcb = false;
						
					} else {
						LOGGER.debug(new StringBuffer(logToken).append("Insert successful"));
					}
		            
			} else {  //connection=null
				rcb = false; 
		        	LOGGER.error(new StringBuffer(logToken).append("No connection made to DB for intermittent loa update"));
		        	throw new DAOException("Failed to connect to DB");
		    }
			
			
		}catch(Exception e){  //Problem encountered getting query results
				 rcb = false;
				 LOGGER.error(new StringBuffer(logToken).append("Exception encountered in query: "));
				 LOGGER.error(new StringBuffer(currentQuery));
				 LOGGER.error(new StringBuffer(logToken).append(" -- EMPLID = ").append(employeeId.substring(employeeId.length()-3,employeeId.length())));
				 LOGGER.error(new StringBuffer(logToken).append(" -- C_INTR_IVR_HRS = ").append(String.valueOf(hoursminutes)));
				 LOGGER.error(new StringBuffer(logToken).append(" -- C_INTR_IVR_REASON = ").append(loaReason));
				 LOGGER.error(new StringBuffer(logToken).append(" -- C_EXTRACTED = ").append(extracted));
				 
				 throw new DAOException(e.getMessage());
		}finally{
				 releaseResource(conn, stmt, rs, sessionid);		 
		}	
	
	return rcb;
	}	
	
}
