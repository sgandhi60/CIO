package com.ibm.ivr.cvs.handler;

import java.io.IOException;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.ibm.ivr.cvs.dao.DAOException;
import com.ibm.ivr.cvs.dao.PaycheckDAO;
import com.ibm.ivr.cvs.data.Employee;

/**
 * Get paycheck delivery status
 * Input: employee, storeNumberEntered (from session) 
 * Output: 
 * 		  employee object delivery status fields updated (into session) 
 *
 *Revision history:
 * <p>
 * 
 * 2010-10-12: initial version
 * <p>
 * 
 * @author Fang Wang
 * @version 2010-10-25
 *
 */
public class GetCheckDeliveryStatus extends HttpServlet implements Servlet{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4878308495608097484L;
	
	private static Logger LOGGER = Logger.getLogger(GetCheckDeliveryStatus.class);

	public void doGet(HttpServletRequest req, HttpServletResponse resp)
							throws ServletException, IOException {

	// get session from Servlet request, created if not existed yet
	HttpSession session = req.getSession(true);
	//Properties prop = (Properties)session.getServletContext().getAttribute("globalProp");

	String callid = (String) session.getAttribute("callid");

	boolean testCall = ((Boolean) session.getAttribute("testCall")).booleanValue();

	//create the log Token for later use, use StringBuffer to reduce number
	// of String objects
	String logToken = new StringBuffer("[").append(callid).append("] ").toString();
		 
	 if (testCall)
	 	LOGGER.debug(new StringBuffer(logToken).append("Entering Handler: GetCheckDeliveryStatus"));
	
		
    // Get attributes from the session
	Employee employee = (Employee) session.getAttribute("employee");
	String storeNumber = (String) session.getAttribute("storeNumberEntered");
	
	if (employee != null){
		//calling payCheckDAO to search
		PaycheckDAO pDAO = (PaycheckDAO) session.getServletContext().getAttribute("paycheckDAO");
		
		try {
			if (pDAO.getCheckDeliveryStatus(employee, storeNumber, callid))
				session.setAttribute("hRC", "S");
			else
				session.setAttribute("hRC", "E");
			
			if (testCall)
				LOGGER.debug(new StringBuffer(logToken).append("delivery type:").append(employee.getDeliveryType()));
			
			//employee.setDeliveryType("UPS");
			//employee.setDeliveryCheckDate("10252010");
			//employee.setDeliveryTrackingNum("1Z3452d");
			//session.setAttribute("hRC", "S");
			
		}catch(DAOException e){
			LOGGER.info(new StringBuffer(logToken).append("failed to get check delivery status: ").append(e.getMessage()));
		     if (e.getMessage() != null && e.getMessage().equalsIgnoreCase("Failed to connect to DB"))
		    	 session.setAttribute("hRC", "C");
		     else
		    	 session.setAttribute("hRC", "E");			
		}
	}
	else {
		LOGGER.warn(new StringBuffer(logToken).append("no employee object in the session"));
		session.setAttribute("hRC", "E");
	}
   return;
  }
}
