package com.ibm.ivr.cvs.handler;

import java.io.IOException;
import java.util.Properties;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.ibm.ivr.cvs.dao.DAOException;
import com.ibm.ivr.cvs.dao.PaycheckDAO;
import com.ibm.ivr.cvs.data.Employee;
import com.ibm.ivr.framework.utilities.Common;

/**
 * Get pay end dates for the employee information
 * Input: employee (from session) 
 * Output: 
 * 		  employee object empPayEndDates field updated (into session) 
 * 		  previousCheckIndex Integer object in the session
 * 		  corporateEmployee String object in the session
 *
 *Revision history:
 * <p>
 * 
 * 2010-10-26: initial version
 * <p>
 * 
 * @author Fang Wang
 * @version 2010-10-26
 *
 * 05/17/2011 FSW: Defect 170553, change check for corporate employee (if numeric not
 * 				corporate (previously checked if > 09999)
 * 05/22/2011 FSW: Change to defect 170553, Need to check 'location' not 'deptid'
 */
public class GetPayEndDates extends HttpServlet implements Servlet{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7663418342607197976L;

	private static Logger LOGGER = Logger.getLogger(GetPayEndDates.class);

	public void doGet(HttpServletRequest req, HttpServletResponse resp)
							throws ServletException, IOException {

	// get session from Servlet request, created if not existed yet
	HttpSession session = req.getSession(true);
	//Properties prop = (Properties)session.getServletContext().getAttribute("globalProp");

	String callid = (String) session.getAttribute("callid");

	boolean testCall = ((Boolean) session.getAttribute("testCall")).booleanValue();

	//create the log Token for later use, use StringBuffer to reduce number
	// of String objects
	String logToken = new StringBuffer("[").append(callid).append("] ").toString();
		 
	 if (testCall)
	 	LOGGER.debug(new StringBuffer(logToken).append("Entering Handler: GetPayEndDates"));
	
		
    // Get attributes from the session
	Employee employee = (Employee) session.getAttribute("employee");
	
	if (employee != null){
		//if deptid > 09999, corporate employee
		//170553 start
		/*if (!employee.getDepartmentID().startsWith("0"))
			session.setAttribute("corporateEmployee", Common.TRUE);
		else
			session.setAttribute("corporateEmployee", Common.FALSE);
		*/
		session.setAttribute("corporateEmployee", Common.FALSE);
		//following will throw exception if location is not numeric
		try {
		 Integer.parseInt(employee.getEmployeeLocation());
			
		} catch (NumberFormatException e) {
			session.setAttribute("corporateEmployee", Common.TRUE);
		}
		//170553 End
		
		session.setAttribute("previousCheckIndex", new Integer(0));
		
		//calling payCheckDAO to search
		PaycheckDAO pDAO = (PaycheckDAO) session.getServletContext().getAttribute("paycheckDAO");
		
		int maxRows = Integer.parseInt(((Properties)session.getServletContext().getAttribute("cvsProp")).getProperty("maxPaycheckRows"));
		try {
			if (pDAO.getPayEndDates(employee, maxRows, callid)){
				session.setAttribute("hRC", "S");
				if (testCall)
				 	LOGGER.debug(new StringBuffer(logToken).append("number of PayEndDates returned: ").append(employee.getEmpPayEndDates().length));
			}
			else
				session.setAttribute("hRC", "E");		
			
						
			//ArrayList<String> date = new ArrayList<String>();
			//date.add("09301020");
			//date.add("10312010");
			//date.add("11302010");
			//employee.setEmpPayEndDates(date);
			
		}catch(DAOException e){
			LOGGER.debug(new StringBuffer(logToken).append("failed to get pay end dates: ").append(e.getMessage()));
		     if (e.getMessage() != null &&  e.getMessage().equalsIgnoreCase("Failed to connect to DB"))
		    	 session.setAttribute("hRC", "C");
		     else
		    	 session.setAttribute("hRC", "E");			
		}
	}
	else {
		LOGGER.warn(new StringBuffer(logToken).append("no employee object in the session"));
		session.setAttribute("hRC", "E");
	}
   return;
  }
}
