package com.ibm.ivr.cvs.handler;

import java.io.IOException;
import java.util.Properties;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.ibm.ivr.cvs.dao.DAOException;
import com.ibm.ivr.cvs.dao.IdentificationDAO;
import com.ibm.ivr.cvs.data.Employee;

/**
 * Searching employee state in database
 * Input: employee object 
 * Output: 
 * 		  employeeState in employee object updated
 *
 *Revision history:
 * <p>
 * 
 * 2010-10-08: initial version
 * <p>
 * 
 * @author Fang Wang
 * @version 2010-10-08
 *
 */
public class GetGABNumber extends HttpServlet implements Servlet{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7747564843316568543L;
	
	private static Logger LOGGER = Logger.getLogger(GetGABNumber.class);

	public void doGet(HttpServletRequest req, HttpServletResponse resp)
							throws ServletException, IOException {

	// get session from Servlet request, created if not existed yet
	HttpSession session = req.getSession(true);
	//Properties prop = (Properties)session.getServletContext().getAttribute("globalProp");

	String callid = (String) session.getAttribute("callid");

	boolean testCall = ((Boolean) session.getAttribute("testCall")).booleanValue();

	//create the log Token for later use, use StringBuffer to reduce number
	// of String objects
	String logToken = new StringBuffer("[").append(callid).append("] ").toString();
		 
	 if (testCall)
	 	LOGGER.debug(new StringBuffer(logToken).append("Entering Handler: GetGABNumber"));
	
		
    // Get attributes from the session
	Employee employee = (Employee) session.getAttribute("employee");
	
	//calling IdentificationDAO to search
	IdentificationDAO iDAO = (IdentificationDAO) session.getServletContext().getAttribute("identificationDAO");
	Properties cvsProp = (Properties) session.getServletContext().getAttribute("cvsProp");
	
	try {
		if (iDAO.getState(employee, callid)) {
			String number = cvsProp.getProperty("TFN_GAB_"+employee.getEmployeeState());
			if (testCall){
				LOGGER.debug(new StringBuffer(logToken).append("GAB number key: ").append("TFN_GAB_").append(employee.getEmployeeState()).append("=").append(number));
			}
			if (number != null)
				session.setAttribute("GABNumber", number);
			else
				session.setAttribute("GABNumber", (String)session.getAttribute("TNT"));
		}else
			session.setAttribute("GABNumber", (String)session.getAttribute("TNT"));
		
	}catch(DAOException e){
		LOGGER.debug(new StringBuffer(logToken).append("failed to look up employee state: ").append(e.getMessage()));
	     if (e.getMessage() != null && e.getMessage().equalsIgnoreCase("Failed to connect to DB"))
	    	 session.setAttribute("hRC", "C");
	     else
	    	 session.setAttribute("hRC", "E");			

		session.setAttribute("GABNumber", (String)session.getAttribute("TNT"));
	}

   return;
  }
}
