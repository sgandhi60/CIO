package com.ibm.ivr.cvs.handler;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.ibm.ivr.cvs.dao.CertificationDAO;
import com.ibm.ivr.cvs.dao.DAOException;
import com.ibm.ivr.cvs.data.Employee;

public class DEA extends HttpServlet {
       
	/**
	 * 
	 */
	private static final long serialVersionUID = 7198228775338574407L;
	private static Logger LOGGER = Logger.getLogger(DEA.class);

	/**
     * @see HttpServlet#HttpServlet()
     */
    public DEA() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		// get session from Servlet request, created if not existed yet
		HttpSession session = request.getSession(true);
		String callid = (String) session.getAttribute("callid");
		boolean testCall = ((Boolean) session.getAttribute("testCall")).booleanValue();

		//create the log Token for later use, use StringBuffer to reduce number
		// of String objects
		String logToken = new StringBuffer("[").append(callid).append("] ").toString();
			 
		 if (testCall)
		 	LOGGER.debug(new StringBuffer(logToken).append("Entering Handler: DEA::"));
		 
		 String hRC = "S";
		 boolean deaStatusResult = false;
		 Employee employee = (Employee) session.getAttribute("employee");
		 String deaCmd = (String) session.getAttribute("deaCmd");
		 
		 CertificationDAO certDAO = (CertificationDAO)session.getServletContext().getAttribute("certificationDAO");

		 if (testCall)
			 	LOGGER.debug(new StringBuffer(logToken).append("deaCmd::")
	                                                   .append(deaCmd));
         // See if the Employee has already Certified
		 if (deaCmd.trim().equalsIgnoreCase("get")){		 
			   try{
				   
				   deaStatusResult = certDAO.getDEACertStatus(employee, callid);
				   //deaStatusResult = certDAO.getDEACertStatus(employee);

			   }catch (DAOException de){
			     LOGGER.error(new StringBuffer(logToken).append("Exception getting DEA status::"+de.toString()));
			     if (de.getMessage() != null && de.getMessage().equalsIgnoreCase("Failed to connect to DB"))
			    	 hRC = "C";
			     else
		            hRC = "E";
			   }
			         //  Record the DEA Certification
			 } else if (deaCmd.trim().equalsIgnoreCase("record")){		 
				   try{
					   
					   deaStatusResult = certDAO.recordDEACertification(employee, callid);

				   }catch (DAOException de){
				     LOGGER.error(new StringBuffer(logToken).append("Exception recording DEA status::"+de.toString()));
				     if (de.getMessage() != null && de.getMessage().equalsIgnoreCase("Failed to connect to DB"))
				    	 hRC = "C";
				     else
			            hRC = "E";
				   }
				 }else{
					 hRC = "E";
					 LOGGER.error(new StringBuffer(logToken).append("Invalid deaCmd::")
							                                .append(deaCmd));
				 }
		 		 
		 if (testCall)
			 	LOGGER.debug(new StringBuffer(logToken).append("Exiting Handler: DEA::")
			 			                               .append("  hRC::")
			 			                               .append(hRC)
			 			                               .append("  statusResult::")
			 			                               .append(deaStatusResult));
     // Store the handler processing result
	 session.setAttribute("hRC", hRC);
	 session.setAttribute("deaStatusResult", deaStatusResult);
	 
     return;
	}
}
